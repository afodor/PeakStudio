// $Id: NameAndValues.java,v 1.1 2010/07/29 16:23:31 afodor Exp $
// FORESTER -- software libraries and applications
// for evolutionary biology research and applications.
//
// Copyright (C) 2008-2009 Christian M. Zmasek
// Copyright (C) 2008-2009 Burnham Institute for Medical Research
// Copyright (C) 2000-2001 Washington University School of Medicine
// and Howard Hughes Medical Institute
// All rights reserved
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
// Contact: cmzmasek@yahoo.com
// WWW: www.phylosoft.org/forester

package org.forester.sdi;

/*
 * @author Christian M. Zmasek
 * 
 * @version 1.100 -- last modified: 10/06/01
 */
class NameAndValues implements Comparable {

    public static final int DEFAULT = -999;
    private final String    name_;
    private final double    value1_, value2_, value3_, value4_;
    private int[]           p_;                                // Since

    NameAndValues() {
        setSigns();
        name_ = "";
        value1_ = NameAndValues.DEFAULT;
        value2_ = NameAndValues.DEFAULT;
        value3_ = NameAndValues.DEFAULT;
        value4_ = NameAndValues.DEFAULT;
    }

    // distance
    // needs to be
    // sorted in
    // different
    // direction than other values, and it is not
    // known which value will be the distance.
    NameAndValues( final String name,
                   final double value1,
                   final double value2,
                   final double value3,
                   final double value4,
                   final int c ) {
        setSigns();
        name_ = name;
        value1_ = value1;
        value2_ = value2;
        value3_ = value3;
        value4_ = value4;
        if ( ( c >= 0 ) && ( c <= 3 ) ) {
            p_[ c ] = -1;
        }
    }

    NameAndValues( final String name, final double value1, final double value2, final double value3, final int c ) {
        setSigns();
        name_ = name;
        value1_ = value1;
        value2_ = value2;
        value3_ = value3;
        value4_ = NameAndValues.DEFAULT;
        if ( ( c >= 0 ) && ( c <= 2 ) ) {
            p_[ c ] = -1;
        }
    }

    NameAndValues( final String name, final double value1, final double value2, final int c ) {
        setSigns();
        name_ = name;
        value1_ = value1;
        value2_ = value2;
        value3_ = NameAndValues.DEFAULT;
        value4_ = NameAndValues.DEFAULT;
        if ( ( c >= 0 ) && ( c <= 1 ) ) {
            p_[ c ] = -1;
        }
    }

    NameAndValues( final String name, final double value1, final int c ) {
        setSigns();
        name_ = name;
        value1_ = value1;
        value2_ = NameAndValues.DEFAULT;
        value3_ = NameAndValues.DEFAULT;
        value4_ = NameAndValues.DEFAULT;
        if ( c == 0 ) {
            p_[ 0 ] = -1;
        }
    }

    public int compareTo( final NameAndValues n ) {
        if ( ( getValue1() != NameAndValues.DEFAULT ) && ( n.getValue1() != NameAndValues.DEFAULT ) ) {
            if ( getValue1() < n.getValue1() ) {
                return p_[ 0 ];
            }
            if ( getValue1() > n.getValue1() ) {
                return ( -p_[ 0 ] );
            }
        }
        if ( ( getValue2() != NameAndValues.DEFAULT ) && ( n.getValue2() != NameAndValues.DEFAULT ) ) {
            if ( getValue2() < n.getValue2() ) {
                return p_[ 1 ];
            }
            if ( getValue2() > n.getValue2() ) {
                return ( -p_[ 1 ] );
            }
        }
        if ( ( getValue3() != NameAndValues.DEFAULT ) && ( n.getValue3() != NameAndValues.DEFAULT ) ) {
            if ( getValue3() < n.getValue3() ) {
                return p_[ 2 ];
            }
            if ( getValue3() > n.getValue3() ) {
                return ( -p_[ 2 ] );
            }
        }
        if ( ( getValue4() != NameAndValues.DEFAULT ) && ( n.getValue4() != NameAndValues.DEFAULT ) ) {
            if ( getValue4() < n.getValue4() ) {
                return p_[ 3 ];
            }
            if ( getValue4() > n.getValue4() ) {
                return ( -p_[ 3 ] );
            }
        }
        return ( getName().compareTo( n.getName() ) );
    }

    public int compareTo( final Object o ) {
        return this.compareTo( ( NameAndValues ) o );
    }

    String getName() {
        return name_;
    }

    double getValue1() {
        return value1_;
    }

    double getValue2() {
        return value2_;
    }

    double getValue3() {
        return value3_;
    }

    double getValue4() {
        return value4_;
    }

    private void setSigns() {
        p_ = new int[ 4 ];
        p_[ 0 ] = p_[ 1 ] = p_[ 2 ] = p_[ 3 ] = +1;
    }
}