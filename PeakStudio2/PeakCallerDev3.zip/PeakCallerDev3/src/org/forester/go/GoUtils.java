// $Id: GoUtils.java,v 1.1 2010/07/29 16:23:30 afodor Exp $
// FORESTER -- software libraries and applications
// for evolutionary biology research and applications.
//
// Copyright (C) 2008-2009 Christian M. Zmasek
// Copyright (C) 2008-2009 Burnham Institute for Medical Research
// All rights reserved
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
// Contact: cmzmasek@yahoo.com
// WWW: www.phylosoft.org/forester

package org.forester.go;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

public final class GoUtils {

    private GoUtils() {
    }

    public static Map<GoId, GoTerm> createGoIdToGoTermMap( final List<GoTerm> go_terms ) {
        final Map<GoId, GoTerm> go_id_to_term_map = new HashMap<GoId, GoTerm>();
        for( final GoTerm go_term : go_terms ) {
            go_id_to_term_map.put( go_term.getGoId(), go_term );
        }
        return go_id_to_term_map;
    }

    public static SortedSet<GoTerm> getAllSuperGoTerms( final GoId go_id, final List<GoTerm> go_terms ) {
        final Map<GoId, GoTerm> goid_to_term_map = GoUtils.createGoIdToGoTermMap( go_terms );
        return getAllSuperGoTerms( go_id, goid_to_term_map );
    }

    public static SortedSet<GoTerm> getAllSuperGoTerms( final GoId go_id, final Map<GoId, GoTerm> goid_to_term_map ) {
        if ( !goid_to_term_map.containsKey( go_id ) ) {
            throw new IllegalArgumentException( "GO id [" + go_id + "] not found in GO id to term map" );
        }
        final GoTerm go_term = goid_to_term_map.get( go_id );
        return getAllSuperGoTerms( go_term, goid_to_term_map );
    }

    public static SortedSet<GoTerm> getAllSuperGoTerms( final GoTerm go_term, final Map<GoId, GoTerm> goid_to_term_map ) {
        final SortedSet<GoTerm> supers = new TreeSet<GoTerm>();
        getAllSuperGoTerms( go_term, goid_to_term_map, supers );
        return supers;
    }

    public static GoTerm getPenultimateGoTerm( final GoTerm go_term, final Map<GoId, GoTerm> map ) {
        GoTerm my_go_term = go_term;
        GoTerm penultimate = my_go_term;
        while ( ( my_go_term.getSuperGoIds() != null ) && ( my_go_term.getSuperGoIds().size() > 0 ) ) {
            penultimate = my_go_term;
            if ( !map.containsKey( my_go_term.getSuperGoIds().get( 0 ) ) ) {
                throw new IllegalArgumentException( "GO-id [" + my_go_term.getSuperGoIds().get( 0 )
                        + "] not found in map" );
            }
            my_go_term = map.get( my_go_term.getSuperGoIds().get( 0 ) );
        }
        return penultimate;
    }

    public static GoTerm getUltimateGoTerm( final GoTerm go_term, final Map<GoId, GoTerm> map ) {
        GoTerm my_go_term = go_term;
        while ( ( my_go_term.getSuperGoIds() != null ) && ( my_go_term.getSuperGoIds().size() > 0 ) ) {
            if ( !map.containsKey( my_go_term.getSuperGoIds().get( 0 ) ) ) {
                throw new IllegalArgumentException( "GO-id [" + my_go_term.getSuperGoIds().get( 0 )
                        + "] not found in map" );
            }
            my_go_term = map.get( my_go_term.getSuperGoIds().get( 0 ) );
        }
        return my_go_term;
    }

    private static void getAllSuperGoTerms( final GoTerm go_term,
                                            final Map<GoId, GoTerm> goid_to_term_map,
                                            final Set<GoTerm> supers ) {
        if ( ( go_term.getSuperGoIds() != null ) && ( go_term.getSuperGoIds().size() > 0 ) ) {
            for( final GoId super_go_id : go_term.getSuperGoIds() ) {
                if ( !goid_to_term_map.containsKey( super_go_id ) ) {
                    throw new IllegalArgumentException( "GO id [" + super_go_id + "] not found in GO id to term map" );
                }
                final GoTerm super_go_term = goid_to_term_map.get( super_go_id );
                supers.add( super_go_term );
                getAllSuperGoTerms( super_go_term, goid_to_term_map, supers );
            }
        }
    }
}
