// $Id: GoNameSpace.java,v 1.1 2010/07/29 16:23:30 afodor Exp $
// FORESTER -- software libraries and applications
// for evolutionary biology research and applications.
//
// Copyright (C) 2008-2009 Christian M. Zmasek
// Copyright (C) 2008-2009 Burnham Institute for Medical Research
// All rights reserved
// 
// This library is free software; you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public
// License as published by the Free Software Foundation; either
// version 2.1 of the License, or (at your option) any later version.
//
// This library is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
// Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public
// License along with this library; if not, write to the Free Software
// Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA
//
// Contact: cmzmasek@yahoo.com
// WWW: www.phylosoft.org/forester

package org.forester.go;

public class GoNameSpace {

    public final String MOLECULAR_FUNCTION_STR = "molecular_function";
    public final String BIOLOGICAL_PROCESS_STR = "biological_process";
    public final String CELLULAR_COMPONENT_STR = "cellular_component";
    private final TYPE  _type;

    public GoNameSpace( final String type ) {
        if ( type.toLowerCase().equals( MOLECULAR_FUNCTION_STR ) ) {
            _type = TYPE.MOLECULAR_FUNCTION;
        }
        else if ( type.toLowerCase().equals( BIOLOGICAL_PROCESS_STR ) ) {
            _type = TYPE.BIOLOGICAL_PROCESS;
        }
        else if ( type.toLowerCase().equals( CELLULAR_COMPONENT_STR ) ) {
            _type = TYPE.CELLULAR_COMPONENT;
        }
        else {
            throw new IllegalArgumentException( "unknown GO namespace: " + type );
        }
    };

    public GoNameSpace( final TYPE type ) {
        _type = type;
    }

    @Override
    public boolean equals( final Object o ) {
        if ( this == o ) {
            return true;
        }
        else if ( ( o == null ) || ( o.getClass() != this.getClass() ) ) {
            return false;
        }
        else {
            return getType() == ( ( GoNameSpace ) o ).getType();
        }
    }

    public TYPE getType() {
        return _type;
    }

    public boolean isBiologicalProcess() {
        return getType() == TYPE.BIOLOGICAL_PROCESS;
    }

    public boolean isCellularComponent() {
        return getType() == TYPE.CELLULAR_COMPONENT;
    }

    public boolean isMolecularFunction() {
        return getType() == TYPE.MOLECULAR_FUNCTION;
    }

    public String toShortString() {
        switch ( _type ) {
            case BIOLOGICAL_PROCESS:
                return ( "B" );
            case CELLULAR_COMPONENT:
                return ( "C" );
            case MOLECULAR_FUNCTION:
                return ( "M" );
            default:
                throw new IllegalStateException();
        }
    }

    @Override
    public String toString() {
        switch ( _type ) {
            case BIOLOGICAL_PROCESS:
                return ( BIOLOGICAL_PROCESS_STR );
            case CELLULAR_COMPONENT:
                return ( CELLULAR_COMPONENT_STR );
            case MOLECULAR_FUNCTION:
                return ( MOLECULAR_FUNCTION_STR );
            default:
                throw new IllegalStateException();
        }
    }

    public static GoNameSpace createBiologicalProcess() {
        return new GoNameSpace( TYPE.BIOLOGICAL_PROCESS );
    }

    public static GoNameSpace createCellularComponent() {
        return new GoNameSpace( TYPE.CELLULAR_COMPONENT );
    }

    public static GoNameSpace createMolecularFunction() {
        return new GoNameSpace( TYPE.MOLECULAR_FUNCTION );
    }

    public static enum TYPE {
        MOLECULAR_FUNCTION, BIOLOGICAL_PROCESS, CELLULAR_COMPONENT
    }
}
