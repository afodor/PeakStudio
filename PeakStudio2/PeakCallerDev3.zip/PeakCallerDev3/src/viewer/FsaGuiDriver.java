package viewer;

import javax.swing.JOptionPane;

public class FsaGuiDriver
{
	public static void main(String[] args) 
	{
		try
        {
			new FsaFrame();
        }
		catch (Exception x)
        {
			x.printStackTrace();
			JOptionPane.showMessageDialog(null, "Failed to run " + x.getMessage(), 
					"Error", JOptionPane.ERROR_MESSAGE);
        }
        
	}
}
