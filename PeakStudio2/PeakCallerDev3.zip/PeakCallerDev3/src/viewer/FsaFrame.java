package viewer;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.print.PageFormat;
import java.awt.print.Printable;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.prefs.Preferences;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import javax.imageio.ImageIO;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JProgressBar;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.filechooser.FileFilter;
import org.jibble.epsgraphics.EpsGraphics2D;
import metaData.MetaData;
import dataProvider.DataProvider;
import dialogs.ABIformatDialog;
import dialogs.BinPeakDialog;
import dialogs.ClusterDialog;
import dialogs.DataSmoothingDialog;
import dialogs.DetailLevelDialog;
import dialogs.ParameterSetDialog;
import dialogs.GraphPrefDialog;
import dialogs.PeakDestroyerDialog;
import dialogs.PeakListDialog;
import dialogs.SpectraToPcaDialog;
import dialogs.StndDialog;
import tableColorChooser.ColorEditor;
import tableColorChooser.ColorRenderer;
import utils.Avevar;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Feature;
import experimentSets.FsaFileDescriptor;
import experimentSets.GuiDerivedExperimentSet;
import experimentSets.Spectra;
import experimentSets.StandardWeights;
import experimentSets.Feature.FeatureType;
import fileManager.SpectraTableModel;
import fileManager.SpectraJTable;
import fileManager.TableSorter;
import fsaFileChoosers.ExtensionFileFilter;
import fsaFileChoosers.FsaFileChooser;

public class FsaFrame extends JFrame
{
	private static final long serialVersionUID = 1L;

	public static final String PEAK_STUDIO_STRING = "Peak Studio V2.2";
	public static final float VERSION_NUMBER = 2.2f;
	public FsaPanel fsaPanel;
	private FsaFrame thisFrame;
	private SpectraTableModel spectraJTableModel;
	private SpectraJTable spectraJTable;
	private MyLoadProjectWorker myWorker;
	private MySaveProjectWorker mySaveProjectWorker;
	private MyLoadFsaFilesWorker myFsaFileWorker;
	private DumpAllSpectraWorker myDumpAllSpectraWorker;
	private JPopupMenu popUpMenu = new JPopupMenu();
	private JScrollPane sp;
	private ExtensionFileFilter filterFSA = new ExtensionFileFilter(
			"Arisa, T-RFLP .fsa", new String[]
			{ "fsa" });
	private ExtensionFileFilter filterTxt = new ExtensionFileFilter(
			"Standards .txt", new String[]
			{ "txt" });
	private ExtensionFileFilter filterSVAZ = new ExtensionFileFilter(
			"Peak Studio Project .svaz", new String[]
			{ "svaz" });
	private ExtensionFileFilter filterMetadataTxt = new ExtensionFileFilter(
			"Metadata .txt", new String[]
			{ "txt" });
	private String prefName = this.getClass() + " LastDirectory";
	private String metaName = this.getClass() + " MetaDirectory";
	private String epsName = this.getClass() + "PDFDirectory";
	private JMenuBar menuBar = new JMenuBar();
	private int epsCounter = 1;
	private int tableSaveCounter = 1;
	private int binnedMatrixCounter = 1;
	private int peakListCounter = 1;
	private int featureCounter = 1;
	private final Color TIMM_ORANGE = new Color(255,153,0);
	private Preferences prefs;
	private File directory;
	private File stnDirectory;
	private File projectFile = null;
	private GuiDerivedExperimentSet guiDerivedExperimentSet;// = new GuiDerivedExperimentSet();
	private JMenuItem closeAll, closeFile, paraSetItem, lineThickness,
			detailLevelItem, save, saveAs, standardsItem,print,smooth;
	private JMenu export;
	private List<StandardWeights> stndWeights = new ArrayList<StandardWeights>();
	private List<Spectra> spectraList = new ArrayList<Spectra>();
	private JCheckBoxMenuItem showPeakNumbers = new JCheckBoxMenuItem(
			"Show Peak Numbers");
	private JCheckBoxMenuItem showLocation = new JCheckBoxMenuItem("Mouse Over Peaks");
	private JCheckBoxMenuItem shadePeaks = new JCheckBoxMenuItem("Shade Peaks");
	private JCheckBoxMenuItem showXLocation = new JCheckBoxMenuItem("Peak X Coordinates");
	JMenuItem removePeak = new JMenuItem("Toggle peak");
	private Feature mouseOverFeature = null;
	private Spectra mouseOverSpectra = null;
	private JCheckBoxMenuItem basePair = new JCheckBoxMenuItem("BasePair");
	private JCheckBoxMenuItem display = new JCheckBoxMenuItem("Display");
	private JMenu axisMenu = new JMenu("Axis");
	private JMenuItem peakEditor = new JMenuItem("Peak Editor");
	private boolean dirty = false;
	private float detailLevel = 10;
	private MyJScrollBar horizontalBar = new MyJScrollBar(JScrollBar.HORIZONTAL);
	private MyJScrollBar vertialBar = new MyJScrollBar(JScrollBar.VERTICAL);
	private JRadioButtonMenuItem sm,raw;
	private transient int progress =0;
	
	public int getProgress() 
	{
		return progress;
	}
	
	public void setProgress(int progress) 
	{
		this.progress = progress;
	}

	public float getDetailLevel()
	{
		return detailLevel;
	}

	public void changeSpectraView(boolean selected)
	{
		this.sm.setSelected(selected);
	}
	public void setDetailLevel(float inLevel)
	{
		this.detailLevel = inLevel;
	}

	public Feature getMouseOverFeature()
	{
		return mouseOverFeature;
	}

	public void setDirty(boolean dirty)
	{
		this.dirty = dirty;
		setTitle(getTitleString());

		if (dirty)
		{
			save.setEnabled(true);
			smooth.setEnabled(true);
		}
		else
		{
			save.setEnabled(false);
			smooth.setEnabled(false);
		}
	}

	public List<String> getMetadataTitles()
	{
		HashSet<String> set = new HashSet<String>();
		for (Spectra s : this.spectraList)
			set.addAll(s.getMetadataMap().keySet());

		List<String> list = new ArrayList<String>(set);
		Collections.sort(list);

		return list;
	}

	public FsaFileDescriptor getAFileDescriptor(String name) throws Exception
	{
		List<FsaFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();

		for (FsaFileDescriptor fsa : list)
			if (fsa.getFileNamePrefix().equals(name))
				return fsa;

		return null;
	}

	public boolean isDirty()
	{
		return dirty;
	}

	private void exitIfAppropriate()
	{
		if (isDirty())
		{
			int userChoice = JOptionPane.showConfirmDialog(thisFrame,
					"Do you want to save the project before exiting?");

			if (userChoice == JOptionPane.NO_OPTION)
			{
				System.exit(0);
			} else if (userChoice == JOptionPane.YES_OPTION)
			{
				if (saveProject(false))
					System.exit(0);
			}
		} else
		{
			int userChoice = JOptionPane.showConfirmDialog(thisFrame,
					"Exit Peak Studio?", "Exit", JOptionPane.YES_NO_OPTION);

			if (userChoice == JOptionPane.YES_OPTION)
			{
				System.exit(0);
			}
		}
	}

	public FsaFrame() throws Exception
	{
		thisFrame = this;
		this.guiDerivedExperimentSet = new GuiDerivedExperimentSet();
		prefs = Preferences.userNodeForPackage(this.getClass());
		buildFrame();
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				exitIfAppropriate();
			}
		});

	}

	private String getTitleString()
	{
		String returnString = PEAK_STUDIO_STRING + " ";

		if (projectFile == null)
			return returnString;

		return returnString + " " + projectFile.getName() + (dirty ? "*" : "");
	}

	public SpectraJTable getSpectraJTable()
	{
		return spectraJTable;
	}

	public boolean peakNumbersAreSelected()
	{
		return showPeakNumbers.isSelected();
	}
	public boolean locationIsSelected()
	{
		return showLocation.isSelected();
	}
	public boolean shadePeaksIsSelected()
	{
		return shadePeaks.isSelected();
	}
	public boolean locationXisSelected()
	{
		return showXLocation.isSelected();
	}
	public boolean axesShouldBeDisplayed()
	{
		return display.isSelected();
	}

	public boolean inBasePairSpace()
	{
		return basePair.isSelected();
	}

	public void enableBasePairSpaceIfAppropriate()
	{
		boolean enableButton = true;
		int spectraCount = 0;

		for (Spectra s : spectraList)
		{
			if (s.isVisibleInTable() && s.graphIsShown())
				spectraCount++;
		}

		if (spectraCount == 0)
		{
			basePair.setEnabled(false);
			return;
		} else
			for (Spectra s : spectraList)
			{
				if (s.isVisibleInTable()
						&& s.graphIsShown()
						&& s.getFileDescriptor().getLastSetOfBasePairCalls() == null)
					enableButton = false;
			}

		if (enableButton)
		{
			basePair.setEnabled(true);
		} else
		{
			basePair.setEnabled(false);
			basePair.setSelected(false);
		}
	}

	/*
	 * not thread safe. Should only be called from the AWT thread
	 */
	public void setMouseOverPeak(Feature f, Spectra s)
	{
		this.mouseOverSpectra = s;
		this.mouseOverFeature = f;

		if (s == null)
		{
			removePeak.setEnabled(false);
		} else
		{
			removePeak.setEnabled(true);
			s.clearImageCache();
		}

	}

	public MyJScrollBar getHorizontalBar()
	{
		return horizontalBar;
	}

	public MyJScrollBar getVertialBar()
	{
		return vertialBar;
	}

	public static class MyJScrollBar extends JScrollBar
	{
		private static final long serialVersionUID = 859074005691049833L;

		public MyJScrollBar(int orientation)
		{
			super(orientation);
		}

		private boolean fireListener = false;

		public void setFireListener(boolean fireListener)
		{
			this.fireListener = fireListener;
		}

		public boolean getFireListener()
		{
			return fireListener;
		}

	}

	private void buildFrame() throws Exception
	{
		this.setTitle(getTitleString());
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setResizable(true);
		this.setSize(1000, 600);
		this.setLocationRelativeTo(null);
		this.setBackground(Color.WHITE);
		URL imageUrl = this.getClass().getResource("PSlogo.png");
		Image logoImage = ImageIO.read(imageUrl);
		this.setIconImage(logoImage);
		fsaPanel = new FsaPanel(this);
		buildFileMangerTable();
		buildMenuBar();
		buildPopUpMenu();
		JPanel innerPanel = new JPanel();
		innerPanel.setLayout(new BorderLayout());
		innerPanel.add(fsaPanel, BorderLayout.CENTER);
		innerPanel.add(vertialBar, BorderLayout.EAST);
		innerPanel.add(horizontalBar, BorderLayout.SOUTH);

		vertialBar.setVisibleAmount(100);
		horizontalBar.setVisibleAmount(100);

		horizontalBar.addAdjustmentListener(new AdjustmentListener()
		{
			public void adjustmentValueChanged(AdjustmentEvent e)
			{
				MyJScrollBar bar = horizontalBar;

				if (bar.fireListener)
				{
					float range = bar.getMaximum() - bar.getVisibleAmount();
					fsaPanel.setXPanFactor(bar.getValue() / range);
					fsaPanel.forceRedraw();
				}
			}
		});

		vertialBar.addAdjustmentListener(new AdjustmentListener()
		{
			public void adjustmentValueChanged(AdjustmentEvent e)
			{
				MyJScrollBar bar = vertialBar;

				if (bar.fireListener)
				{
					float range = bar.getMaximum() - bar.getVisibleAmount();
					fsaPanel.setYPanFactor(bar.getValue() / range);
					fsaPanel.forceRedraw();
				}
			}
		});

		JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
				innerPanel, sp);
		splitPane.setOneTouchExpandable(true);
		splitPane.setDividerLocation(415);
		this.setBackground(Color.white);
		this.setPreferredSize(fsaPanel.getPreferredSize());
		splitPane.setResizeWeight(1.0);
		this.getContentPane().add(splitPane, BorderLayout.CENTER);
		this.pack();
		this.setVisible(true);

	}

	private void buildPopUpMenu()
	{
		JMenuItem zoomOut = new JMenuItem("Zoom_Out");
		zoomOut.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				fsaPanel.resetZoomOut();
			}
		});
		zoomOut.setEnabled(true);

		removePeak.setEnabled(false);
		removePeak.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				removePeak();
			}
		});
		popUpMenu.addSeparator();
		popUpMenu.add(zoomOut);
		popUpMenu.addSeparator();
		popUpMenu.add(removePeak);

	}

	/*
	public void autoAdjustPeaks(Spectra stnd)
	{
		
		List<Feature> allFeatures = stnd.getFeatureList();
		List<Feature> filterFeatures = new ArrayList<Feature>();
		float stdThreshold = 3.1f;
		List<Float> areas = new ArrayList<Float>();
		for(Feature f: allFeatures)
		{
			if(!f.getFeatureType().equals(Feature.FeatureType.NON_PEAK) && f.getAUC(true) > 1)
			{
				filterFeatures.add(f);
				areas.add((float)f.getAUC(true));
				//System.out.println(f.getAUC(true));
			}
		}
		
		Avevar av = new Avevar(areas);
		double mean = av.getAve();
		double sd = Math.sqrt(av.getVar());
		int Peakcount = 0;
		for(Feature f: allFeatures)
		{
			//double z = (f.getAUC(true)-mean)/sd;
			f.setZscore((f.getAUC(true)-mean)/sd);
			if(Math.abs(f.getZscore()) <= stdThreshold && f.getAUC(true) > 1)
			{
				Peakcount++;
				f.setFeatureType(Feature.FeatureType.PEAK);
				//System.out.println(count+" "+f.getFeatureType()+" "+z);
			}
			else
				f.setFeatureType(Feature.FeatureType.NON_PEAK);
		}
		
		List<Feature> allFeatures = stnd.getFeatureList();
		float stdThreshold = 3.1f;
		for(Feature f: allFeatures)
		{
			if(Math.abs(f.getZscore()) <= stdThreshold && f.getAUC(true) > 1)
			{
				f.setFeatureType(Feature.FeatureType.PEAK);
			}
			else
				f.setFeatureType(Feature.FeatureType.NON_PEAK);
		}
		
		//fsaPanel.forceRedraw();
		//spectraJTable.getModel().fireTableDataChanged();
		//dirty = true;
	}*/
	
	private void removePeak()
	{
		try
		{
			if (mouseOverFeature != null)
			{
				if (mouseOverFeature.getFeatureType() == Feature.FeatureType.PEAK)
					mouseOverFeature
							.setFeatureType(Feature.FeatureType.USER_REMOVED);
				else if(mouseOverFeature.getFeatureType() == Feature.FeatureType.USER_REMOVED)
					mouseOverFeature.setFeatureType(Feature.FeatureType.USER_ADDED);
				else
					mouseOverFeature.setFeatureType(Feature.FeatureType.PEAK);

				if (mouseOverSpectra.getIsStandard())
				{
					AbstractFSAFileDescriptor fsa = mouseOverSpectra
							.getFileDescriptor();

					if (fsa.getSizeStandards() != null)
						fsa.generateBasePairCalls(false);
				}

				fsaPanel.forceRedraw();
				spectraJTable.getModel().fireTableDataChanged();
				mouseOverSpectra = null;
				mouseOverFeature = null;
				removePeak.setEnabled(false);
				dirty = true;
			}
		} catch (Exception ex)
		{
			JOptionPane.showMessageDialog(thisFrame, "Error: "
					+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
	}

	private void buildMenuBar()
	{
		createFileMenu();
		createEditMenu();
		createViewMenu();
		createAxisMenu();
		createAnalysisMenu();
		createTreeViewerMenu();
		createHelpMenu();
		this.add(menuBar, BorderLayout.NORTH);
	}

	public JPopupMenu getPopUpMenu()
	{
		return this.popUpMenu;
	}

	private void createViewMenu()
	{
		JMenu viewMenu = new JMenu("View");
		viewMenu.setMnemonic('V');

		viewMenu.add(showPeakNumbers);

		showPeakNumbers.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if (fsaPanel != null)
					fsaPanel.forceRedraw();
			}
		});
		showPeakNumbers.setMnemonic('B');
		showPeakNumbers.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_B,
				ActionEvent.CTRL_MASK));
		
		viewMenu.add(showLocation);
		showLocation.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(fsaPanel != null)
					fsaPanel.forceRedraw();
			}
			
		});
		showLocation.setMnemonic('V');
		showLocation.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,ActionEvent.CTRL_MASK));
		showLocation.setSelected(true);
		viewMenu.add(shadePeaks);
		shadePeaks.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(fsaPanel != null)
					fsaPanel.forceRedraw();
			}
			
		});
		shadePeaks.setMnemonic('D');
		shadePeaks.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,ActionEvent.CTRL_MASK));
		shadePeaks.setSelected(true);
		viewMenu.addSeparator();
		viewMenu.add(showXLocation);
		viewMenu.addSeparator();
		showXLocation.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(fsaPanel != null)
					fsaPanel.forceRedraw();
			}
		
		});
		showXLocation.setMnemonic('J');
		showXLocation.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,ActionEvent.CTRL_MASK));
		lineThickness = new JMenuItem("Line Thickness");
		lineThickness.setMnemonic('U');
		lineThickness.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_U,
				ActionEvent.CTRL_MASK));
		lineThickness.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				displayPrefDialog();
			}
		});
		viewMenu.add(lineThickness);

		detailLevelItem = new JMenuItem("Detail level");
		detailLevelItem.setMnemonic('D');
		detailLevelItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_D,
				ActionEvent.CTRL_MASK));

		detailLevelItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JDialog dialog = new DetailLevelDialog(thisFrame);
				dialog.setVisible(true);

			};
		});

		//viewMenu.add(detailLevelItem);
		viewMenu.addSeparator();
		JMenuItem setXZoom = new JMenuItem("Set X zoom");
		setXZoom.setMnemonic('X');
		setXZoom.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,
				ActionEvent.CTRL_MASK));

		setXZoom.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				float maxZoomFactor = fsaPanel.getMaxXZoomFactor();

				String returnVal = JOptionPane
						.showInputDialog(
								thisFrame,
								"Set the X zoom factor\n"
										+ "(Anything other than a number between 1 and "
										+ maxZoomFactor + " will be ignored!",
								new Float(fsaPanel.getxZoomFactor()));

				if (returnVal == null)
					return;

				Float f = null;
				try
				{
					f = Float.parseFloat(returnVal);
				} catch (NumberFormatException ex)
				{
					// user just being obnoxious
					JOptionPane.showMessageDialog(thisFrame, "Error: "
							+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}

				if ( f==null || f < 1 || f > maxZoomFactor)
					return;

				fsaPanel.setxZoomFactor(f);
			}
		});
		viewMenu.add(setXZoom);

		JMenuItem setYZoom = new JMenuItem("Set Y zoom");
		setYZoom.setMnemonic('Y');
		setYZoom.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y,
				ActionEvent.CTRL_MASK));

		setYZoom.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				float maxZoomFactor = fsaPanel.getMaxYZoomFactor();

				String returnVal = JOptionPane
						.showInputDialog(
								thisFrame,
								"Set the Y zoom factor\n"
										+ "(Anything other than a number between 1 and "
										+ maxZoomFactor+ " will be ignored!",
								new Float(fsaPanel.getyZoomFactor()));

				if (returnVal == null)
					return;

				Float f = null;
				try
				{
					f = Float.parseFloat(returnVal);
				} catch (NumberFormatException ex)
				{
					// user just being obnoxious
					JOptionPane.showMessageDialog(thisFrame, "Error: "
							+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}

				if (f==null ||f < 1 || f > maxZoomFactor)
					return;

				fsaPanel.setyZoomFactor(f);
			}
		});
		viewMenu.add(setYZoom);

		JMenuItem zoomOut = new JMenuItem("Zoom Out");
		
		zoomOut.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				fsaPanel.resetZoomOut();
				
			}
		});
		zoomOut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				ActionEvent.CTRL_MASK));
		viewMenu.add(zoomOut);
		viewMenu.addSeparator();
		ButtonGroup bgGroup = new ButtonGroup();
		raw = new JRadioButtonMenuItem("Raw");
		raw.setSelected(true);
		raw.setMnemonic('R');
		raw.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.CTRL_MASK));
		bgGroup.add(raw);
		raw.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				try
				{
					if(thisFrame.getSpectraList().size() > 0)
						
					{
						for(Spectra s: thisFrame.getSpectraList())
						{
							s.setShowSmoothed(false);
							if(!s.getIsStandard())
								s.callFeatures();
							if(s.getIsStandard())
								s.resetStndHeights(false);
						}
							
						thisFrame.getSpectraJTable().getModel().fireTableDataChanged();
						fsaPanel.forceRedraw();
					}
					
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(thisFrame, "Error: "
							+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		sm = new JRadioButtonMenuItem("Smoothed");
		sm.setSelected(false);
		sm.setMnemonic('R');
		sm.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R, ActionEvent.ALT_MASK));
		bgGroup.add(sm);
		sm.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				try
				{
					boolean smoothed = true;
					for(Spectra s: thisFrame.getSpectraList())
					{
						if(!s.getIsSmoothed())
							smoothed = false;
					}
					if(smoothed)
					{
						for(Spectra s: thisFrame.getSpectraList())
						{
							s.setShowSmoothed(true);
							if(!s.getIsStandard())
								s.callFeatures();
							if(s.getIsStandard())
								s.resetStndHeights(true);
						}
						thisFrame.getSpectraJTable().getModel().fireTableDataChanged();
						fsaPanel.forceRedraw();
					}
					else
					{
						sm.setSelected(false);
						raw.setSelected(true);
						smoothingNotAvailable();
						new DataSmoothingDialog(thisFrame).setVisible(true);
						
					}
					
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(thisFrame, "Error: "
							+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
					
				}
				
				
			}
		});
		viewMenu.add(raw);
		viewMenu.add(sm);
		menuBar.add(viewMenu);
	}

	// file manager table
	private void buildFileMangerTable()
	{
		spectraJTableModel = new SpectraTableModel(fsaPanel);
		spectraJTable = new SpectraJTable(thisFrame, spectraJTableModel);
		spectraJTable.initializeTable();
		TableSorter tableSorter = new TableSorter(spectraJTableModel, this);
		tableSorter.addMouseListenerToHeaderInTable(spectraJTable);
		spectraJTable.setModel(spectraJTableModel);
		spectraJTable
				.setPreferredScrollableViewportSize(new Dimension(800, 75));
		spectraJTable.setGridColor(Color.BLACK);
		spectraJTable.setDefaultRenderer(Color.class, new ColorRenderer(true));
		spectraJTable.setDefaultEditor(Color.class, new ColorEditor());
		spectraJTable.setCellSelectionEnabled(false);
		spectraJTable.setRowSelectionAllowed(true);
		spectraJTable.getTableHeader().setReorderingAllowed(true);
		sp = new JScrollPane(spectraJTable);
	}

	public void handleKeyType(KeyEvent e)
	{

		if ( ! e.isAltDown() )
			return;
		if (mouseOverFeature == null || mouseOverSpectra == null)
			return;
		int index = -1;

		List<Feature> list = mouseOverSpectra.getFeatureList();

		for (int x = 0; x < list.size(); x++)
			if (mouseOverFeature == list.get(x))
				index = x;

		if (index == -1)
			return;
		
		//number checks (730 and 172) put in for mac which otherwise ignores alts
		if (e.getKeyChar() == 'K' || e.getKeyChar() == 'k' || (int)e.getKeyChar() == 730)
		{
			index--;
			if (index >= 0)
				setMouseOverPeak(list.get(index), mouseOverSpectra);

			fsaPanel.forceRedraw();

		} 
		else if (e.getKeyChar() == 'L' || e.getKeyChar() == 'l' || (int)e.getKeyChar() == 172)
		{
			index++;

			if (index < list.size())
				setMouseOverPeak(list.get(index), mouseOverSpectra);

			fsaPanel.forceRedraw();
		}
		
	}
	
	private void saveJTable() throws IOException
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(".txt");
		chooser.setSelectedFile(new File("Table_data"+tableSaveCounter++ +".txt"));
		chooser.setCurrentDirectory(new File(prefs.get(prefName, "")));
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = chooser.getSelectedFile();
			if(!f.getAbsolutePath().endsWith(".txt"))
			{
				if(f.getAbsolutePath().lastIndexOf('.') > -1)
				{
					String newPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf('.'));
					File f2 = new File(newPath+".txt");
					f = f2;
				}
				else
				{
					f = new File(f.getAbsoluteFile()+".txt");
				}
			}
			
			BufferedWriter out = new BufferedWriter(new FileWriter(f));
			for(int col=0; col<spectraJTable.getColumnCount(); col++)
			{
				out.write(spectraJTable.getColumnName(col)+"\t");
			}
			out.write("\n");
			for(int row=0; row < spectraJTable.getRowCount(); row++ )
			{
				for(int col=0; col < spectraJTable.getColumnCount(); col++)
				{
					if(spectraJTable.getValueAt(row, col) instanceof Color)
					{
						Color c = (Color)spectraJTable.getValueAt(row, col);
						out.write("("+c.getRed()+","+c.getGreen()+","+c.getBlue()+")");
						out.write("\t");
					}
					else
					{
						String value =  spectraJTable.getValueAt(row, col).toString();
						out.write(value);
						out.write("\t");
					}
				}
				out.write("\n");
			}
			out.close();
		}
		
	}
	private void saveEPS()
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(".eps");
		chooser.setSelectedFile(new File("Myeps" + epsCounter++ + ".eps"));
		chooser.setCurrentDirectory(new File(prefs.get(epsName, "")));
		chooser.setFileFilter(new FileFilter()
		{
			public String getDescription()
			{
				return "Encapsulated PostScript file";
			}

			public boolean accept(File f)
			{
				if( f.isDirectory() || f.getName().toLowerCase().endsWith("eps"))
					return true;
				
				return false;
			}
		});
		
		int returnVal = chooser.showSaveDialog(thisFrame);
		
		if(returnVal == JFileChooser.APPROVE_OPTION)
		{
			int choice = JOptionPane.YES_OPTION;
			File file = chooser.getSelectedFile();
			if( file.exists())
			{
				choice = JOptionPane.showConfirmDialog(this, 
						file.getName() + " exists.  Replace?", "Replace?", 
						JOptionPane.YES_NO_OPTION);
			}
			
			if( choice == JOptionPane.YES_OPTION)
			{
				File parentDir = file.getParentFile();
				
				if( parentDir != null)
					prefs.put(epsName, parentDir.getAbsolutePath());
				
				try
				{	
					EpsGraphics2D g = new EpsGraphics2D();
				    g.setAccurateTextMode(false);
				    fsaPanel.paintAsVectors(g);
				    
				    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
				    writer.write(g.toString());
				    writer.flush();  writer.close();
				    g.dispose();
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(this, "Could not save pdf "  
							+ ex.getMessage());
				}
			}
		}

	}

	private void createFileMenu()
	{
		JMenu fileMenu = new JMenu("File");
		fileMenu.setMnemonic('F');
		JMenuItem openSpectra = new JMenuItem("Open Spectra");
		openSpectra.setMnemonic('O');
		openSpectra.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,
				ActionEvent.CTRL_MASK));
		openSpectra.setEnabled(true);

		JMenuItem openProject = new JMenuItem("Open Project");
		openProject.setMnemonic('P');
		openProject.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,
				ActionEvent.CTRL_MASK));
		openProject.setEnabled(true);

		saveAs = new JMenuItem("Save_AS");
		saveAs.setEnabled(false);
		save = new JMenuItem("Save");
		save.setMnemonic('S');
		save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,
				ActionEvent.CTRL_MASK));
		save.setEnabled(false);
		JMenuItem exitItem = new JMenuItem("Exit");
		exitItem.setMnemonic(KeyEvent.VK_ENTER);
		exitItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER,
				ActionEvent.CTRL_MASK));

		closeFile = new JMenuItem("Remove Sample(s)");
		closeFile.setMnemonic('C');
		closeFile.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,
				ActionEvent.CTRL_MASK));
		closeFile.setEnabled(false);
		closeAll = new JMenuItem("Close Project");
		closeAll.setMnemonic('A');
		closeAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,
				ActionEvent.CTRL_MASK));
		closeAll.setEnabled(false);
		export = new JMenu("Export");
		export.setEnabled(false);
		JMenuItem pic = new JMenuItem("PNG");

		pic.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				fsaPanel.takePicture();
			}
		});
		JMenu _import = new JMenu("Import");
		_import.setEnabled(true);
		JMenuItem _metaData = new JMenuItem("Metadata");

		_metaData.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				loadMetaData();
			}
		});

		pic.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_G,
				ActionEvent.ALT_MASK));
		export.add(pic);
		
		JMenuItem exportEPS = new JMenuItem("Encapsulated PostScript");
		exportEPS.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				saveEPS();
			}
		});
		
		exportEPS.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
				ActionEvent.ALT_MASK));
		export.add(exportEPS);
		
		JMenuItem exportJtable = new JMenuItem("Table View");
		exportJtable.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					saveJTable();
				}
				catch(Exception io)
				{
					JOptionPane.showMessageDialog(thisFrame, "Error in Saving Table Information " + io.getMessage());
					io.printStackTrace();
				}
			}
		});
		exportJtable.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_J,ActionEvent.ALT_MASK));
		export.add(exportJtable);
		JMenuItem exportBinMatrix = new JMenuItem("Binned Peak Matrix");
		exportBinMatrix.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				List<? extends AbstractFSAFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();
				boolean stndCheck = true;
				for (AbstractFSAFileDescriptor fsa : list)
				{
					if(fsa.getStndWeightsObject() == null || fsa.getSizeStandards().isEmpty())
						stndCheck = false;
				}
				if(stndCheck)
					outPutBinnedPeaksMatrix();
				else
				{
					standardsWarning();
					displayStndDialog();
				}
				
			}
			
		});
		exportBinMatrix.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_M,ActionEvent.ALT_MASK));
		export.add(exportBinMatrix);
		JMenuItem expPeakList = new JMenuItem("All Peaks");
		expPeakList.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				PeakListDialog ps = new PeakListDialog(thisFrame);
			}
		});
		expPeakList.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_COMMA,ActionEvent.ALT_MASK));
		export.add(expPeakList);
		JMenuItem exportFeatures = new JMenuItem("All Features");
		exportFeatures.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				outPutFeatures();
			}
		});
		exportFeatures.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_BACK_SLASH,ActionEvent.ALT_MASK));
		//export.add(exportFeatures);
		
		JMenuItem exportSpectraData = new JMenuItem("QC Files");
		exportSpectraData.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_PERIOD,ActionEvent.ALT_MASK));
		exportSpectraData.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				 JFileChooser chooser = new JFileChooser(); 
				 File spectraExportDirectory= new File(prefs.get("spectraExportDir", ""));
				 chooser.setCurrentDirectory(spectraExportDirectory);
				 chooser.setDialogTitle("Choose a directory");
				 chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				 chooser.setAcceptAllFileFilterUsed(false);
				 if (chooser.showOpenDialog(thisFrame) == JFileChooser.APPROVE_OPTION) 
				 { 
					 prefs.put("spectraExportDir", chooser.getSelectedFile().getAbsolutePath());
					 MyProgressBarDialog mpd = new MyProgressBarDialog("Exporting Spectra",getSpectraList().size());
					 mpd.getCancelButton().addActionListener(new ActionListener()
					 {
						 @Override
						public void actionPerformed(ActionEvent e)
						 {
							myDumpAllSpectraWorker.cancel(true);
							
						}
					 });
					 myDumpAllSpectraWorker = new DumpAllSpectraWorker(mpd.getProgressBar(),mpd,chooser.getSelectedFile());
					 myDumpAllSpectraWorker.execute();
					 mpd.setVisible(true);
				 }
			}
		});
		export.add(exportSpectraData);
		
		JMenuItem abiFormat = new JMenuItem("Sizing Table");
		abiFormat.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_0,ActionEvent.ALT_MASK));
		abiFormat.addActionListener(new ActionListener()
		{
			
			@Override
			public void actionPerformed(ActionEvent e)
			{
				List<? extends AbstractFSAFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();
				boolean stndCheck = true;
				for (AbstractFSAFileDescriptor fsa : list)
				{
					if(fsa.getStndWeightsObject() == null || fsa.getSizeStandards().isEmpty())
						stndCheck = false;
				}
				if(stndCheck)
					new ABIformatDialog(thisFrame);//add in export abi dialog here
				else
				{
					standardsWarning();
					displayStndDialog();
				}
				
				
			}
		});
		export.add(abiFormat);
		
		_import.add(_metaData);
		openSpectra.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				chooseFsaFiles();
			}
		});
		openProject.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				chooseProjectFile();
			}
		});

		saveAs.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				saveProject(true);
			}
		});

		save.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				saveProject(false);
			}

		});

		closeFile.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				closeDescriptorFile(spectraJTable.getSelectedRows());
				setDirty(true);
			}
		});

		closeAll.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				closeAllFiles(true);
			}
		});

		exitItem.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				exitIfAppropriate();
			};
		});

		print = new JMenuItem("Print");
		
		print.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,
				ActionEvent.ALT_MASK));
		
		print.addActionListener(new ActionListener()
		{
			
			public void actionPerformed(ActionEvent e)
			{
				printGraph();
			}
		});
		print.setEnabled(false);
		
		menuBar.add(fileMenu);
		fileMenu.add(openSpectra);
		fileMenu.add(openProject);
		fileMenu.add(save);
		fileMenu.add(saveAs);
		fileMenu.addSeparator();
		fileMenu.add(_import);
		fileMenu.addSeparator();
		fileMenu.add(export);
		fileMenu.addSeparator();
		fileMenu.add(closeFile);
		fileMenu.add(closeAll);
		
		// printing is crashing the program right now
		// todo:  At some point, we should debug this..
		//fileMenu.add(print);
		
		fileMenu.addSeparator();
		fileMenu.add(exitItem);
	}
	private class DumpAllSpectraWorker extends SwingWorker<Void, Void>
	{
		private JProgressBar jbar;
		private JDialog jdialog;
		private File directory;
		private List<File> exportedFiles = new ArrayList<File>();
		public DumpAllSpectraWorker(JProgressBar jbar, JDialog dialog,File directory)
		{
			this.jbar = jbar;
			this.jdialog = dialog;
			this.directory = directory;
		}
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = getSpectraList().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		protected Void doInBackground() throws Exception 
		{
			try
			{
				int progress = 0;
				for(Spectra s: getSpectraList())
				{
					if(isCancelled())
						return null;
					File exFile = new File(this.directory + File.separator + s.getName() + "_" + 
											s.getDataChannel() + "_EXPORT.txt");
					exportedFiles.add(exFile);
					BufferedWriter writer = new BufferedWriter(new FileWriter(exFile));
					DataProvider<Float> basepairCalls = s.getBasePairCalls();
					DataProvider<Short> data = s.getData();
					s.resetFeatureCrawler();
					
					writer.write("index\t" + 
							(basepairCalls == null ? "":"basepair\t") + "data\tfeature\n");
					
					for( int x=0;x < data.getLength(); x++)
					{
						writer.write(x + "\t");
						
						if( basepairCalls != null)
							writer.write(basepairCalls.get(x) + "\t");
						
						writer.write( data.get(x) + "\t" );
						
						Feature f = s.getAFeatureFromCumulativeCralwer(x);
						
						writer.write( ((f==null) ? "-" : f.getFeatureType()) + "\n");
					}
					
					writer.flush();  writer.close();
					SwingUtilities.invokeLater(new SetterClass(progress));
					progress++;
				}
				
			}
			catch(Exception ex)
			{
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				JOptionPane.showMessageDialog(thisFrame, "Error " + ex.getMessage());
				ex.printStackTrace();
			}
			return null;
		}
		@Override
		protected void done() 
		{
			this.jdialog.dispose();
			if(isCancelled())
			{
				for(File f: exportedFiles)
					f.delete();	
			}
		}
	}
	
	private void outPutFeatures()
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(".txt");
		chooser.setSelectedFile(new File("Spectra_Features"+featureCounter++ +".txt"));
		chooser.setCurrentDirectory(new File(prefName, ""));
		if(chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = chooser.getSelectedFile();
			if(!f.getAbsolutePath().endsWith(".txt"))
			{
				if(f.getAbsolutePath().lastIndexOf('.') > -1)
				{
					String newPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf('.'));
					File f2 = new File(newPath+".txt");
					f = f2;
				}
				else
				{
					f = new File(f.getAbsoluteFile()+".txt");
				}
			}
			try
			{
				writeOutFeatures(f);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, e.getMessage() + "\n"
						+ "Saving File Failed\n"
						+ "Check to make sure approiate files are open\n"
						+ "Restaring PeakStudio is recommended\n");
			}
			
		}
		
	}
	
	private void writeOutFeatures(File f) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(f));
		List<Spectra> spectra = getSpectraList();
		writer.write("Sample"+"\t"+"Channel_Number"+"\t"+"Type"+"\t"+"Index"+"\t"
				+"Base_Pair"+"\t"+"Feature"+"\t"+"Area(Index)"+"\t"+"Area(BasePair)"+"\n");
		
		for(Spectra s : spectra)
		{
			DataProvider<Float> bpCalls = s.getBasePairCalls();
			List<Feature> fList = s.getFeatureList();
			if(!s.getIsStandard())
			{
				DataProvider<Short> data = s.getData();
				for(int index=0; index<data.getLength(); index++)
				writer.write(index+"\t"+data.get(index)+"\n");
				//for(Feature ft: fList)
				//{
					//DataProvider<Short> data = ft.getParentSpectra().getData();
					//for(int index=0; index<data.getLength(); index++)
					//writer.write(index+"\t"+data.get(index)+"\n");
				/*String type = (s.getIsStandard() ? "Standard" : "Data");
				writer.write(s.getName()+"\t"+s.getDataChannel()+"\t"+type+"\t");
				writer.write(ft.getIndexOfHighestPeak()+"\t"+bpCalls.get(ft.getIndexOfHighestPeak())+"\t"+ft.getFeatureType()+"\n");*/
						//ft.getAUC(true)+"\t"+ft.getAUC(false)+"\n");
				//}
			}
		}
		writer.flush(); writer.close();
		
	}
	private void printGraph()
	{
		PrinterJob printJob = PrinterJob.getPrinterJob();
		printJob.setPrintable(new Printable()
		{
			@Override
			public int print(Graphics graphics, PageFormat pageFormat, int pageIndex)
					throws PrinterException
			{
				try
				{
					Graphics2D g2d = (Graphics2D) graphics;
					g2d.translate(pageFormat.getImageableX(), pageFormat.getImageableY());
					
					fsaPanel.paint(g2d);
					g2d.dispose();
					
					return PAGE_EXISTS;
				}
				catch(Exception ex)
				{
					JOptionPane.showMessageDialog(thisFrame, "Could not print " + ex.getMessage());
					ex.printStackTrace();
				}
				
				return NO_SUCH_PAGE;
			}
		});
		
			try
			{
				boolean userSaysPrint = printJob.printDialog();
				
				if( userSaysPrint )
					printJob.print();
			}
			catch(Exception ex)
			{
				JOptionPane.showMessageDialog(thisFrame, "Could not print " + ex.getMessage());
				ex.printStackTrace();
			}
	}

	public void setSelectionSensitiveMenuItemsEnabled(boolean b)
	{
		this.paraSetItem.setEnabled(b);
		//this.peakEditor.setEnabled(b);
	}

	private void createEditMenu()
	{
		JMenu editMenu = new JMenu("Edit");
		editMenu.setMnemonic('E');

		paraSetItem = new JMenuItem("Parameter Set");
		paraSetItem.setMnemonic('Q');
		paraSetItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
				ActionEvent.CTRL_MASK));

		paraSetItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				displayParameterSetDialog();
			}
		});
		paraSetItem.setEnabled(false);

		standardsItem = new JMenuItem("Standards");
		standardsItem.setMnemonic('W');
		standardsItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_W,
				ActionEvent.CTRL_MASK));
		standardsItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				displayStndDialog();
			}
		});

		standardsItem.setEnabled(true);

		peakEditor.setMnemonic('R');
		peakEditor.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_R,
				ActionEvent.CTRL_MASK));
		peakEditor.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				new PeakDestroyerDialog(thisFrame).setVisible(true);
			}
		});
		peakEditor.setEnabled(false);

		smooth = new JMenuItem("Data Smoothing");
		smooth.setMnemonic('-');
		smooth.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_SPACE,ActionEvent.CTRL_MASK));
		smooth.addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0)
			{
				boolean toSmooth = true;
				for(Spectra s: thisFrame.getSpectraList())
				{
					if(s.getFileDescriptor().getStndWeightsObject() == null)
						toSmooth = false;
				}
				if(toSmooth)
					new DataSmoothingDialog(thisFrame).setVisible(true);
				else
				{
					thisFrame.standardsWarning();
				}
				
			}
		});
		smooth.setEnabled(false);
		editMenu.add(paraSetItem);
		editMenu.add(standardsItem);
		editMenu.add(smooth);
		// editMenu.add(backgroundCorrect);
		//editMenu.add(peakEditor);
		menuBar.add(editMenu);

	}

	private void createHelpMenu()
	{
		JMenu helpMenu = new JMenu("Help");
		helpMenu.setMnemonic('H');
		JMenuItem aboutItem = new JMenuItem("About");
		aboutItem.setMnemonic('I');
		aboutItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I,
				ActionEvent.CTRL_MASK));
		aboutItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				aboutDialogBox();
			}
		});
		menuBar.add(helpMenu);
		helpMenu.add(aboutItem);
	}

	private void createAxisMenu()
	{

		axisMenu.setMnemonic('A');

		axisMenu.add(display);
		axisMenu.addSeparator();
		axisMenu.add(basePair);
		axisMenu.setEnabled(false);
		basePair.setEnabled(false);

		ActionListener forceRefresh = new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				setCursor(new Cursor(Cursor.WAIT_CURSOR));
				fsaPanel.forceRedraw();
				setDirty(true);
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			}
		};

		display.addActionListener(forceRefresh);

		basePair.addActionListener(forceRefresh);

		basePair.setMnemonic('K');
		basePair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_K,
				ActionEvent.CTRL_MASK));
		menuBar.add(axisMenu);
	}

	/******************************************
	 * Removed all clustering from Analysis Menu,
	 * may be added back in later versions
	 ******************************************/
	private void createAnalysisMenu()
	{
		JMenu analysis = new JMenu("Analysis");
		analysis.setMnemonic('Z');
		JMenuItem clusterItem = new JMenuItem("ARISA_Cluster");
		clusterItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (getStndWeightsList().isEmpty())
				{
					standardsWarning();
					displayStndDialog();
				} else
				{
					ClusterDialog cDog = new ClusterDialog(thisFrame);
					cDog.setDisplay();
					cDog.setVisible(true);
				}
			}
		});
		clusterItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1,
				ActionEvent.CTRL_MASK));
		clusterItem.setEnabled(true);
		//analysis.add(clusterItem);
		//analysis.addSeparator();

		JMenuItem trflpItem = new JMenuItem("TRFLP_Analysis");
		trflpItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(thisFrame, "Not implemented");
			}
		});
		trflpItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_2,ActionEvent.CTRL_MASK));
		trflpItem.setEnabled(true);
		//analysis.add(trflpItem);
		//analysis.addSeparator();

		JMenuItem trflpSetUpFileItem = new JMenuItem(
				"TRFLP_Analysis_Using_Setup_File");
		trflpSetUpFileItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_3,ActionEvent.CTRL_MASK));
		trflpSetUpFileItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(thisFrame, "Not implemented");
			}
		});
		trflpSetUpFileItem.setEnabled(true);

		//analysis.add(trflpSetUpFileItem);
		//analysis.addSeparator();
		JMenuItem pcaSetUp = new JMenuItem("PCA");
		pcaSetUp.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_4,ActionEvent.CTRL_MASK));
		pcaSetUp.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				if (getStndWeightsList().isEmpty())
				{
					standardsWarning();
					displayStndDialog();
				} else
				{
					displaySpectraToPcaDialog();
				}
			}
		});
		pcaSetUp.setEnabled(true);
		analysis.add(pcaSetUp);
		menuBar.add(analysis);

	}

	/***********************************************
	 * Removed from Menu Bar,
	 * may be added back in later version
	 ************************************************/
	private void createTreeViewerMenu()
	{
		JMenu treeViewer = new JMenu("Tree Viewer");
		treeViewer.setMnemonic('T');
		JMenuItem clusterItem = new JMenuItem("Archaeopteryx_Tree_Viewer");
		clusterItem.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				org.forester.archaeopteryx.Archaeopteryx.main(new String[0]);
			}
		});
		clusterItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_T,
				ActionEvent.CTRL_MASK));
		clusterItem.setEnabled(true);
		//menuBar.add(treeViewer);
		treeViewer.add(clusterItem);

	}
	
	
	public JTable getTable()
	{
		return this.spectraJTable;
	}

	public FsaPanel getFsaPanel()
	{
		return this.fsaPanel;
	}

	public GuiDerivedExperimentSet getExperimentSet()
	{
		return guiDerivedExperimentSet;
	}

	public StandardWeights getStandardWeights()
	{
		if (!stndWeights.isEmpty())
		{
			if (stndWeights.size() > 1)
				return stndWeights.get(stndWeights.size() - 1);
			else
				return stndWeights.get(0);
		} else
			return null;
	}

	public List<StandardWeights> getStndWeightsList()
	{
		return stndWeights;
	}

	public boolean isInStndWeightsList(StandardWeights sw)
	{
		boolean flag = false;
		if (stndWeights.isEmpty())
			return false;
		for (StandardWeights s : stndWeights)
		{
			if (sw.getName().equals(s.getName()))
				flag = true;
		}
		return flag;
	}

	public void setStndWeightsList(List<StandardWeights> list)
	{
		stndWeights = list;
	}

	public List<Spectra> getSpectraList()
	{
		return this.spectraList;
	}

	public List<Spectra> getNonStndSpectraList()
	{
		List<Spectra> list = new ArrayList<Spectra>();
		for (Spectra s : this.spectraList)
		{
			if (!s.getIsStandard())
				list.add(s);
		}
		return list;
	}

	public List<Spectra> getStndSpectraList()
	{
		List<Spectra> list = new ArrayList<Spectra>();
		for (Spectra s : this.spectraList)
		{
			if (s.getIsStandard())
				list.add(s);
		}
		return list;
	}

	/**************************************************************************/
	/*********************************************
	 * Methods
	 * 
	 * @throws Exception
	 ********************************************/
	private void displayStndDialog()
	{
		StndDialog stndDialog = new StndDialog(thisFrame);
		stndDialog.setVisible(true);
	}

	private void displayPrefDialog()
	{
		GraphPrefDialog pd = new GraphPrefDialog(this);
		pd.setDialog();
		pd.setVisible(true);
	}

	private void displaySpectraToPcaDialog()
	{
		SpectraToPcaDialog spca = new SpectraToPcaDialog(thisFrame);
		spca.setUpDialog();
		spca.setVisible(true);
	}

	private void outPutBinnedPeaksMatrix()
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(".txt");
		chooser.setSelectedFile(new File("Binned_Peaks_Matrix"+binnedMatrixCounter++ +".txt"));
		chooser.setCurrentDirectory(new File(prefs.get(prefName, "")));
		if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = chooser.getSelectedFile();
			if(!f.getAbsolutePath().endsWith(".txt"))
			{
				if(f.getAbsolutePath().lastIndexOf('.') > -1)
				{
					String newPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf('.'));
					File f2 = new File(newPath+".txt");
					f = f2;
				}
				else
				{
					f = new File(f.getAbsoluteFile()+".txt");
				}
			}
			BinPeakDialog bp = new BinPeakDialog(thisFrame,f);
			bp.setUpDialog();
			bp.setVisible(true);
		}
		
		
	}
	
	public int getPeakListCounterThenIncrement()
	{
		int current = peakListCounter;
		peakListCounter++;
		return current;
	}
	
	private void displayParameterSetDialog()
	{
		ParameterSetDialog parameterSetDialog = new ParameterSetDialog(
				thisFrame);
		parameterSetDialog.setSpectra();
		parameterSetDialog.setAllRBselected(true);
		parameterSetDialog.setVisible(true);
	}

	private void spectraSelection(boolean select) throws Exception
	{
		List<? extends AbstractFSAFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();
		List<Spectra> allSpectra = new ArrayList<Spectra>();
		for (AbstractFSAFileDescriptor afd : list)
		{
			Spectra stndSp = afd.getStandardSpectra();
			stndSp.setGraphIsShown(select);
			allSpectra.add(stndSp);
			List<Spectra> spList = afd.getDataSpectra();
			for (Spectra s : spList)
			{
				s.setGraphIsShown(select);
				allSpectra.add(s);
			}
		}
		this.spectraList = allSpectra;
		fsaPanel.forceRedraw();
		spectraJTableModel.fireTableDataChanged();
	}

	public void showAllSpectraFromTable(boolean select)
	{
		try
		{
			spectraSelection(select);
		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Unexpected error " + e.getMessage());
		}
	}

	private void chooseProjectFile()
	{
		if (dirty)
		{
			int userResponse = JOptionPane.showConfirmDialog(this,
					"Save current project?", "Save?",
					JOptionPane.YES_NO_CANCEL_OPTION);

			if (userResponse == JOptionPane.YES_OPTION)
			{
				if (!saveProject(false))
					return;
			}

			if (userResponse == JOptionPane.CANCEL_OPTION)
			{
				return;
			}
		}

		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setMultiSelectionEnabled(false);
		fileChooser.setCurrentDirectory(new File(prefs.get(prefName, "")));
		fileChooser.setFileFilter(filterSVAZ);

		if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			closeAllFiles(false);
			loadProject(fileChooser.getSelectedFile());
		}

	}

	private class MyProgressBarDialog extends JDialog
	{
		private static final long serialVersionUID = 1L;
		private String string;
		private JProgressBar jbar;
		private int max;
		private JButton cancel;
		public MyProgressBarDialog(String s, int max) 
		{
			super(thisFrame,"Working...");
			this.string = s;
			this.max = max;
			init();
			this.setAlwaysOnTop(true);
			this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			this.setSize(200,100);
			this.setLocationRelativeTo(null);
			this.setModal(true);
			this.pack();
			this.setResizable(true);
		}
		public JProgressBar getProgressBar()
		{
			return this.jbar;
		}
		public JButton getCancelButton()
		{
			return this.cancel;
		}
		private void init()
		{
			try
			{
				URL imageUrl = thisFrame.getClass().getResource("PSlogoSmall.png");
				Image logoImage = ImageIO.read(imageUrl);
				ImageIcon icon = new ImageIcon(logoImage);
				jbar = new JProgressBar(0,max);
				jbar.setPreferredSize(new Dimension(200,20));
				cancel = new JButton("Cancel");
				jbar.setString("Working");
				jbar.setStringPainted(true);
				jbar.setValue(0); 
				JLabel label = new JLabel(this.string);
				JPanel center_panel = new JPanel();
				center_panel.setSize(200, 75);
				center_panel.add(new JLabel(icon));
				center_panel.add(jbar);
				JPanel bot_panel = new JPanel();
				bot_panel.setSize(200, 75);
				bot_panel.add(cancel);
				JPanel top_panel = new JPanel();
				top_panel.add(label);
				this.getContentPane().add(top_panel,BorderLayout.NORTH);
				this.getContentPane().add(center_panel, BorderLayout.CENTER);
				this.getContentPane().add(bot_panel,BorderLayout.SOUTH);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(thisFrame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	private void chooseFsaFiles()
	{
		FsaFileChooser fsaFileChooser = new FsaFileChooser();
		directory = new File(prefs.get(prefName, ""));
		fsaFileChooser.setMultiSelectionEnabled(true);
		fsaFileChooser.setCurrentDirectory(directory);
		fsaFileChooser.setFileFilter(filterFSA);

		if (fsaFileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			this.setCursor(new Cursor(Cursor.WAIT_CURSOR));
			File[] fs = fsaFileChooser.getSelectedFiles();
			//List<Integer> dataChannels = fsaFileChooser.getDataChannels();
			//int stndChannel = fsaFileChooser.getSeletedStnd();
			List<Byte> dataChannels = fsaFileChooser.getDataChannels();
			byte stndChannel = fsaFileChooser.getSelectedStnd();
			prefs.put(prefName, fs[0].getParent());

			MyProgressBarDialog mpd = new MyProgressBarDialog("Opening: fsa Files",fs.length);
			mpd.getCancelButton().addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent e) 
				{
					myFsaFileWorker.cancel(true);	
				}
			});
			myFsaFileWorker = new MyLoadFsaFilesWorker(mpd.getProgressBar(),mpd,fs,dataChannels,stndChannel);
			myFsaFileWorker.execute();
			mpd.setVisible(true);
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			
		}
			
	}

	private class MyLoadFsaFilesWorker extends SwingWorker<Void, Void>
	{
		private JProgressBar jbar;
		private JDialog jdialog;
		private File[] fs;
		//private List<Integer> dataChannels;
		private List<Byte> dataChannels;
		//private int stndChannel;
		private byte stndChannel;
		private List<Exception> exceptionList = new ArrayList<Exception>();
		
		/*public MyLoadFsaFilesWorker(JProgressBar jbar, JDialog dialog,File[] fs,List<Integer>dataChannels,int stndChannel)*/
		public MyLoadFsaFilesWorker(JProgressBar jbar, JDialog dialog,File[] fs,List<Byte>dataChannels,byte stndChannel)
		{
			this.jbar = jbar;
			this.jdialog = dialog;
			this.fs = fs;
			this.dataChannels = dataChannels;
			this.stndChannel = stndChannel;
			
		}
		
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = fs.length;
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		protected Void doInBackground() throws Exception
		{
			//int x = 0;
			//for (File f : fs)
			for(int x=0; x<fs.length; x++)
			{
				if(isCancelled())
					return null;
				SwingUtilities.invokeLater(new SetterClass(x));
				Exception ex = loadFsaFile(fs[x], dataChannels, stndChannel);
				
				
				//x++;
				if (ex != null)
					this.exceptionList.add(ex);
			}
			if (this.exceptionList.size() > 0)
			{
				JOptionPane.showMessageDialog(null, "Failed to add "
						+ this.exceptionList.size() + " spectra \n"
						+ this.exceptionList.get(0).getMessage(), "Error",
						JOptionPane.ERROR_MESSAGE);
			}

			try
			{
				setGUIForNewFiles();
				updatePanel(false);
			} 
			catch (Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(thisFrame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}

			return null;
		}
		
		@Override
		protected void done() 
		{
			jdialog.dispose();
			if(isCancelled())
			{
				dirty = false;
				closeAllFiles(false);
				
			}
		}
	}
	
	private void setGUIForNewFiles()
	{
		closeAll.setEnabled(true);
		closeFile.setEnabled(true);
		export.setEnabled(true);
		print.setEnabled(true);
		lineThickness.setEnabled(true);
		spectraJTable.setFilesOpen(true);
		axisMenu.setEnabled(true);
		save.setEnabled(true);
		smooth.setEnabled(true);
	}
	

	/*
	 * returns true if the file was saved
	 */
	private boolean saveProject(boolean isSaveAsCall)
	{
		File oldFile = projectFile;

		if (isSaveAsCall || projectFile == null)
		{
			JFileChooser outFC = new JFileChooser();
			outFC.setCurrentDirectory(directory);
			outFC.setSelectedFile(new File("NewProject.svaz"));

			if (outFC.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
			{
				projectFile = outFC.getSelectedFile();

				if (projectFile.exists())
				{
					int option = JOptionPane.showConfirmDialog(this, "File "
							+ projectFile.getName() + " exists.  Replace?",
							"Replace file?", JOptionPane.YES_NO_OPTION);

					if (option != JOptionPane.YES_OPTION)
					{
						projectFile = oldFile;
						return false;
					}
				}

			} else
			{
				return false;
			}
		}
		
		MyProgressBarDialog mpd = new MyProgressBarDialog("Saving: "+projectFile.getName(),guiDerivedExperimentSet.getFileDescriptors().size());
		mpd.getCancelButton().addActionListener(new ActionListener()
		{

			@Override
			public void actionPerformed(ActionEvent e) 
			{
				mySaveProjectWorker.cancel(true);
				
			}
			
		});
		mySaveProjectWorker = new MySaveProjectWorker(mpd.getProgressBar(),mpd);
		mySaveProjectWorker.execute();
		mpd.setVisible(true);
		return true;
	}

	private class MySaveProjectWorker extends SwingWorker<Void, Void>
	{
		private JProgressBar jbar;
		private JDialog jdialog;
		private File tempFile;// = new File("PS_temp_save.svaz");
		public MySaveProjectWorker(JProgressBar jbar, JDialog dialog)
		{
			this.jbar = jbar;
			this.jdialog = dialog;
			
		}
		private File getRandomTempFile()
		{
			String s = "PS_temp_save_";
			String ext = ".svaz";
			Random gen = new Random();
			int r = gen.nextInt(100);
			String path = s+r+ext;
			return new File(path);
		}
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = guiDerivedExperimentSet.getFileDescriptors().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		protected Void doInBackground() throws Exception 
		{
			try
			{
				setCursor(new Cursor(Cursor.WAIT_CURSOR));
				if (!projectFile.getAbsolutePath().endsWith(".svaz"))
				{
					if (projectFile.getAbsolutePath().lastIndexOf('.') > -1)
					{
						String newPath = projectFile.getAbsolutePath().substring(0,
								projectFile.getAbsolutePath().lastIndexOf('.'));
						projectFile = new File(newPath + ".svaz");
					}

					else
					{
						projectFile = new File(projectFile.getAbsolutePath() + ".svaz");
					}

				}
				
				tempFile = getRandomTempFile();
				while(tempFile.exists())
				{
					tempFile = getRandomTempFile();
				}
				ObjectOutputStream out = new ObjectOutputStream(
						new GZIPOutputStream(new FileOutputStream(tempFile)));//(projectFile)));
				//ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(stnFile));
				out.writeFloat(VERSION_NUMBER);
				out.writeInt(guiDerivedExperimentSet.getFileDescriptors().size());
				out.writeObject(guiDerivedExperimentSet);
				for(int x=0; x<guiDerivedExperimentSet.getFileDescriptors().size(); x++)
				{
					out.writeObject(guiDerivedExperimentSet.getFileDescriptors().get(x));
					SwingUtilities.invokeLater(new SetterClass(x));
					out.reset();
				}
				out.writeObject(stndWeights);

				out.flush();
				out.close();
				saveAs.setEnabled(true);
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				setDirty(false);

			} catch (Exception ex)
			{
				if( ! isCancelled())
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(thisFrame, "Error in saving file "
							+ ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);

					projectFile = null;
				}
				
			} finally
			{
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				setTitle(getTitleString());
				validate();
			}
			return null;
		}
		@Override
		protected void done() 
		{
			jdialog.dispose();
			if(isCancelled())
			{
				//projectFile.delete();
				tempFile.delete();
			}
			else
			{
				boolean success = tempFile.renameTo(projectFile);
				if(!success)
					JOptionPane.showMessageDialog(thisFrame, "Error in saving file, last attempt located: "+"\n"
							+tempFile.getAbsolutePath(),"Error",JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	public Boolean checkIfFileOpen(String filePath)
	{
		List<? extends AbstractFSAFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();

		for (AbstractFSAFileDescriptor fsa : list)
			if (fsa.getFSAFile().getAbsolutePath().equals(filePath))
				return true;

		return false;
	}

	// Close file
	// added this to get access to file close and open methods from jtable
	public void removeSpectraFromTable()
	{
		removeSpectra();
	}

	public void closeAllFromTable()
	{
		closeAllFiles(true);
	}

	public void closeSelectedFilesFromTable()
	{
		closeDescriptorFile(spectraJTable.getSelectedRows());
	}

	public void displayStndDialogFromTable()
	{
		displayStndDialog();
	}

	private void removeSpectra()
	{
		try
		{
			if (spectraJTable.getSelectedRows().length == 0
					&& spectraJTable.getRowCount() > 0)
				spectraJTable.setRowSelectionInterval(0, 0);
			closeMultipleFiles(spectraJTable.getSelectedRows());
			fsaPanel.forceRedraw();
		} catch (Exception x)
		{
			System.out.println(x);
			System.out.println(x.getMessage());
			x.printStackTrace();
			System.out.println("fail");
			JOptionPane.showMessageDialog(thisFrame, "Error: "
					+ x.getMessage(), "Error Total Fail", JOptionPane.ERROR_MESSAGE);
			System.exit(1);
		}

	}

	private void resetMenuItems()
	{
		saveAs.setEnabled(false);
		save.setEnabled(false);
		lineThickness.setEnabled(false);
		smooth.setEnabled(false);
	}

	private void closeDescriptorFile(int[] selectedRows)
	{
		try
		{
			List<? extends AbstractFSAFileDescriptor> list = guiDerivedExperimentSet
					.getFileDescriptors();
			if (selectedRows.length == 0)
			{
				JOptionPane.showMessageDialog(thisFrame,
						"Selection Error\n"
								+ "\n Please Select Spectra in table to Remove\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
			else
			{
				for (Integer i : selectedRows)
				{
					String name = this.spectraList.get(i).getName();
					for (Iterator<? extends AbstractFSAFileDescriptor> afd = list
							.iterator(); afd.hasNext();)
					{
						AbstractFSAFileDescriptor temp = afd.next();
						if (name.equals(temp.getFileNamePrefix()))
							afd.remove();
					}

				}
				List<? extends AbstractFSAFileDescriptor> curList = guiDerivedExperimentSet
						.getFileDescriptors();
				this.spectraList.clear();
				for (AbstractFSAFileDescriptor afd : curList)
				{
					Spectra sts = afd.getStandardSpectra();
					List<Spectra> data = afd.getDataSpectra();
					this.spectraList.add(sts);
					for (Spectra s : data)
						this.spectraList.add(s);

				}
				if (this.spectraList.isEmpty())
					closeAllFiles(false);
				else
				{
					spectraJTableModel.fireTableDataChanged();
					fsaPanel.forceRedraw();
				}
			}
			

		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(thisFrame,
					"A serious error has occurred \n" + e.getMessage()
							+ "\nYour data are in an undefined state\n",
					"Error", JOptionPane.ERROR_MESSAGE);
		}

	}

	private void closeMultipleFiles(int[] selectedRows) throws Exception
	{
		for (Integer i : selectedRows)
		{
			this.spectraList.get(i).setDeleteFromList(true);
		}
		for (int x = this.spectraList.size() - 1; x >= 0; x--)
		{
			if (this.spectraList.get(x).isDeleteFromList())
				this.spectraList.remove(x);
		}
		if (this.spectraList.isEmpty())
		{
			resetMenuItems();
			// editAxis.setEnabled(false);
			export.setEnabled(false);
			print.setEnabled(false);
		}
		spectraJTableModel.fireTableDataChanged();

	}

	public void closeAllFiles(boolean askFirst)
	{
		List<FsaFileDescriptor> list = guiDerivedExperimentSet
				.getFileDescriptors();

		int userResponse = JOptionPane.YES_OPTION;

		if (askFirst)
		{
			userResponse = JOptionPane.showConfirmDialog(this,
					"Really close all files?", "Close all?s",
					JOptionPane.YES_NO_OPTION);
		}

		if (userResponse == JOptionPane.YES_OPTION)
		{
			try
			{
				list.removeAll(guiDerivedExperimentSet.getFileDescriptors());
				this.spectraList.clear();
				spectraJTableModel.fireTableDataChanged();
				resetMenuItems();
				export.setEnabled(false);
				print.setEnabled(false);
				closeAll.setEnabled(false);
				closeFile.setEnabled(false);
				spectraJTable.setFilesOpen(false);
				setDirty(false);
				fsaPanel.forceRedraw();
				projectFile = null;
				this.setTitle(getTitleString());
				// this.filterSVAZ = null;
			} catch (Exception x)
			{
				x.printStackTrace();
				JOptionPane.showMessageDialog(null, "File Close All Failure!"
						+ '\n' + "Message:" + '\n' + x.getMessage(),
						"Could not close all Files!",
						JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	/*private FsaFileDescriptor makeADescriptor(StandardWeights sw,
			final File filePath, final GuiDerivedExperimentSet experimentSet,
			final List<Integer> channels, final int stndChannel)*/
	private FsaFileDescriptor makeADescriptor(StandardWeights sw,
			final File filePath, final GuiDerivedExperimentSet experimentSet,
			final List<Byte> channels, final byte stndChannel)
	{
		return new FsaFileDescriptor(sw, filePath, experimentSet, channels,
				stndChannel);
	}

	/*public AbstractFSAFileDescriptor addData(File fsaFile,
			List<Integer> dataChannels, int stndChannel)*/
	public AbstractFSAFileDescriptor addData(File fsaFile,
			List<Byte> dataChannels, byte stndChannel)
	{
		FsaFileDescriptor fsa = makeADescriptor(null, fsaFile,
				guiDerivedExperimentSet, dataChannels, stndChannel);
		guiDerivedExperimentSet.getFileDescriptors().add(fsa);
		dirty = true;

		return fsa;
	}

	
	public boolean loadStandardsFile()
	{
		JFileChooser jfc = new JFileChooser();
		jfc.setMultiSelectionEnabled(true);
		stnDirectory = new File(prefs.get("stndDir", ""));
		jfc.setCurrentDirectory(stnDirectory);
		jfc.setFileFilter(filterTxt);
		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File[] fs = jfc.getSelectedFiles();
			prefs.put("stndDir", fs[0].getParent());
			prefs.put("lastStnd", fs[0].getAbsolutePath());
			for (File f : fs)
			{
				readInStndFile(f);
			}
		} else
			return true;
		return false;
	}

	public void loadMetaData()
	{
		JFileChooser jfc = new JFileChooser();
		File aDirectory = new File(prefs.get(metaName, ""));
		jfc.setMultiSelectionEnabled(false);
		if (aDirectory != null)
			jfc.setCurrentDirectory(aDirectory);

		jfc.setFileFilter(filterMetadataTxt);
		if (jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = jfc.getSelectedFile();
			prefs.put(metaName, f.getParent());

			try
			{
				MetaData.parseFile(f, this);
				dirty = true;
				spectraJTable.getModel().ensureMetaNamesComplete();
			} catch (Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, "Failed to load metadata "
						+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
			}
		}

	}

	public void readInStndFile(File f)
	{
		try
		{
			ArrayList<Short> standards = new ArrayList<Short>();
			BufferedReader reader = new BufferedReader(new FileReader(f));
			String nextLine = reader.readLine();
			while (nextLine != null)
			{
				//standards.add(Integer.parseInt(nextLine));
				standards.add(Short.parseShort(nextLine));
				nextLine = reader.readLine();
			}
			stndWeights.add(new StandardWeights(f, standards));
			dirty = true;
		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Failed to read in standards file " + 
					f.getName() + "\n" + e.getMessage() + "\n" + 
					"Make sure a standards file has only integers followed by newlines\n" + 
					"For example:\n10\n20\n30\n");
		}

	}

	/*private Exception loadFsaFile(File f, List<Integer> dataChannels,
			int stndChannel)*/
	private Exception loadFsaFile(File f, List<Byte> dataChannels,
			byte stndChannel)
	{
		Exception ex = null;
		try
		{
			// a new file coming in may not have standards
			basePair.setSelected(false);

			// a total hack here, but that is where the standards curve
			// sometimes lives in FSA files!
			if (stndChannel == 5)
				stndChannel = 105;

			AbstractFSAFileDescriptor fsa = addData(f, dataChannels,
					stndChannel);
			fsa.getStandardSpectra().callFeatures();
			fsa.getStandardSpectra().setPeakColor(getPeakColor(fsa.getStandardSpectra().getDataChannel()));//(Color.DARK_GRAY);
			fsa.getStandardSpectra().setPossiblePeakColor(Color.MAGENTA);
			fsa.getStandardSpectra().setIsStandard(true);

			List<Spectra> spectra = fsa.getDataSpectra();
			for (Spectra s : spectra)
			{
				s.callFeatures();
				s.setPeakColor(getPeakColor(s.getDataChannel()));
				s.setPossiblePeakColor(Color.MAGENTA);
			}
			dirty = true;

		} catch (Exception x)
		{
			x.printStackTrace();
			ex = x;
			JOptionPane.showMessageDialog(this, "Failed to read in FSA file " + 
					f.getName() + "\n" + x.getMessage() + "\n" + 
					"Serious Error Occurred with FSA file!" + 
					" This File may be corrupted.");
		}
		return ex;
	}

	private Color getPeakColor(int channelNum)
	{
		switch(channelNum)
		{
			case 1: return Color.BLUE;
			case 2: return Color.GREEN;
			case 3: return Color.YELLOW;
			case 4: return Color.RED;
			case 105: return TIMM_ORANGE;
			default: return Color.BLACK;
		}
	}
	private void updatePanel(boolean recallPeaks) throws Exception
	{
		List<? extends AbstractFSAFileDescriptor> afdList = guiDerivedExperimentSet
				.getFileDescriptors();
		for (AbstractFSAFileDescriptor fsa : afdList)
		{
			if (recallPeaks)
				fsa.getStandardSpectra().callFeatures();

			if(!this.spectraList.contains(fsa.getStandardSpectra()))
				this.spectraList.add(fsa.getStandardSpectra());
			List<Spectra> spectra = fsa.getDataSpectra();
			for (Spectra s : spectra)
			{
				if(!this.spectraList.contains(s))
				{
					if (recallPeaks)
						s.callFeatures();

					this.spectraList.add(s);
				}
				
			}

		}
		fsaPanel.resetZoomOut();
		fsaPanel.forceRedraw();

		spectraJTable.getModel().ensureMetaNamesComplete();
		spectraJTable.dataComplete();
		spectraJTableModel.fireTableDataChanged();
	}
	
	private void loadProject(File f)
	{
		
		MyProgressBarDialog mpd = new MyProgressBarDialog("Opening: "+f.getName(),guiDerivedExperimentSet.getFileDescriptors().size());
		mpd.getCancelButton().addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				myWorker.cancel(true);	
			}
		});
		myWorker = new MyLoadProjectWorker(mpd.getProgressBar(),mpd,f);
		myWorker.execute();
		mpd.setVisible(true);
	}

	private void aboutDialogBox()
	{
		try
		{
			URL imageUrl = this.getClass().getResource("PSlogoSmall.png");
			Image logoImage = ImageIO.read(imageUrl);
			ImageIcon icon = new ImageIcon(logoImage);
			JOptionPane.showMessageDialog(null, PEAK_STUDIO_STRING + '\n'
					+ "Fodor Lab UNCC" + '\n' + "Version: " + VERSION_NUMBER,
					PEAK_STUDIO_STRING, JOptionPane.PLAIN_MESSAGE, icon);

		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Dialog Failed"
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}

	}

	private void standardsWarning()
	{
		try
		{
			URL imageUrl = this.getClass().getResource("PSlogoSmall.png");
			Image logoImage = ImageIO.read(imageUrl);
			ImageIcon icon = new ImageIcon(logoImage);
			JOptionPane.showMessageDialog(null, "Standards Warning!" + '\n'
					+ "Message:" + '\n'
					+ "Must Load Standards File For This Fuction To Work!"
					+ '\n' + "Import Standards then select Apply All Spectra",
					"Standards File Warning! ", JOptionPane.WARNING_MESSAGE,
					icon);
		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Dialog Failed"
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	private void smoothingNotAvailable()
	{
		try
		{
			URL imageUrl = this.getClass().getResource("PSlogoSmall.png");
			Image logoImage = ImageIO.read(imageUrl);
			ImageIcon icon = new ImageIcon(logoImage);
			JOptionPane.showMessageDialog(null, "Option Not Available!" + '\n'
					+ "Message:" + '\n'
					+ "Smooth data view not available."
					+ '\n' + "Make sure all data has been smoohted before selecting this option.",
					" Option Not Available", JOptionPane.WARNING_MESSAGE,
					icon);
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this, "Dialog Failed"
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	public void printToScreen(String s)
	{
		System.out.println(s);
	}

	public File getDirectory()
	{
		return new File(prefs.get(prefName, ""));
	}

	public String getPrefName()
	{
		return prefName;
	}

	public Preferences getPrefs()
	{
		return prefs;
	}
	
	   
    private class MyLoadProjectWorker extends SwingWorker<Void, Void>
    {
    	private JProgressBar jbar;
    	private JDialog jdialog;
    	private File file;
    	private int numRecords;
    	public MyLoadProjectWorker( JProgressBar jbar, JDialog dialog,File file)
    	{
    		this.jbar = jbar;
			this.jdialog = dialog;
			this.file = file;
			
    	}

    	private class SetterClass implements Runnable
		{
			final int x;
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				jbar.setString((int)(((float)x/numRecords)*100)+"%"+" Complete");
				
			}
		}
    	
		@Override
		protected Void doInBackground() throws Exception
		{
			try
			{
				
				// new files coming in may not have standards
				basePair.setSelected(false);
				setCursor(new Cursor(Cursor.WAIT_CURSOR));

				projectFile = this.file;
				ObjectInputStream in = new ObjectInputStream(new GZIPInputStream(
						new FileInputStream(projectFile)));

				in.readFloat(); // the version number
				numRecords = in.readInt();
				jbar.setMaximum(numRecords);
				guiDerivedExperimentSet = (GuiDerivedExperimentSet) in.readObject();
				
				List<FsaFileDescriptor> fsaList = new ArrayList<FsaFileDescriptor>();
				guiDerivedExperimentSet.setUsersList(fsaList);
				for( int x=0; x < numRecords ; x++)
				{
					if(isCancelled())
						return null;
				
					fsaList.add( (FsaFileDescriptor) in.readObject());
					SwingUtilities.invokeLater(new SetterClass(x));
			}
			
			stndWeights = (List<StandardWeights>) in.readObject();
			for(FsaFileDescriptor fd: fsaList)
			{
				fd.getStandardSpectra().calculateFeatureZscore();
			}
			in.close();
					
			setGUIForNewFiles();
			updatePanel(false);
			saveAs.setEnabled(true);
				
				
		}
			catch (Exception e)
			{
				if( ! isCancelled())
				{
					e.printStackTrace();
					JOptionPane.showMessageDialog(thisFrame, e.getMessage() + "\n"
							+ "Loading project failed\n"
							+ "Peak Studio is now in an undefined state\n"
							+ "Restaring PeakStudio is recommended\n");
				}
				
				
			} finally
			{
				setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
				setDirty(false);
			}
			return null;
			}
		
		@Override
		protected void done() 
		{
			
			jdialog.dispose();
			if(isCancelled())
			{
				closeAllFiles(false);
				projectFile = null;
			}
		}
    }
		
}
