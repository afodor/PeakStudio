package viewer;

import utils.PointConverter;
import dataProvider.DataProvider;
import experimentSets.Feature;
import experimentSets.Spectra;
import experimentSets.Feature.FeatureType;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.NoninvertibleTransformException;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.filechooser.FileFilter;

public class FsaPanel extends JPanel
{
	Range indexRange = new Range(Float.MAX_VALUE, Float.MIN_VALUE);
	Range basepairRange = new Range(Float.MAX_VALUE, Float.MIN_VALUE);
	Range yRange = new Range(Float.MAX_VALUE, Float.MIN_VALUE);

	Range displayedXRange = null;
	Range displayedYRange = null;
	Range displayedIndexRange = null;

	private Point dragStartScreen;
	private Point dragEndScreen;
	private Point autoPanPoint;
	private boolean panning = false;
	private Timer autoPan;
	public static final float Y_SCREEN_FRACTION = 0.92f;

	private String pngName = this.getClass() + "ImageDirectory";
	private Point mousePoint = new Point();
	private int x_ticNumber;
	private int y_ticNumber;
	private static final long serialVersionUID = 1L;
	private int oldWidth = -1, oldHeight = -1;
	private boolean forceRedraw = false;
	private BufferedImage offScreenImage;
	private BufferedImage axisBi;
	private final FsaFrame parentFrame;
	private FsaPanel thisPanel;
	private int picCount = 0;
	RenderingHints rn = null;
	BasicStroke bs = null;
	private float strokeSize;
	private boolean axisDirty = true;

	private float xZoomFactor = 1;
	private float maxXZoomFactor = 500;

	private float xPanFactor = 0.5f;

	private float yZoomFactor = 1;
	private float maxYZoomFactor = 25;

	private float yPanFactor = 0.5f;

	public static final int AUTO_PAN_SPEED = 125;
	
	private BufferedImage lastImage = null;

	private static class Range
	{
		final float lowVal;
		final float highVal;
		final float diff;

		public Range(float lowVal, float highVal)
		{
			this.lowVal = lowVal;
			this.highVal = highVal;
			this.diff = highVal - lowVal;
		}
		
		private List<Float> getBasicSplit(int numDivisions)
		{
			List<Float> splits = new ArrayList<Float>();
			
			for( float x=0; x < numDivisions; x++)
				splits.add( lowVal + diff * x / (numDivisions -1));
			
			return splits;
		
		}
		
		public List<Float> getSplits(int numDivisions)
		{
			if(diff < 1)
			{
				return getBasicSplit(numDivisions);
			}
			
			int intDiffInterval = (int) ((diff + 0.5)/numDivisions);
			
			if( intDiffInterval <= 1)
			{
				getBasicSplit(numDivisions);
			}
			
			int intDiffLength = ("" + intDiffInterval).length();
			
			if(intDiffLength > 1 )
			{
				int tenFactor = (int) Math.pow(10,(intDiffLength - 1));
				
				intDiffInterval = tenFactor * (intDiffInterval/tenFactor);
			}
			
			if( intDiffInterval<=0)
				return getBasicSplit(numDivisions);
			
			int startVal = (int) (intDiffInterval * (int)(lowVal / intDiffInterval));
			
			List<Float> splits = new ArrayList<Float>();
			
			for( int x=startVal; x <= highVal + intDiffInterval; x+=intDiffInterval)
			{
				splits.add((float)x);
			}
			
			return splits;
		}
	}

	public float getMaxYZoomFactor()
	{
		return maxYZoomFactor;
	}

	public float getMaxXZoomFactor()
	{
		return maxXZoomFactor;
	}

	public void autoPanning(Point p)
	{
		if (autoPanPoint != null)
			imagePan(autoPanPoint);
	}
	
	public float getXPanFactor()
	{
		return xPanFactor;
	}

	public void setXPanFactor(float xPanFactor)
	{
		this.xPanFactor = xPanFactor;
	}

	public float getYPanFactor()
	{
		return yPanFactor;
	}

	public float getxZoomFactor()
	{
		return xZoomFactor;
	}

	public void setxZoomFactor(float xZoomFactor)
	{
		if (xZoomFactor < 1)
			xZoomFactor = 1;

		if (xZoomFactor > maxXZoomFactor)
			xZoomFactor = maxXZoomFactor;

		this.xZoomFactor = xZoomFactor;

		if (this.xZoomFactor == 1)
			xPanFactor = 0.5f;

		forceRedraw();
	}

	public void setyZoomFactor(float yZoomFactor)
	{
		if (yZoomFactor < 1)
			yZoomFactor = 1;

		if (yZoomFactor > maxYZoomFactor)
			yZoomFactor = maxYZoomFactor;

		this.yZoomFactor = yZoomFactor;

		if (this.yZoomFactor == 1)
			yPanFactor = 0.5f;

		forceRedraw();
	}

	public float getyZoomFactor()
	{
		return yZoomFactor;
	}

	public void setYPanFactor(float yPanFactor)
	{
		this.yPanFactor = yPanFactor;
	}

	private Range getYRangeToDisplay()
	{
		float zoomedRange = yRange.diff / yZoomFactor;

		float panStart = yRange.lowVal + yPanFactor * yRange.diff - zoomedRange
				/ 2;

		return new Range(panStart, panStart + zoomedRange);

	}

	private Range getDisplayRange(Range inputRange)
	{
		float zoomedRange = inputRange.diff / xZoomFactor;

		float panStart = inputRange.lowVal +  inputRange.diff - xPanFactor * inputRange.diff
				- zoomedRange / 2;

		return new Range(panStart, panStart + zoomedRange);
	}

	private Range getXRangeToDisplay()
	{
		this.displayedIndexRange = getDisplayRange(indexRange);

		if (!parentFrame.inBasePairSpace())
		{
			return this.displayedIndexRange;
		} else
		{
			return getDisplayRange(basepairRange);
		}
	}

	public FsaFrame getParentFrame()
	{
		return parentFrame;
	}

	public void forceRedraw()
	{
		parentFrame.getHorizontalBar().setFireListener(false);
		parentFrame.getVertialBar().setFireListener(false);
		forceRedraw = true;
		parentFrame.setDirty(true);


		boolean oneShown= false;
		
		for( Spectra s : parentFrame.getSpectraList())
			if( s.graphIsShown() )
				oneShown = true;
			
		JScrollBar bar = parentFrame.getHorizontalBar();

		float range = bar.getMaximum() - bar.getVisibleAmount();

		bar.setValue(0);
		
		if(oneShown)
		{
			bar.setVisibleAmount((int) (100f / xZoomFactor));

			if (xZoomFactor > 1)
				bar.setValue((int) (xPanFactor * range));
		}
		else
		{
			bar.setVisibleAmount(100);
		}
		
		
		bar = parentFrame.getVertialBar();
		range = bar.getMaximum() - bar.getVisibleAmount();

		bar.setValue(0);
		
		if(oneShown)
		{
			bar.setVisibleAmount((int) (100f / yZoomFactor));

			if (yZoomFactor > 1)
				bar.setValue((int) (yPanFactor * range));

		}
		else
		{
			bar.setVisibleAmount(100);
		}
		
		repaint();
	}

	public FsaPanel(FsaFrame parentFrame) throws Exception
	{
		this.parentFrame = parentFrame;
		thisPanel = this;
		this.x_ticNumber = this.parentFrame.getPrefs()
				.getInt("x_ticNumber", 10);
		this.y_ticNumber = this.parentFrame.getPrefs()
				.getInt("y_ticNumber", 10);
		this.strokeSize = this.parentFrame.getPrefs().getFloat("strokeSize",
				1.5f);
		init();
	}

	public void resetZoomOut()
	{
		xZoomFactor = 1;
		xPanFactor = 0.5f;
		yZoomFactor = 1;
		yPanFactor = 0.5f;

		forceRedraw();
	}

	public void handleKeyPressed(KeyEvent e)
	{
		if (!e.isAltDown())
			return;

		switch (e.getKeyCode())
		{
		case KeyEvent.VK_UP:
			yPanFactor = yPanFactor - 0.005f;
			if (yPanFactor < 0)
				yPanFactor = 0;
			forceRedraw();
			break;

		case KeyEvent.VK_DOWN:
			yPanFactor = yPanFactor + 0.005f;
			if (yPanFactor > 1)
				yPanFactor = 1;
			forceRedraw();
			break;

		case KeyEvent.VK_LEFT:
			xPanFactor = xPanFactor - 0.005f;
			if (xPanFactor < 0)
				xPanFactor = 0;
			forceRedraw();

			break;

		case KeyEvent.VK_RIGHT:
			xPanFactor = xPanFactor + 0.005f;
			if (xPanFactor > 1)
				xPanFactor = 1;
			forceRedraw();
			break;
		}
	}

	private void init()
	{
		addMouseMotionListener(new MouseOver());
		addMouseListener(new PopUpHandler());
		addMouseListener(new MousePeakSelect());
		setFocusable(true);
		setBackground(Color.white);
		setPreferredSize(new Dimension(1000, 600));
		setSize(800, 600);
		setFocusable(true);
		rn = new RenderingHints(RenderingHints.KEY_ANTIALIASING,
				RenderingHints.VALUE_ANTIALIAS_ON);
		rn.put(RenderingHints.KEY_STROKE_CONTROL,
				RenderingHints.VALUE_STROKE_PURE);
		rn.put(RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		bs = new BasicStroke(this.strokeSize);

		addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyTyped(KeyEvent e)
			{
				if(e.isShiftDown() && e.getKeyChar() == '+')
					keyZoomY(true);
				else if (e.isShiftDown() && e.getKeyChar() == '-')
					keyZoomY(false);
				else if(e.getKeyChar() == '+')
					keyZoomX(true);
				else if(e.getKeyChar() == '-')
					keyZoomX(false);
				else if(e.getKeyCode() == KeyEvent.VK_UP)
					imagePanByKeyEvent(new Point((getWidth()/2),0));
				else if(e.getKeyCode() == KeyEvent.VK_DOWN)
					imagePanByKeyEvent(new Point((getWidth()/2),getHeight()));
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
					imagePanByKeyEvent(new Point(getWidth(),(getHeight()/2)));
				else if(e.getKeyCode() == KeyEvent.VK_LEFT)
					imagePanByKeyEvent(new Point(0,(getHeight()/2)));
				else
					parentFrame.handleKeyType(e);
			}

			public void keyPressed(KeyEvent e)
			{
				if(e.isShiftDown() && e.getKeyChar() == '+')
					keyZoomY(true);
				else if (e.isShiftDown() && e.getKeyChar() == '-')
					keyZoomY(false);
				else if(e.getKeyChar() == '+')
					keyZoomX(true);
				else if(e.getKeyChar() == '-')
					keyZoomX(false);
				else if(e.getKeyCode() == KeyEvent.VK_UP)
					imagePanByKeyEvent(new Point((getWidth()/2),0));
				else if(e.getKeyCode() == KeyEvent.VK_DOWN)
					imagePanByKeyEvent(new Point((getWidth()/2),getHeight()));
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
					imagePanByKeyEvent(new Point(getWidth(),(getHeight()/2)));
				else if(e.getKeyCode() == KeyEvent.VK_LEFT)
					imagePanByKeyEvent(new Point(0,(getHeight()/2)));
				else
					handleKeyPressed(e);
			}
		});

		addMouseWheelListener(new MouseAdapter()
		{
			@Override
			public void mouseWheelMoved(MouseWheelEvent e)
			{
				float wheelRotation = ((float) e.getWheelRotation()) / 100;

				if (e.isShiftDown())
				{
					yZoomFactor += wheelRotation * 5;

					if (yZoomFactor > maxYZoomFactor)
						yZoomFactor = maxYZoomFactor;
					else
						yZoomFactor += wheelRotation;

					if (yZoomFactor < 1)
					{
						yZoomFactor = 1;
						yPanFactor = 0.5f;
					}

				} else
				{
					xZoomFactor += wheelRotation * 100;

					if (xZoomFactor > maxXZoomFactor)
						xZoomFactor = maxXZoomFactor;

					if (xZoomFactor < 1)
					{
						xZoomFactor = 1;
						xPanFactor = 0.5f;
					}

				}

				forceRedraw();
			}

		});

		addMouseListener(new DragStarter());
		addMouseMotionListener(new Dragging());

		autoPan = new Timer(AUTO_PAN_SPEED, new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				autoPanning(autoPanPoint);
			}
		});
	}

	private class MousePeakSelect extends MouseAdapter
	{
		@Override
		public void mouseClicked(MouseEvent e)
		{
			if (e.getClickCount() < 2)
				return;

			Feature maxFeature = null;

			for (Spectra s : parentFrame.getSpectraList())
				if (s.isVisibleInTable() && s.graphIsShown())
				{
					List<Feature> features = s.getFeatureList();

					float xVal = inverseX(e.getX());
					float yVal = inverseY(e.getY());
					
					if (parentFrame.inBasePairSpace())
					{
						DataProvider<Float> basepairs = s.getBasePairCalls();
						xVal = basepairs.search(xVal);

						if (xVal < 0)
							xVal = -xVal - 1;						
					}

					
					for (Feature f : features)
					{
						
						float range = Math.abs(f.getMaxValue()
								- f.getMinValue());
						if (xVal >= f.getStartIndex()
								&& xVal <= f.getFinalIndex()
								&& yVal + 10 * range >= f.getMinValue()
								&& yVal - 10 * range <= f.getMaxValue())
						{
							float thisRange = range;

							if (maxFeature == null
									|| thisRange > Math.abs(maxFeature
											.getMaxValue()
											- maxFeature.getMinValue()))
							{
								maxFeature = f;
							}

						}
					}

				}

			if (maxFeature == null)
			{
				parentFrame.setMouseOverPeak(null, null);
			} else
			{
				parentFrame.setMouseOverPeak(maxFeature, maxFeature
						.getParentSpectra());
			}

			forceRedraw();
		}
	}

	private float getXYvalue(boolean x)
	{
		if(x)
			return  PointConverter.getXVal(mousePoint.x, displayedXRange.lowVal, displayedXRange.diff, getWidth());
		else
			return PointConverter.getYval(mousePoint.y, displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION, getHeight());
	}
	
	private JLabel getToolTipFeature(JLabel label)
	{
		NumberFormat formatter = new DecimalFormat("0.00");
		String name = null;
		String featureType = null;
		String x = null;
		String y = null;
		String auc = null;
		String zscore = null;
		boolean setter = false;
		boolean isStnd = false;
		for(Spectra s: parentFrame.getSpectraList())
		{
			
			
			if(s.isVisibleInTable() && s.graphIsShown())
			{
				isStnd = s.getIsStandard();
				Float xVal = getXYvalue(true);
				Float yVal = getXYvalue(false);
				List<Feature> featureList = s.getFeatureList();
				if(xVal != null && yVal != null)
				{
					if(parentFrame.inBasePairSpace())
					{
						
							for(Feature f: featureList)
							{
								if(f.getIndexOfHighestPeak() > -1 && Math.abs(xVal-s.getBasePairCalls().get(f.getIndexOfHighestPeak()))<1
										&& yVal < f.getMaxDisplayed() && yVal > f.getMinValue())
								{
									name = s.getName();
									featureType = f.getFeatureType().toString();
									//x = formatter.format(xVal);
									//y = formatter.format(yVal);
									x = formatter.format(s.getBasePairCalls().get(f.getIndexOfHighestPeak()));
									y = formatter.format(f.getHeight());
									auc = formatter.format(f.getAUC(false));
									if(isStnd)
										zscore = formatter.format(f.getZscore());
									else
										zscore = "NA";
								
									setter = true;
								}//end if
							}//end for
					}//end if
					else
					{
						for(Feature f: featureList)
						{
							if(Math.abs(xVal - f.getIndexOfHighestPeak()) < 10 
									&& yVal < f.getMaxDisplayed() && yVal >= f.getMinValue())
							{
								name = s.getName();
								featureType = f.getFeatureType().toString();
								//x = formatter.format(xVal);
								//y = formatter.format(yVal);
								x = formatter.format(f.getIndexOfHighestPeak());
								y = formatter.format(f.getHeight());
								auc = formatter.format(f.getAUC(true));
								if(isStnd)
									zscore = formatter.format(f.getZscore());
								else
									zscore = "NA";
								setter = true;
							}//end if
						}//end for
					}//end else
				}
			}//end if
		}//end for
		if(!setter)
			label.setText(null);
		else if(isStnd)
			label.setText("<html>"+name+"<br>"+featureType+"<br>"+"("+x+", "+y+")"+"<br>"+"Area: "+auc+"<br>"+"Zscore: "+zscore+"</html>");
		else
			label.setText("<html>"+name+"<br>"+featureType+"<br>"+"("+x+", "+y+")"+"<br>"+"Area: "+auc+"</html>");
		return label;
		
	}
	private class MouseOver implements MouseMotionListener
	{

		JWindow toolTip;
	    JLabel label;
	    Point location = null;
		Color toolTipcolor;
	    public MouseOver()
	    {
	    	label = new JLabel();
	    	toolTipcolor = new Color(176,196,222);
	    	UIManager.put("ToolTip.background",toolTipcolor);
	        label.setBorder(UIManager.getBorder("ToolTip.border"));
	        toolTip = new JWindow(parentFrame);
	        toolTip.getContentPane().setBackground(
	                          UIManager.getColor("ToolTip.background"));
	        toolTip.getContentPane().add(label);
		}
		public void mouseDragged(MouseEvent e)
		{
			int rightButton = e.BUTTON3_DOWN_MASK;
			if ((e.getModifiersEx() & rightButton) == rightButton)
			{
				showPopUpAfterDrag(e);
				repaint();
			}

		}

		@Override
		public void mouseMoved(MouseEvent e)
		{
			//used for mouse coordinates display
			mousePoint = e.getPoint();
			if(parentFrame.locationIsSelected())
			{
			        label = getToolTipFeature(label);
			        if (label.getText() == null)
			        	toolTip.dispose();
			        else
			        {
			        	location = new Point(mousePoint.x+10,mousePoint.y+10);
		                SwingUtilities.convertPointToScreen(location, thisPanel);
		                toolTip.setLocation(location);
		                toolTip.pack();
		                toolTip.setVisible(true);
			        }
			}
			else
				toolTip.dispose();
	       
			repaint();
		}
	}

	private void addPeakNumbers(Graphics2D g) throws Exception
	{
		Font font = new Font("SansSerif", Font.BOLD, 20);
		FontMetrics fm = g.getFontMetrics(font);
		g.setFont(font);

		for (Spectra s : parentFrame.getSpectraList())
			if (s.isVisibleInTable() && s.graphIsShown())
			{
				List<Feature> peaks = s.getLastGeneratedPeakSet();

				int peakCount = 1;
				if (peaks != null)
					for (Feature p : peaks)
					{
						g.setColor(s.getPeakColor());
						String outString = "" + peakCount;

						int xPoint = p.getIndexOfHighestPeak();
												
						float bp = -1;

						if (parentFrame.inBasePairSpace())
						{
							bp = s.getBasePairCalls().get(xPoint);
							
						} else
						{
							bp = xPoint;
						}

						float xPos = PointConverter.getXpixel(bp,
								displayedXRange.lowVal, displayedXRange.diff,
								getWidth());

						float yMax = getHeight() * Y_SCREEN_FRACTION;
						
						float yPos = PointConverter.getYpixel( 
								p.getMaxDisplayed(), displayedYRange.lowVal, 
											displayedYRange.diff, yMax)-5;
						
					
						if( yPos < 20)
							yPos = 20;
						
						if( yPos > yMax-20 )
							yPos = yMax -20;
						
						Point2D.Float aPoint = new Point2D.Float(xPos -
								fm.stringWidth(outString) /2,
								yPos);
						g.drawString(outString, aPoint.x, aPoint.y);

						if (s.getIsStandard()
								&& s.getFileDescriptor().getSizeStandards() != null)
						{
							List<Short> standards = s.getFileDescriptor()
									.getSizeStandards();

							if (peakCount - 1 < standards.size())
							{
								String weightString = ""
										+ standards.get(peakCount - 1);
								Point2D.Float startPoint = new Point2D.Float(
										xPos -fm.stringWidth(weightString)/2, aPoint.y + 20);
								g.setColor(Color.BLACK);
								g.drawString(weightString, startPoint.x,
										startPoint.y);
							}
						}

						peakCount++;
					}
			}
	}

	private Color getShadeColor(Spectra s, Feature f)
	{
		if(f.getFeatureType() == FeatureType.PEAK || f.getFeatureType() == FeatureType.USER_ADDED)
			return s.getPeakColor();
		else if(f.getFeatureType() == FeatureType.ABRUPT_JUMP || f.getFeatureType() == FeatureType.BELOW_HEIGHT_THRESHOLD
				|| f.getFeatureType() == FeatureType.BELOW_WIDTH_THRESHOLD || f.getFeatureType() == FeatureType.INTERSLOPE_INTEVAL_TOO_WIDE
				|| f.getFeatureType() == FeatureType.TWO_UPSLOPES_IN_A_ROW || f.getFeatureType() == FeatureType.USER_REMOVED)
		{
			return s.getPossiblePeakColor();
		}
		else
			return s.getGraphColor();
	}
	
	private void shadeAreaUnderCurve(Graphics2D g)
	{
		for(Spectra s: parentFrame.getSpectraList())
		{
			if(s.isVisibleInTable() && s.graphIsShown())
			{
				DataProvider<Short> data;// = s.getData();
				if(s.getIsSmoothed() && s.isShowSmoothed())//if(s.getIsStandard() || !s.getIsSmoothed())
					data = s.getSmoothedData();
				else
					data = s.getData();
				DataProvider<Float> bp = s.getBasePairCalls();
				Float xVal = getXYvalue(true);
				Float yVal = getXYvalue(false);
				List<Feature> featureList = s.getFeatureList();
				if(xVal != null && yVal != null)
				{
					
					if(parentFrame.inBasePairSpace())
					{
						//xVal = getXYvalue(true);
						//yVal = getXYvalue(false);
						for(Feature f: featureList)
						{
							xVal = getXYvalue(true);
							yVal = getXYvalue(false);
							int lowY = (int) PointConverter.getYpixel(f.getMinValue(), displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION);
							if(f.getIndexOfHighestPeak() > -1 && Math.abs(xVal-s.getBasePairCalls().get(f.getIndexOfHighestPeak()))<1
									&& yVal < f.getMaxDisplayed() && yVal > f.getMinValue())
							{
								float x,y;
								g.setColor(getShadeColor(s, f));
								//int lowY=(int)(getHeight()*Y_SCREEN_FRACTION);
								for(int index = f.getStartIndex(); index < f.getFinalIndex(); index++)
								{
									float basepair = bp.get(index);
									x = PointConverter.getXpixel(basepair, displayedXRange.lowVal, displayedXRange.diff, getWidth());
									y = PointConverter.getYpixel(data.get(index), displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION);
									XYPair xyp = new XYPair((int)x,(int)y);
									g.drawLine(xyp.xPoint,xyp.yPoint, xyp.xPoint, lowY);
								}
							}
						}
					}
					else
					{
						//xVal = getXYvalue(true);
						//yVal = getXYvalue(false);
						for(Feature f: featureList)
						{
							xVal = getXYvalue(true);
							yVal = getXYvalue(false);
							int lowY = (int) PointConverter.getYpixel(f.getMinValue(), displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION);
							if(Math.abs(xVal - f.getIndexOfHighestPeak()) < 10 
									&& yVal < f.getMaxDisplayed() && yVal >= f.getMinValue())
							{
								float x,y;
								g.setColor(getShadeColor(s, f));
								for(int index = f.getStartIndex(); index < f.getFinalIndex(); index++)
								{
									x = PointConverter.getXpixel(index, displayedXRange.lowVal, displayedXRange.diff, getWidth());
									y = PointConverter.getYpixel(data.get(index), displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION);
									XYPair xyp = new XYPair((int)x,(int)y);
									g.drawLine(xyp.xPoint,xyp.yPoint, xyp.xPoint, lowY);
								}
							}
						}
					}
				}
			}
		}
	}
	
	private void addMouseCoordinates(Graphics2D g)
	{
		boolean yes = false;
		NumberFormat formatter = new DecimalFormat("0.00");
		for(Spectra s: parentFrame.getSpectraList())
		{
			if(s.isVisibleInTable() && s.graphIsShown())
				yes = true;
		}
		if(yes)
		{
			g.setColor(Color.BLACK);
			g.drawLine(mousePoint.x, mousePoint.y, mousePoint.x, getHeight());
			g.drawLine(mousePoint.x, mousePoint.y, 0, mousePoint.y);
			float xVal = PointConverter.getXVal(mousePoint.x, displayedXRange.lowVal, displayedXRange.diff, getWidth());
			float yVal = PointConverter.getYval(mousePoint.y, displayedYRange.lowVal, displayedYRange.diff, getHeight()*Y_SCREEN_FRACTION, getHeight());
			g.drawString(formatter.format(xVal), mousePoint.x-50, mousePoint.y-5);
			g.drawString(formatter.format(yVal), mousePoint.x+10,mousePoint.y+10);
		}
		
	}

	private void addXonlyLocation(Graphics2D g,int cushion)
	{
		Font font = new Font("SansSerif", Font.BOLD, 15);
		FontMetrics fm = g.getFontMetrics(font);
		g.setFont(font);
		NumberFormat formatter = new DecimalFormat("0.00");
		for (Spectra s : parentFrame.getSpectraList())
			if (s.isVisibleInTable() && s.graphIsShown())
			{
				List<Feature> peaks = s.getLastGeneratedPeakSet();

				if (peaks != null)
					for (Feature p : peaks)
					{
						g.setColor(s.getPeakColor());
						
						int xPoint = p.getIndexOfHighestPeak();
												
						float bp = -1;
						String outString;
						if (parentFrame.inBasePairSpace())
						{
							bp = s.getBasePairCalls().get(xPoint);
							outString = formatter.format(bp);
							
						} else
						{
							bp = xPoint;
							outString = Integer.toString((int)bp);
						}

						float xPos = PointConverter.getXpixel(bp,
								displayedXRange.lowVal, displayedXRange.diff,
								getWidth());

						float yMax = getHeight() * Y_SCREEN_FRACTION;
						
						float yPos = PointConverter.getYpixel( 
								p.getMaxDisplayed(), displayedYRange.lowVal, 
											displayedYRange.diff, yMax)-5;
						
					
						if( yPos < 20)
							yPos = 20;
						
						if( yPos > yMax-20 )
							yPos = yMax -20;
						
						Point2D.Float aPoint = new Point2D.Float(xPos -
								fm.stringWidth(outString) /2,
								yPos);
						g.drawString(outString, aPoint.x, aPoint.y+cushion);

					}
			}
	}
	private Color getFeatureColor(Spectra s, Feature f)
	{
		Color color = null;

		if (f == parentFrame.getMouseOverFeature())
		{
			color = s.getSelectedPeakColor();
		} else if (f.getFeatureType() == Feature.FeatureType.NON_PEAK)
		{
			color = s.getGraphColor();
		} else if (f.getFeatureType() == Feature.FeatureType.PEAK || f.getFeatureType() == Feature.FeatureType.USER_ADDED)
			color = s.getPeakColor();
		else
			color = s.getPossiblePeakColor();

		return color;
	}

	private float getSkipNum(Spectra s)
	{
		float aDiff = displayedXRange.diff;

		if (parentFrame.inBasePairSpace())
		{
			DataProvider<Float> basepairs = s.getBasePairCalls();
			int lowIndex = basepairs.search(displayedXRange.lowVal);
			int highIndex = basepairs.search(displayedXRange.highVal);

			if (lowIndex < 0)
				lowIndex = -lowIndex - 1;

			if (highIndex < 0)
				highIndex = -highIndex - 1;

			aDiff = highIndex - lowIndex;
		}

		float skip = aDiff / getWidth();

		if (skip < 1)
		{
			skip = 1;
		} else
		{
			if (skip > aDiff / 100)
				skip = aDiff / 100;
		}

		return skip;
	}

	private void calculateGraphPath(Graphics2D g, Spectra s)
			throws NoninvertibleTransformException
	{
		this.displayedXRange = getXRangeToDisplay();
		this.displayedYRange = getYRangeToDisplay();
		g.setRenderingHints(rn);
		g.setStroke(getCurrentStroke());

		float graphYMax = getHeight() * Y_SCREEN_FRACTION;

		float skip = getSkipNum(s);

		List<Feature> featureList = s.getFeatureList();

		int minFeature = featureList.size();
		int maxFeature = 0;
		int numDrawn = 0;

		XYPair oldPoint = new XYPair(-1,-1);
		for (int x = 0; x < featureList.size(); x++)
		{
			Feature f = featureList.get(x);
			float aStart = f.getStartIndex();
			float anEnd = f.getFinalIndex() - 1;

			if (parentFrame.inBasePairSpace())
			{
				aStart = s.getBasePairCalls().get(f.getStartIndex());
				anEnd = s.getBasePairCalls().get(f.getFinalIndex() - 1);
			}
			
			if (aStart >= displayedXRange.lowVal
					&& anEnd <= displayedXRange.highVal)
			{
				oldPoint = drawAFeature(f, skip, graphYMax, s, g,oldPoint);

				maxFeature = Math.max(x, maxFeature);
				minFeature = Math.min(x, minFeature);
				numDrawn++;
			}
		}

		minFeature--;
		maxFeature++;

		oldPoint = new XYPair(-1,-1);
		if (minFeature >= 0 && minFeature < featureList.size())
		{
			drawAFeature(featureList.get(minFeature), skip, graphYMax, s, g,oldPoint);

		}

		if (maxFeature >= 0 && maxFeature < featureList.size())
		{
			drawAFeature(featureList.get(maxFeature), skip, graphYMax, s, g,oldPoint);
		}

		// always draw something
		if (numDrawn == 0)
		{
			for (Feature f : featureList)
				oldPoint = drawAFeature(f, skip, graphYMax, s, g,oldPoint);
		}
	}
	
	private static class XYPair
	{
		private int xPoint;
		private int yPoint;
		
		public XYPair(int xPoint, int yPoint)
		{
			this.xPoint = xPoint;
			this.yPoint = yPoint;
		}
	}

	private XYPair drawAFeature(Feature f, float skip, float graphYMax, Spectra s,
			Graphics2D g2d, XYPair oldPair)
	{
		DataProvider<Short> data;
		if(s.getIsSmoothed() && s.isShowSmoothed())
			data = s.getSmoothedData();
		else
			data = s.getData();//s.getData();
		DataProvider<Float> basepairs = s.getBasePairCalls();
		int thisWidth = getWidth();
	
		g2d.setColor(getFeatureColor(s, f));
		int lastIndex = f.getStartIndex();
		

		boolean firstTime = true;
		f.resetMaxDisplayed();
		
		for (int xIndex = f.getStartIndex(); xIndex < f.getFinalIndex(); xIndex += firstTime ? 1
				: skip)
		{
			// at the end of features, draw more detail to avoid
			// sharp color changes
			if (skip > 1 && xIndex + skip >= f.getFinalIndex())
				skip = 1;

			firstTime = false;
			float ySpacePoint = data.get(xIndex);

			float numPoints = 1;

			while (lastIndex + 1 < xIndex)
			{
				lastIndex++;
				ySpacePoint += data.get(lastIndex);
				numPoints++;
			}

			float bp;

			if (parentFrame.inBasePairSpace())
			{
				bp = basepairs.get(xIndex);
			} else
			{
				bp = xIndex;
			}

			ySpacePoint /= numPoints;
			
			f.setMaxDisplayedIfAppropriate(ySpacePoint);
			
			lastIndex = xIndex;

			int newX = (int) PointConverter.getXpixel(bp,
					displayedXRange.lowVal, displayedXRange.diff, thisWidth);

			int newY = (int) PointConverter.getYpixel(ySpacePoint,
					displayedYRange.lowVal, displayedYRange.diff, graphYMax);

			if (oldPair.xPoint != -1 && newX >=0 && newX <= thisWidth )
			{
				g2d.drawLine(oldPair.xPoint, oldPair.yPoint, newX, newY);
			}

			oldPair = new XYPair(newX,newY);
		}
		
		return oldPair;

	}

	public void setXticNumber(int num)
	{

		if (num > this.basepairRange.highVal)
			this.x_ticNumber = (int) this.basepairRange.highVal;
		else
			this.x_ticNumber = num;
		this.parentFrame.getPrefs().putInt("x_ticNumber", num);
	}

	public int getXticNumber()
	{
		return this.x_ticNumber;
	}

	public void setYticNumber(int num)
	{
		if (num > this.yRange.highVal)
			this.y_ticNumber = (int) this.yRange.highVal;
		else
			this.y_ticNumber = num;
		this.parentFrame.getPrefs().putInt("y_ticNumber", num);
	}

	public int getYticNumber()
	{
		return this.y_ticNumber;
	}

	public float inverseY(int pixel)
	{
		return displayedYRange.highVal - ((float) pixel) / getHeight()
				* displayedYRange.diff;
	}

	/*
	 * given a pixel, may not be in range so it is the invoker's responsibility
	 * to check before using in an array
	 */
	public float inverseX(int pixel)
	{
		return displayedXRange.lowVal + ((float) pixel) / getWidth()
				* displayedXRange.diff;
	}

	private void xTics(Graphics2D g) throws NoninvertibleTransformException
	{
		if( parentFrame.getSpectraList() == null || 
				parentFrame.getSpectraList().size() == 0 || displayedXRange == null)
			return;
		
		boolean oneShown= false;
		
		for( Spectra s : parentFrame.getSpectraList())
			if( s.graphIsShown() )
				oneShown = true;
		
		if(! oneShown)
			return;
		
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(1);

		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		g.setColor(Color.WHITE);
		g.fillRect(0, (int) graphYmax, getWidth(), (int) graphYmax);
		g.setColor(Color.BLACK);
		g.drawLine(35, (int) graphYmax, getWidth(), (int) graphYmax);

		List<Float> splits = displayedXRange.getSplits(10);
		
		for (float split : splits)
		{	
			int newX = (int) PointConverter.getXpixel(split,
					displayedXRange.lowVal, displayedXRange.diff, getWidth());

			g.setColor(Color.BLACK);
			g.drawLine(newX, (int) graphYmax, newX, getHeight() - 25);

			if (parentFrame.inBasePairSpace())
			{
				g.drawString("" + nf.format(split) + " ", newX-5,
						getHeight() - 10);
			} else
			{
				g.drawString("" + (int)split+ " ", newX-5,
								getHeight() - 10);
			}
		}

		g.setColor(Color.BLACK);
		g.drawString(parentFrame.inBasePairSpace() ? "Base pair" : "index",
				getWidth() / 2, getHeight());
	}

	private void yTics(Graphics2D g) throws NoninvertibleTransformException
	{
		if( parentFrame.getSpectraList() == null || 
				parentFrame.getSpectraList().size() == 0  || displayedYRange == null)
			return;
		

		boolean oneShown= false;
		
		for( Spectra s : parentFrame.getSpectraList())
			if( s.graphIsShown() )
				oneShown = true;
		
		if(! oneShown)
			return;

		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 35, (int) graphYmax);
		g.setColor(Color.BLACK);
		g.drawLine(0, 0, 0, (int) graphYmax);
		
		List<Float> splits = displayedYRange.getSplits(10);
		for( float split : splits )
		{
			int newY = (int) PointConverter.getYpixel(split,
					displayedYRange.lowVal, displayedYRange.diff, graphYmax);
			
			if (split>= yRange.lowVal && split<= yRange.highVal)
			{
				g.drawLine(20, newY, 0, newY);
				g.drawString("" + ((int) (split)), 0, newY);
			}
		}
		
		//g.drawLine(20, 0, x2, y2)
	}

	public void setXaxisBasePairBounds()
	{
		float maxX = Float.MIN_VALUE;
		float minX = Float.MAX_VALUE;

		for (Spectra s : parentFrame.getSpectraList())
			if ( s.graphIsShown() && s.isVisibleInTable())
			{
				DataProvider<Float> bpCalls = s.getFileDescriptor()
						.getLastSetOfBasePairCalls();

				if( bpCalls != null && bpCalls.getLength()> 2)
				{
					maxX = Math.max(bpCalls.get(bpCalls.getLength()-1), maxX);
					minX = Math.min(bpCalls.get(0), minX);

				}
			}

//		if (this.basepairRange.highVal != maxX
	//			|| this.basepairRange.lowVal != minX)
		{
			this.basepairRange = new Range(minX, maxX);

			// image cache is not implemented and is not likely to come back
			//for (Spectra s : parentFrame.getSpectraList())
			//	s.clearImageCache();
		}
	}

	public void setYAxisIntensityBounds()
	{
		int maxY = Integer.MIN_VALUE;
		int minY = Integer.MAX_VALUE;

		for (Spectra s : parentFrame.getSpectraList())
			if (s.graphIsShown() && s.isVisibleInTable())
			{
				maxY = Math.max(s.getMaxVal(), maxY);
				minY = Math.min(s.getMinVal(), minY);
			}

		if (this.yRange.lowVal != minY || this.yRange.highVal != maxY)
		{
			this.yRange = new Range(minY, maxY);

			for (Spectra s : parentFrame.getSpectraList())
				s.clearImageCache();
		}
	}

	public void setXaxisIndexBounds()
	{
		int maxX = 100;

		for (Spectra s : parentFrame.getSpectraList())
			if (  s.graphIsShown() && s.isVisibleInTable())
			{
				maxX = Math.max(s.getData().getLength(), maxX);
			}

		if (maxX != this.indexRange.highVal)
		{
			this.indexRange = new Range(0, maxX);

			for (Spectra s : parentFrame.getSpectraList())
				s.clearImageCache();
		}

	}

	private List<BufferedImage> getImages() throws Exception
	{
		List<Spectra> spectra = parentFrame.getSpectraList();
		List<Callable<BufferedImage>> callingList = new ArrayList<Callable<BufferedImage>>();
		int numPermits = Runtime.getRuntime().availableProcessors() + 1;

		if (numPermits < 1)
			numPermits = 1;

		ExecutorService myEx = Executors.newFixedThreadPool(numPermits);
		// ExecutorService myEx = Executors.newSingleThreadExecutor();
		for (Spectra s : spectra)
		{
			if (s.graphIsShown() && s.isVisibleInTable())
			{
				GraphWorker aWorker = new GraphWorker(s);
				callingList.add(aWorker);
			}
		}
		List<Future<BufferedImage>> futureList = myEx.invokeAll(callingList);

		List<BufferedImage> returnList = new ArrayList<BufferedImage>();

		for (Future<BufferedImage> f : futureList)
			returnList.add(f.get());

		return returnList;
	}

	private void rerenderImages() throws Exception
	{
		setYAxisIntensityBounds();
		// this must be called before parentFrame.
		parentFrame.enableBasePairSpaceIfAppropriate();

		setXaxisIndexBounds();

		setXaxisBasePairBounds();

		List<BufferedImage> images = getImages();

		offScreenImage = new BufferedImage(getWidth(), getHeight(),
				BufferedImage.TRANSLUCENT);
		Graphics2D g2 = offScreenImage.createGraphics();
		g2.setColor(Color.WHITE);
		g2.fillRect(0, 0, getWidth(), getHeight());

		for (BufferedImage i : images)
			g2.drawImage(i, 0, 0, this);

		forceRedraw = false;
	}

	private void rerenderAxis() throws Exception
	{
		BufferedImage bi = new BufferedImage(getWidth(), getHeight(),
				BufferedImage.TRANSLUCENT);
		Graphics2D big = bi.createGraphics();

		xTics(big);
		yTics(big);
		axisBi = bi;
	}

	/*
	 * Should only be called on the AWT thread.
	 * 
	 */
	public void paintAsVectors(Graphics2D g) throws Exception
	{
		setCursor( new Cursor( Cursor.WAIT_CURSOR));
		super.paint(g);

		setYAxisIntensityBounds();
		// this must be called before parentFrame.
		parentFrame.enableBasePairSpaceIfAppropriate();

		setXaxisIndexBounds();

		setXaxisBasePairBounds();

		List<Spectra> spectra = parentFrame.getSpectraList();
		
		for (Spectra s : spectra)
		{
			if (s.graphIsShown() && s.isVisibleInTable())
			{
				calculateGraphPath(g, s);
			}
		}
		
		if (parentFrame.axesShouldBeDisplayed())
		{
			xTics(g);
			yTics(g);
		}
		
		if (parentFrame.peakNumbersAreSelected())
		{
			addPeakNumbers(g);
		}	
		if(parentFrame.locationXisSelected())
		{
			if(parentFrame.peakNumbersAreSelected())
				addXonlyLocation(g, -20);
			else
				addXonlyLocation(g,0);
		}
		setCursor( new Cursor( Cursor.HAND_CURSOR));
	}
	
	public void paint(Graphics g)
	{
		parentFrame.getHorizontalBar().setFireListener(false);
		parentFrame.getVertialBar().setFireListener(false);
		super.paint(g);

		try
		{
			lastImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TRANSLUCENT);

			if (forceRedraw || oldWidth != getWidth()
					|| oldHeight != getHeight())
			{
				rerenderImages();
				axisDirty = true;
			}

			Graphics2D g2 = (Graphics2D) lastImage.getGraphics();
			g2.drawImage(offScreenImage, 0, 0, this);


			if (parentFrame.peakNumbersAreSelected())
			{
				BufferedImage bi = new BufferedImage(getWidth(), getHeight(),
						BufferedImage.TRANSLUCENT);
				Graphics2D big = bi.createGraphics();
				addPeakNumbers(big);
				g2.drawImage(bi, 0, 0, this);
			}
			//shades area under peak features
			if(parentFrame.shadePeaksIsSelected())
			{
				BufferedImage bi = new BufferedImage(getWidth(), getHeight(),
						BufferedImage.TRANSLUCENT);
				Graphics2D big = bi.createGraphics();
				shadeAreaUnderCurve(big);
				g2.drawImage(bi, 0, 0, this);
			}
			//this adds X only coordinate information to peaks
			if(parentFrame.locationXisSelected())
			{
				BufferedImage bi = new BufferedImage(getWidth(), getHeight(),
						BufferedImage.TRANSLUCENT);
				Graphics2D big = bi.createGraphics();
				if(parentFrame.peakNumbersAreSelected())
					addXonlyLocation(big,-20);
				else
					addXonlyLocation(big,0);
				g2.drawImage(bi, 0, 0, this);
			}
			if (parentFrame.axesShouldBeDisplayed())
			{
				if (axisDirty)
					rerenderAxis();

				axisDirty = false;
				g2.drawImage(axisBi, 0, 0, this);
			}
			g.drawImage(lastImage,0,0,this);

			oldWidth = getWidth();
			oldHeight = getHeight();
		} catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(parentFrame, "Unexpected error:\n"
					+ e.getMessage());

		}

		parentFrame.getHorizontalBar().setFireListener(true);
		parentFrame.getVertialBar().setFireListener(true);
	}

	public void setStrokeSize(float size)
	{
		this.parentFrame.getPrefs().putFloat("strokeSize", size);
		this.strokeSize = size;
		bs = new BasicStroke(this.strokeSize, BasicStroke.CAP_ROUND,
				BasicStroke.JOIN_MITER);
		forceRedraw();
	}

	public float getStrokeSize()
	{
		return this.strokeSize;
	}

	private BasicStroke getCurrentStroke()
	{
		return bs;
	}

	public void takePicture()
	{
		if( lastImage == null )
		{
			JOptionPane.showMessageDialog(parentFrame, "No message to save!");
		}
		
		JFileChooser fc = new JFileChooser();
		fc.setDialogTitle(".png");
		fc.setSelectedFile(new File("Spectra" + picCount + ".png"));
		fc.setCurrentDirectory(new File(parentFrame.getPrefs().get(pngName, "")));
				
		fc.setFileFilter(new FileFilter()
		{
			public String getDescription()
			{
				return "png file";
			}

			public boolean accept(File f)
			{
				if( f.isDirectory() ||  f.getName().toLowerCase().endsWith("png"))
					return true;
				
				return false;
			}
		});
		
		if (fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
		{
			File file = fc.getSelectedFile();
			
			int choice = JOptionPane.YES_OPTION;
			
			File parentDir = file.getParentFile();
			if(parentDir != null)
				parentFrame.getPrefs().put(pngName, parentDir.getAbsolutePath());
			
			if( file.exists())
			{
				choice = JOptionPane.showConfirmDialog(parentFrame, 
						file.getName() + " exists.  Replace?", "Replace?", 
						JOptionPane.YES_NO_OPTION);
			}
			
			if( choice == JOptionPane.YES_OPTION)
			{
				try
				{
					ImageIO.write(lastImage, "PNG", file.getAbsoluteFile());
					picCount++;
				}
				catch(Exception ex)
				{
					ex.printStackTrace();
					JOptionPane.showMessageDialog(parentFrame, "Could not save image\n" + 
							ex.getMessage());
				}
			}
		}
		
	}

	private class GraphWorker implements Callable<BufferedImage>
	{
		private final Spectra s;

		public GraphWorker(Spectra s)
		{
			this.s = s;
		}

		@Override
		public BufferedImage call() throws Exception
		{
			// image caching is disable. Increased complexity with minimal gains
			// in performance

			// CachedBufferedImage cbi = s.getBufferedImage();
			// int width = getWidth();
			// int height = getHeight();

			/*
			 * Caching is diabled for now if( cbi != null &&
			 * cbi.getNanoTimeStamp() > getTimestampLastChange() &&
			 * cbi.getWidth() == width && cbi.getHeight() == height) { // the
			 * cached image is ok return cbi.getImage(); }
			 */
			// s.setBufferedImageIfAppropriate(image, width, height, System
			// .nanoTime());

			BufferedImage image = new BufferedImage(getWidth(), getHeight(),
					BufferedImage.TRANSLUCENT);

			Graphics2D g = (Graphics2D) image.getGraphics();
			calculateGraphPath(g,this.s);

			g.dispose();
			
			return image;
		}
	}

	private class DragStarter extends MouseAdapter
	{
		@Override
		public void mousePressed(MouseEvent e)
		{
			dragStartScreen = e.getPoint();
			//dragEndScreen = null;
			dragEndScreen = e.getPoint();
			switch (e.getButton())
			{
			case MouseEvent.BUTTON1:

				if (xZoomFactor > 1 || yZoomFactor > 1)
				{
					setCursor(new Cursor(Cursor.HAND_CURSOR));
					panning = true;
				}
				break;

			}
		}

		@Override
		public void mouseReleased(MouseEvent e)
		{
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			panning = false;
			autoPan.stop();
		}
	}

	public void keyZoomX(boolean zoomIn)
	{
		if(zoomIn)
			xZoomFactor += 2;
		else
			xZoomFactor -= 2;
		
		if(xZoomFactor > maxXZoomFactor)
			xZoomFactor = maxXZoomFactor;
		if(xZoomFactor < 1)
		{
			xZoomFactor = 1;
			xPanFactor = 0.5f;
		}
		forceRedraw();
	}
	
	public void keyZoomY(boolean zoomIn)
	{
		if(zoomIn)
			yZoomFactor += 2;
		else
			yZoomFactor -= 2;
		if(yZoomFactor > maxYZoomFactor)
			yZoomFactor = maxYZoomFactor;
		if(yZoomFactor < 1)
		{
			yZoomFactor = 1;
			yPanFactor = 0.5f;
		}
		forceRedraw();
	}
	
	public void imagePanByKeyEvent(Point p)
	{
		dragStartScreen = new Point(getWidth()/2,getHeight()/2);
		imagePan(p);
	}
	
	public void imagePan(Point p)
	{
		if (p == null)
			return;

		dragEndScreen = p;// e.getPoint();

		if (xZoomFactor > 1)
		{
			float xPixelDiff = (dragEndScreen.x - dragStartScreen.x) / 10f;

			float numIndexes = xPixelDiff / getWidth()
					* displayedIndexRange.diff;

			float scaleFactor = numIndexes / indexRange.diff;

			xPanFactor += scaleFactor;

			if (xPanFactor < 0)
				xPanFactor = 0;

			if (xPanFactor > 1)
				xPanFactor = 1;

		}

		if (yZoomFactor > 1)
		{
			float yPixelDiff = (dragEndScreen.y - dragStartScreen.y) / 10f;
			float scaleFactor = yPixelDiff / getHeight();

			yPanFactor += scaleFactor;

			if (yPanFactor < 0)
				yPanFactor = 0;

			if (yPanFactor > 1)
				yPanFactor = 1;
		}

		forceRedraw();
	}

	private class Dragging extends MouseMotionAdapter
	{
		public void mouseDragged(MouseEvent e)
		{
			if (panning)
			{
				if (e.getX() >= getWidth() || e.getX() <= 0
						|| e.getY() >= getHeight() || e.getY() <= 0)
				{
					autoPanPoint = e.getPoint();
					autoPan.start();
				} else
					imagePan(e.getPoint());

			}
		}
	}

	private class PopUpHandler implements MouseListener
	{

		public void mousePressed(MouseEvent e)
		{
			showPopUp(e);
		}

		public void mouseReleased(MouseEvent e)
		{
			showPopUp(e); // for windows
		}

		public void mouseClicked(MouseEvent e)
		{
		}

		public void mouseEntered(MouseEvent e)
		{
		}

		public void mouseExited(MouseEvent e)
		{
		}
	}

	private void showPopUp(MouseEvent e)
	{
		if (e.isPopupTrigger())
		{
			parentFrame.getPopUpMenu().setVisible(false);
			parentFrame.getPopUpMenu().show(e.getComponent(), e.getX(),
					e.getY());
			parentFrame.getPopUpMenu().setVisible(true);
		}
	}

	private void showPopUpAfterDrag(MouseEvent e)
	{
		parentFrame.getPopUpMenu().setVisible(false);
		parentFrame.getPopUpMenu().show(this, e.getX(), e.getY());
		parentFrame.getPopUpMenu().setVisible(true);
	}
}
