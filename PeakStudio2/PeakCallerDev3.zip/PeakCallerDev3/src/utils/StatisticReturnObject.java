
package utils;


public class StatisticReturnObject
{
    private final double score;
    private final double pValue;
    
    public StatisticReturnObject(double score, double pValue)
    {
        this.score = score;
        this.pValue = pValue;
    }
    
    
    public double getPValue()
    {
        return pValue;
    }
    public double getScore()
    {
        return score;
    }
    
    
}
