package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class PythonProcessWrapper
{

	public PythonProcessWrapper( String[] cmdArgs ) throws Exception
	{
		/*
		for ( int x=0; x < cmdArgs.length; x++ )
				System.out.print(cmdArgs[x] + " " );
			
			System.out.println();	
			*/
		System.out.println(" Now starting RunTime & Process for Python");
		Runtime r = Runtime.getRuntime();
		
		Process p = Runtime.getRuntime().exec(cmdArgs);
		
		BufferedReader br = new BufferedReader (new InputStreamReader(p.getInputStream()));
		
		String s;
		
		for( String s1 : cmdArgs)
			System.out.print(s1 + " ");
		
		while ((s = br.readLine ())!= null)
		{
    		System.out.println (s);
		}
			
		System.out.println(" \nwe are this far, process ran, next up is the bloody p.waitFor() statement !");
		
		p.waitFor();
		p.destroy();
	}
}
