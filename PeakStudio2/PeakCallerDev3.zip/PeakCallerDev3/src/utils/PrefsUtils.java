package utils;
import java.util.*;
import java.util.prefs.*;

public class PrefsUtils
{

	/**
     * Puts a list into the preferences starting with "0" then "1"
     */
    public static void putList( Preferences preferences, List list, String key )
    {
    	List<String> strList = new ArrayList<String>();
    	for(int x = 0; x<list.size();x++)
    		strList.add(list.get(x).toString());
        putList( preferences.node( key ), strList );
    }
    
    /**
     * Puts a list into the preferences starting with "0" then "1"
     */
    public static void putList( Preferences preferences, List list )
    {
        if( preferences == null )
        {
            throw new IllegalArgumentException( "Preferences not set." );
        }
        for( int index = 0; list != null && index < list.size(); index++ )
        {
            Object value = list.get( index );
            preferences.put( ""+index, value == null ? null : value.toString() );
        }
    }

    /**
     * Gets a List from the preferences, starting with "0", then "1" etc
     */
    public static List<Integer> getList( Preferences preferences, String key )
    {
        return getList( preferences.node( key ) );
    }
    
    /**
     * Gets a List from the preferences, starting with "0", then "1" etc
     */
    public static List<Integer> getList( Preferences preferences )
    {
        if( preferences == null )
        {
            throw new IllegalArgumentException( "Preferences not set." );
        }

        List list = new ArrayList();
    
        for( int index = 0; index < 1000; index++ )
        {
            String value = preferences.get( ""+index, null );
            if( value == null ) 
            	break;
            list.add( value );
        }
        List<Integer> intList = new ArrayList<Integer>();
        for(int x=0; x<list.size(); x++)
        	intList.add(Integer.parseInt(list.get(x).toString()));
        return intList;
    }
    

    public static void main( String[] args )
    {
        try
        {
           

            Preferences prefs = Preferences.userNodeForPackage( System.class );
            
           
            List<Integer> intList = new ArrayList<Integer>();
            for(int x=0; x<10; x++)
            {
            	intList.add(x);
            }
            PrefsUtils.putList(prefs, intList, "TestStoreList");
            //List<String> difList = PrefsUtil.getList(prefs, "TestStoreList");
            List<Integer> difList = new ArrayList<Integer>();
            if(difList.isEmpty())
            	System.out.println("list is empty");
            
            difList = PrefsUtils.getList(prefs, "TestStoreList");
            if(!difList.isEmpty())
            	System.out.println("List in now full");
            for(Integer i: difList)
            	System.out.println(i.toString());
        }
        catch( Exception e )
        {
            e.printStackTrace();
        }
    }
}
