package utils;

public class PointConverter 
{

	public static float getXpixel(float x_current, float xStartValBP, float xRangeBp,float width)
	{	
		return (width)*(x_current-xStartValBP)/ xRangeBp;
	}
	
	public static float getYpixel(float y_current, float yStartVal, float yRange,float yFloor)
	{
		return yFloor-yFloor*(y_current-yStartVal)/yRange;
	}
	
	public static float getXVal(float pix,float xMin,float xRange,float width)
	{
		return pix*xRange/width+xMin;
	}
	
	public static float getYval(float pix,float yMin,float yRange, float yFloor,float height)
	{
		return (yFloor-pix)*yRange/height+yMin;
	}
	
}
