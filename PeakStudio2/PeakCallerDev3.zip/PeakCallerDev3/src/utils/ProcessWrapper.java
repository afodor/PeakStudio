package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ProcessWrapper
{
	
	public ProcessWrapper( String[] cmdArgs ) throws Exception
	{
		/*
		for ( int x=0; x < cmdArgs.length; x++ )
				System.out.print(cmdArgs[x] + " " );
			
			System.out.println();	
			*/
		System.out.println(" Now starting RunTime");
		Runtime r = Runtime.getRuntime();
		System.out.println(" Now starting Process");
		Process p = r.exec(cmdArgs);
		System.out.println(" Process Complete");
		
		BufferedReader br = new BufferedReader (new InputStreamReader(p.getErrorStream()));
		
		String s;
		
		for( String s1 : cmdArgs)
			System.out.print(s1 + " ");
		
		System.out.println();
		
		while ((s = br.readLine ())!= null)
		{
    		System.out.println (s);
		}
				
		p.waitFor();
		p.destroy();
	}
}
