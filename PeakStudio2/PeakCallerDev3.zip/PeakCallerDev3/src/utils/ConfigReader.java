package utils;

import java.io.InputStream;

import java.util.Properties;

public class ConfigReader
{
	public static final String PROPERTIES_FILE_NAME="arisa.properties";
	public static final String LOG_DIRECTORY = "LOG_DIRECTORY";
	public static final String MATT_CF_DIR = "MATT_CF_DIR";
	public static final String ZEISEL_DIR = "ZEISEL_DIR";
	public static final String JOSH_DIR = "JOSH_DIR";
	public static final String ARISA_RAW_DATA = "ARISA_RAW_DATA";
	public static final String PYTHON_EXE = "PYTHON_EXE";
	private static ConfigReader configReader = null;
	private static Properties props = new Properties();
	
	/*
	 *  Lazy initialized and thread safe.
	 */
	private static synchronized ConfigReader getConfigReader() throws Exception
	{
		if ( configReader == null ) 
		{
			configReader = new ConfigReader();
		}
		
		return configReader;
	}

	private ConfigReader() throws Exception
	{
		Object o = new Object();
		
		// ugly syntax that just looks for a file anwhere along the class path
		InputStream in = o.getClass().getClassLoader().getSystemResourceAsStream( PROPERTIES_FILE_NAME );
		
		if ( in == null )
			throw new Exception("Error!  Could not find " + PROPERTIES_FILE_NAME + " anywhere on the current classpath");		

		props.load( in );
		
	}
	
	private static String getAProperty(String namedProperty ) throws Exception
	{
		Object obj = props.get( namedProperty );
		
		if ( obj == null ) 
			throw new Exception("Error!  Could not find " + namedProperty + " in " + PROPERTIES_FILE_NAME );
		
		return obj.toString();
	}
	
	public static String getMattCFDirectory() throws Exception
	{
		return getConfigReader().getAProperty(MATT_CF_DIR);
	}
	
	public static String getZeiselDirectory() throws Exception
	{
		return getConfigReader().getAProperty(ZEISEL_DIR);
	}
	
	public static String getLogDirectory() throws Exception
	{
		return getConfigReader().getAProperty(LOG_DIRECTORY);
	}
	

	public static String getJoshDirectory() throws Exception
	{
		return getConfigReader().getAProperty(JOSH_DIR);
	}
	
	public static String getArisaRawDatDir() throws Exception
	{
		return getConfigReader().getAProperty(ARISA_RAW_DATA);
	}
	
	public static String getPythonExe() throws Exception
	{
		return getConfigReader().getAProperty(PYTHON_EXE);
	}
	
	
}
