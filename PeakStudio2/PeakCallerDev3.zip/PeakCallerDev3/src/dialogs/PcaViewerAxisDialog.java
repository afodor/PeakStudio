package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import pca.PcaFrame;
import pca.PcaPanel;

public class PcaViewerAxisDialog extends JDialog
{
	private static final long serialVersionUID = 1L;
	private PcaPanel panel;
	private PcaFrame parent;
	private DecimalFormat formatter;
	private JPanel mainPanel,center_panel;
	private DefaultComboBoxModel dropBoxModelX = new DefaultComboBoxModel();
	private DefaultComboBoxModel dropBoxModelY = new DefaultComboBoxModel();
	private JComboBox dropBoxX,dropBoxY;
	private PcaViewerAxisDialog thisDialog;
	public PcaViewerAxisDialog(PcaPanel panel,PcaFrame frame) 
	{
		super(frame,"Change Axis");
		this.panel = panel;
		this.parent = frame;
		thisDialog = this;
		formatter = new DecimalFormat(".00");
		init();
	}
	
	private void init()
	{
		this.setSize(500,90);
		this.setLocationRelativeTo(this.parent);
		this.setResizable(false);
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		center_panel = new JPanel();
		center_panel.setLayout(new BorderLayout());
		center_panel.add(buildXPanel(),BorderLayout.WEST);
		center_panel.add(buildYpanel(),BorderLayout.EAST);
		mainPanel.add(center_panel,BorderLayout.NORTH);
		mainPanel.add(buildCloseButton(),BorderLayout.SOUTH);
		this.add(mainPanel);
		
	}
	private JPanel buildYpanel()
	{
		JPanel y_panel = new JPanel();
		dropBoxY = new JComboBox(dropBoxModelY);
		y_panel.add(new JLabel("Y Axis"));
		y_panel.add(dropBoxY);
		dropBoxY.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				panel.setYcomp(dropBoxY.getSelectedIndex());
				panel.forceRedraw();
				
			}
		});
		return y_panel;
	}
	private JPanel buildXPanel()
	{
		JPanel x_panel = new JPanel();
		dropBoxX = new JComboBox(dropBoxModelX);
		x_panel.add(new JLabel("X Axis"));
		x_panel.add(dropBoxX);
		dropBoxX.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				panel.setXcomp(dropBoxX.getSelectedIndex());
				panel.forceRedraw();
			}
		});
		return x_panel;
	}
	private JPanel buildCloseButton()
	{
		JPanel close_panel = new JPanel();
		JButton close = new JButton("Close");
		close.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				thisDialog.setVisible(false);
				thisDialog.dispose();
				System.gc();
				
			}
		});
		close_panel.add(close);
		return close_panel;
	}

	public void setUpXdropMenu(int index)
	{
		dropBoxModelX.removeAllElements();
		for(int x=0; x<this.parent.getVarExplained().size(); x++)
		{
			String s = formatter.format(this.parent.getVarExplained().get(x)*100);
			int comp = x+1;
			dropBoxModelX.addElement("Comp_"+comp+" "+s+"%");
		}
		dropBoxX.setSelectedIndex(index);
		
	}
	public void setUpYdropMenu(int index)
	{
		dropBoxModelY.removeAllElements();
		for(int y=0; y<this.parent.getVarExplained().size(); y++)
		{
			String s = formatter.format(this.parent.getVarExplained().get(y)*100);
			int comp = y+1;
			dropBoxModelY.addElement("Comp_"+comp+" "+s+"%");
		}
		dropBoxY.setSelectedIndex(index);
	}
}
