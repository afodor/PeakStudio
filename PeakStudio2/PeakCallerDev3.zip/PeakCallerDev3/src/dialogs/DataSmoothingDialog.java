package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
//import java.util.RandomAccess;
//import java.util.concurrent.Semaphore;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import experimentSets.Spectra;
import viewer.FsaFrame;

public class DataSmoothingDialog extends JDialog implements ActionListener
{
	
	private static final long serialVersionUID = 13495823823094L;
	private final FsaFrame fsaFrame;
	private JTextField regWindowText,regIncText,sgSmoothText,sgPolyDegree;
	private JButton close = new JButton("Close");
	private JButton runSmooth = new JButton("Smooth All");
	private JButton applySelectedSpectra = new JButton("Smooth Selected Only");
	private MySmoothWorker smoothWorker;
	private final String REGWINSIZE = "90";
	private final String REGINCSIZE = "150";
	private final String SGWINSIZE = "24";
	private final String SGPOLYDEGREE = "2";
	//private int NUM_THREADS = Runtime.getRuntime().availableProcessors()+1;
	private MyProgressBarDialog mpd;
	
	public DataSmoothingDialog(FsaFrame frame)
	{
		super(frame,"Data Smoothing");
		this.fsaFrame = frame;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(400,350);
		this.setLocationRelativeTo(frame);
		this.setResizable(true);
		buildDialog();
		
	}
	
	private void buildDialog()
	{
		
		this.add(buildPanel());
	}
	
	private JPanel buildPanel()
	{
		JPanel mp = new JPanel();
		mp.setSize(250,250);
		mp.setLayout(new BorderLayout());
		mp.add(new JPanel(),BorderLayout.EAST);
		mp.add(new JPanel(),BorderLayout.WEST);
		mp.add(textPanel(),BorderLayout.CENTER);
		mp.add(buttonsPanel(),BorderLayout.SOUTH);
		return mp;
	}
	private JPanel buttonsPanel()
	{
		toggleActionEnabledAsApproproiate();
		JPanel butt = new JPanel();
		butt.setLayout(new FlowLayout());
		close.setEnabled(true);
		runSmooth.setEnabled(true);
		close.addActionListener(this);
		runSmooth.addActionListener(this);
		butt.add(runSmooth);
		butt.add(applySelectedSpectra);
		butt.add(close);
		return butt;
		
	}
	private JPanel textPanel()
	{
		regWindowText = new JTextField(5);
		regWindowText.setPreferredSize(new Dimension(25, 25));
		regWindowText.setEditable(true);
		regWindowText.setBackground(Color.WHITE);
		regWindowText.setText(REGWINSIZE);
		regIncText = new JTextField(5);
		regIncText.setEditable(true);
		regIncText.setBackground(Color.WHITE);
		regIncText.setText(REGINCSIZE);
		sgSmoothText = new JTextField(5);
		sgSmoothText.setEditable(true);
		sgSmoothText.setBackground(Color.WHITE);
		sgSmoothText.setText(SGWINSIZE);
		sgPolyDegree = new JTextField(5);
		sgPolyDegree.setEditable(true);
		sgPolyDegree.setBackground(Color.WHITE);
		sgPolyDegree.setText(SGPOLYDEGREE);
		JLabel sgSmooth = new JLabel("<html>Savitzky-Golay<br> Smoothing Window</html>");
		JLabel regWinSize = new JLabel("Baseline Window");
		JLabel regIncSize = new JLabel("<html>Baseline Window<br> Increment</html>");
		JLabel sgPoly = new JLabel("<html>Savitzky-Golay<br> Polynomial Degree</html>");
		
		JPanel dataPanel = new JPanel();
		dataPanel.setSize(200, 200);
		dataPanel.setBorder(BorderFactory.createTitledBorder("Smoothing Parameters"));
		dataPanel.setLayout(new GridLayout(1, 3));
		
		JPanel labels = new JPanel();
		labels.setLayout(new GridLayout(4,1));
		labels.add(regWinSize);
		labels.add(regIncSize);
		labels.add(sgSmooth);
		labels.add(sgPoly);
		JPanel text = new JPanel();
		text.setLayout(new GridLayout(4,2));
		text.add(regWindowText);
		text.add(new JPanel());
		text.add(regIncText);
		text.add(new JPanel());
		text.add(sgSmoothText);
		text.add(new JPanel());
		text.add(sgPolyDegree);
		dataPanel.add(labels);
		dataPanel.add(text);
		
		return dataPanel;
	}

	private void toggleActionEnabledAsApproproiate()
	{
		applySelectedSpectra.addActionListener(this);
		if( fsaFrame.getSpectraJTable().getSelectedRowCount() == 0  )
			applySelectedSpectra.setEnabled(false);
		else
			applySelectedSpectra.setEnabled(true);
	}
	public static boolean isNumber(String s)
	{
		try
		{
			Double.parseDouble(s);
		}
		catch(Exception x)
		{
			return false;
		}
		return true;
		
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == close)
		{
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		if(e.getSource() == runSmooth)
		{
			//long startTime = System.currentTimeMillis();
			callSmoothWorker(this.fsaFrame.getSpectraList());
			//long endTime = System.currentTimeMillis();
			//System.out.println("Time in seconds "+(endTime-startTime)/1000d);
		}
		else if (e.getSource() == applySelectedSpectra)
		{
			int[] selectedRows = this.fsaFrame.getSpectraJTable().getSelectedRows();
			List<Spectra> spectra = new ArrayList<Spectra>();
			for(Integer i: selectedRows)
			{
				int index = this.fsaFrame.getSpectraJTable().getModel().getSpectraRowNumber(i);
				spectra.add(this.fsaFrame.getSpectraList().get(index));
			}
			callSmoothWorker(spectra);
		}
		
	}
	private void callSmoothWorker(List<Spectra> spectraList)
	{
		mpd = new MyProgressBarDialog("Smoothing Data", spectraList.size());
		mpd.getCancelButton().addActionListener(new ActionListener() 
		{
			
			@Override
			public void actionPerformed(ActionEvent ae)
			{
				smoothWorker.cancel(true);
				
			}
		});
		int rws=Integer.parseInt(REGWINSIZE);
		int rwi=Integer.parseInt(REGINCSIZE);
		int sgw=Integer.parseInt(SGWINSIZE);
		int sgp=Integer.parseInt(SGPOLYDEGREE);
		if(isNumber(regWindowText.getText()))
			rws = Integer.parseInt(regWindowText.getText());
		if(isNumber(regIncText.getText()))
			rwi = Integer.parseInt(regIncText.getText());
		if(isNumber(sgSmoothText.getText()))
			sgw = Integer.parseInt(sgSmoothText.getText());
		if(isNumber(sgPolyDegree.getText()))
			sgp = Integer.parseInt(sgPolyDegree.getText());
		
		smoothWorker = new MySmoothWorker(mpd, mpd.getProgressBar(), rws,rwi,sgw,sgp,spectraList);
		smoothWorker.execute();
		mpd.setVisible(true);
	}
	
	
	private class MyProgressBarDialog extends JDialog
	{
		private static final long serialVersionUID = 1L;
		private String string;
		private JProgressBar jbar;
		private int max;
		private JButton cancel;
		public MyProgressBarDialog(String s, int max) 
		{
			super(fsaFrame,"Working...");
			this.string = s;
			this.max = max;
			init();
			this.setAlwaysOnTop(true);
			this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			this.setSize(200,100);
			this.setLocationRelativeTo(null);
			this.setModal(true);
			this.pack();
			this.setResizable(true);
		}
		public JProgressBar getProgressBar()
		{
			return this.jbar;
		}
		public JButton getCancelButton()
		{
			return this.cancel;
		}
		private void init()
		{
			try
			{
				URL imageUrl = fsaFrame.getClass().getResource("PSlogoSmall.png");
				Image logoImage = ImageIO.read(imageUrl);
				ImageIcon icon = new ImageIcon(logoImage);
				jbar = new JProgressBar(0,max);
				jbar.setPreferredSize(new Dimension(200,20));
				cancel = new JButton("Cancel");
				jbar.setString("Working");
				jbar.setStringPainted(true);
				jbar.setValue(0); 
				JLabel label = new JLabel(this.string+": ");
				JPanel center_panel = new JPanel();
				center_panel.setSize(200, 75);
				center_panel.add(new JLabel(icon));
				center_panel.add(jbar);
				JPanel bot_panel = new JPanel();
				bot_panel.setSize(200, 75);
				bot_panel.add(cancel);
				JPanel top_panel = new JPanel();
				top_panel.add(label);
				this.getContentPane().add(top_panel,BorderLayout.NORTH);
				this.getContentPane().add(center_panel, BorderLayout.CENTER);
				this.getContentPane().add(bot_panel,BorderLayout.SOUTH);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(fsaFrame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	private class MySmoothWorker extends SwingWorker<Void, Void>
	{
		JDialog jdialog;
		JProgressBar jbar;
		int rws,ris,sgw,sgp;
		List<Spectra> spectraList;
		//List<Thread> threads = new ArrayList<Thread>();
		
		public MySmoothWorker(JDialog dialog, JProgressBar jbar,int rws,int ris,int sgw, int sgp,List<Spectra> spectraList)
		{
			this.jdialog = dialog;
			this.jbar = jbar;
			this.rws = rws;
			this.ris = ris;
			this.sgw = sgw;
			this.sgp = sgp;
			this.spectraList = spectraList;
			
		}

		@Override
		protected Void doInBackground() throws Exception
		{
			int x=0;
			//Semaphore sema = new Semaphore(NUM_THREADS);
			for( Spectra s : this.spectraList)
			{
				if(isCancelled())
				{
					for( Spectra sp : this.spectraList)
					{
						sp.cancelSmoothing();
					}
					return null;
				/*for(Thread t: threads)
						t.interrupt();
					
					int count =0;
					while(count < NUM_THREADS)
					{
						sema.acquire();
						count++;
					}*/
					
					
				}
				
				s.smoothData(rws,ris,sgw,sgp);
				s.setIsSmoothed(true);
				s.setShowSmoothed(true);
				if(!s.getIsStandard())
					s.callFeatures();
				if(s.getIsStandard())
					s.resetStndHeights(true);
				
				SwingUtilities.invokeLater(new SetterClass(x));
					
				x++;
				//SwingUtilities.invokeLater(new SetterClass(x));
				/*sema.acquire();
				Smoother sm = new Smoother(sema,rws,ris,sgw,sgp,s,this.jbar,x);
				Thread th = new Thread(sm);
				th.start();
				threads.add(th);
				x++;*/
				
				
			}
			/*int numAcquired =0;
			
			while( numAcquired < NUM_THREADS)
			{
				sema.acquire();
				numAcquired++;
			}*/
			return null;
		}
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = fsaFrame.getSpectraList().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		protected void done() 
		{
			if(isCancelled())
			{
				try
				{
					for( Spectra sp : this.spectraList)
					{
						sp.cancelSmoothing();
					}
					fsaFrame.changeSpectraView(false);
				}
				catch(Exception e)
				{
					e.printStackTrace();
					System.out.println("Cancel Smoothing Failed..");
				}
				
			}
			else
				fsaFrame.changeSpectraView(true);
			jdialog.dispose();
			fsaFrame.getSpectraJTable().getModel().fireTableDataChanged();
			fsaFrame.getFsaPanel().forceRedraw();
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			fsaFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			//this.parent.dispose();
		}
		
	}
	//Attempt at multi-threading
	/*private class Smoother implements Runnable
	{
		Semaphore s;
		int rws;
		int ris;
		int sgw;
		int sgp;
		Spectra spec;
		JProgressBar jbar;
		int x;
		Smoother(Semaphore s,int rws,int ris,int sgw, int sgp,Spectra spec,JProgressBar jbar,int x)
		{
			this.s = s;
			this.rws = rws;
			this.ris = ris;
			this.sgw = sgw;
			this.sgp = sgp;
			this.spec = spec;
			this.jbar = jbar;
			this.x = x;
			
		}

		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = fsaFrame.getSpectraList().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		public void run() 
		{
			try
			{
				SwingUtilities.invokeLater(new SetterClass(x));
				spec.smoothData(rws,ris,sgw,sgp);
				spec.setIsSmoothed(true);
				spec.setShowSmoothed(true);
				if(!spec.getIsStandard())
					spec.callFeatures();
				if(spec.getIsStandard())
					spec.resetStndHeights(true);
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("SemaPhore crash!!");
			}
			s.release();
			
		}
		
	}*/
	

}
