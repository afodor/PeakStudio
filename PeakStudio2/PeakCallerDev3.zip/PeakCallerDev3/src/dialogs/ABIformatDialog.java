package dialogs;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.prefs.Preferences;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import dataProvider.DataProvider;

import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Feature;
import experimentSets.Spectra;

import viewer.FsaFrame;

public class ABIformatDialog extends JDialog implements ItemListener
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final FsaFrame parent;
	private final HashMap<Byte,String> dyeMap;
	private final HashMap<String, Byte> dyeChannelMap;
	private List<Byte> dataChannel = new ArrayList<Byte>();
	private Set<Byte> fsaChannels = new HashSet<Byte>();
	private List<? extends AbstractFSAFileDescriptor> fsaFiles;
	private JPanel mainPanel,chkBoxPanel;
	private boolean isAreaIndexSpace = true;
	
	public ABIformatDialog(FsaFrame frame)
	{
		this.setTitle("Export Sizing Table");
		this.parent = frame;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(310,150);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		this.fsaFiles = this.parent.getExperimentSet().getFileDescriptors();
		getCurrentFSAchannels();
		this.dyeMap = buildDyeMap();
		this.dyeChannelMap = buildChannelMap();
		buildCheckBoxes();
		buildPanels();
		this.setVisible(true);
		
	}
	
	private void getCurrentFSAchannels()
	{
		for(AbstractFSAFileDescriptor f: this.fsaFiles)
		{
			fsaChannels.add(f.getStandardChannel());
			List<Byte> dc = f.getDataChannels();
			for(Byte b: dc)
				fsaChannels.add(b);
		}
	}
	
	private void buildPanels()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setSize(300, 150);
		mainPanel.add(chkBoxPanel,BorderLayout.NORTH);
		mainPanel.add(buildAreaCheck(),BorderLayout.CENTER);
		mainPanel.add(buildButtons(),BorderLayout.SOUTH);
		this.add(mainPanel);
	}
	
	private JPanel buildAreaCheck()
	{
		JPanel ckP = new JPanel();
		JCheckBox ckb = new JCheckBox("Area in Index Space");
		ckb.setSelected(true);
		ckb.addItemListener(new ItemListener() 
		{
			
			@Override
			public void itemStateChanged(ItemEvent e) 
			{
				JCheckBox jc = (JCheckBox) e.getSource();
				if(jc.isSelected())
					isAreaIndexSpace = true;
				else
					isAreaIndexSpace = false;
				
			}
		});
		ckP.add(ckb);
		return ckP;
	}
	private void buildCheckBoxes()
	{
		chkBoxPanel = new JPanel();
		chkBoxPanel.setLayout(new FlowLayout());
		chkBoxPanel.setBorder(BorderFactory.createTitledBorder("Dye Colors"));
		chkBoxPanel.setSize(300,150);
		JCheckBox[] ret = new JCheckBox[dyeMap.size()];
		List<Byte> nums = new ArrayList<Byte>(dyeMap.keySet());
		Collections.sort(nums);
		for(int x=0; x<nums.size(); x++)
		{
			ret[x] = new JCheckBox(dyeMap.get(nums.get(x)));
			ret[x].addItemListener(this);
			if(dyeMap.get(nums.get(x)).equals("B") && fsaChannels.contains(nums.get(x)) || dyeMap.get(nums.get(x)).equals("O") && fsaChannels.contains(nums.get(x)))
			{
				ret[x].setSelected(true);
				ret[x].setEnabled(true);
			}
			if(!fsaChannels.contains(nums.get(x)))
				ret[x].setEnabled(false);
			
			
			chkBoxPanel.add(ret[x]);
		}
	}
	
	private JPanel buildButtons()
	{
		JPanel butts = new JPanel();
		butts.setLayout(new GridLayout(1,2));
		JButton exp = new JButton("Export");
		exp.setSize(10, 10);
		exp.addActionListener(new ActionListener()
		{
			
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				exportPeaks();
				exitDialog();
			}
		});
		butts.add(exp);
		JButton cancel = new JButton("Cancel");
		cancel.setSize(10, 10);
		cancel.addActionListener(new ActionListener()
		{
			
			@Override
			public void actionPerformed(ActionEvent arg0) 
			{
				//System.out.println("CANCELING...");
				exitDialog();
			}
		});
		butts.add(cancel);
		return butts;	
	}
	
	private void exportPeaks()
	{
		JFileChooser chooser = new JFileChooser();
		Preferences prefs = this.parent.getPrefs();
		chooser.setCurrentDirectory(new File(prefs.get(this.parent.getPrefName(), "")));
		chooser.setSelectedFile(new File("ABI_Format"+".txt"));
		if(chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = chooser.getSelectedFile();
			if(!f.getAbsolutePath().endsWith(".txt"))
			{
				if(f.getAbsolutePath().lastIndexOf('.') > -1)
				{
					String newPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf('.'));
					File f2 = new File(newPath+".txt");
					f = f2;
				}
				else
				{
					f = new File(f.getAbsoluteFile()+".txt");
				}
			}
			try
			{
				Set<Byte> slectedChannels = new HashSet<Byte>();
				for(Byte b: dataChannel)
					slectedChannels.add(b);
				writeOutFile(f,slectedChannels);
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(this, e.getMessage() + "\n"
						+ "Saving File Failed\n"
						+ "Check to make sure approiate files are open\n"
						+ "Restaring PeakStudio is recommended\n");
			}
			
		}
	}
	
	private void writeOutFile(File f,Set<Byte> channels) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(f));
		DecimalFormat df = new DecimalFormat("0.00");
		for(AbstractFSAFileDescriptor as: this.fsaFiles)
		{
			if(channels.contains(as.getStandardChannel()))
			{
				Spectra stnd = as.getStandardSpectra();
				DataProvider<Float> bpCalls = stnd.getBasePairCalls();
				List<Feature> peaks = stnd.getLastGeneratedPeakSet();
				
				for(int x=0; x<peaks.size(); x++)
				{
					writer.write(dyeMap.get(as.getStandardChannel())+","+(x+1)+"\t"+as.getFSAFile().getName()+"\t");
					writer.write(df.format(bpCalls.get(peaks.get(x).getIndexOfHighestPeak()))+"\t");
					writer.write(peaks.get(x).getHeight()+"\t"+df.format(peaks.get(x).getAUC(isAreaIndexSpace))+"\t"+peaks.get(x).getIndexOfHighestPeak()+"\n");
				}
			}
			List<Spectra> data = as.getDataSpectra();
			for(Spectra s: data)
			{
				if(channels.contains((byte)s.getDataChannel()))
				{
					DataProvider<Float> dBpCalls = s.getBasePairCalls();
					List<Feature> peaks = s.getLastGeneratedPeakSet();
					for(int x=0; x<peaks.size(); x++)
					{
						writer.write(dyeMap.get((byte)s.getDataChannel())+","+(x+1)+"\t"+as.getFSAFile().getName()+"\t");
						writer.write(df.format(dBpCalls.get(peaks.get(x).getIndexOfHighestPeak()))+"\t");
						writer.write(peaks.get(x).getHeight()+"\t"+df.format(peaks.get(x).getAUC(isAreaIndexSpace))+"\t"+peaks.get(x).getIndexOfHighestPeak()+"\n");
					}
					
				}
			}
		
		}
		writer.flush(); writer.close();
		
	}

	private HashMap<Byte, String> buildDyeMap()
	{
		HashMap<Byte, String> retMap = new HashMap<Byte, String>();
		retMap.put((byte)1, "B");
		retMap.put((byte)2, "G");
		retMap.put((byte)3, "Y");
		retMap.put((byte)4, "R");
		retMap.put((byte)105, "O");
		return retMap;
	}

	private HashMap<String, Byte> buildChannelMap()
	{
		HashMap<String, Byte> ret = new HashMap<String, Byte>();
		ret.put("B", (byte) 1);
		ret.put("G", (byte)2);
		ret.put("Y",(byte)3);
		ret.put("R", (byte)4);
		ret.put("O",(byte)105);
		return ret;
	}
	private void exitDialog()
	{
		this.setVisible(false);
		this.dispose();
		System.gc();
	}	
	
	@Override
	public void itemStateChanged(ItemEvent e) 
	{
		JCheckBox jc = (JCheckBox)e.getSource();
		String s = jc.getText();
		if(jc.isSelected())
		{
			dataChannel.add(dyeChannelMap.get(s));
		}
		else
		{
			dataChannel.remove(dyeChannelMap.get(s));
		}
		Collections.sort(dataChannel);
		
	}
	
	

}
