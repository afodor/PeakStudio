package dialogs;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import viewer.FsaFrame;
import viewer.FsaPanel;

public class GraphPrefDialog extends JDialog implements ActionListener,ChangeListener
{
	private static final long serialVersionUID = 1L;
	private FsaFrame frame;
	private FsaPanel panel;
	private JButton closeButton = new JButton("Close");
	private JSlider slider;
	private int precision = 100;
	private final int SLIDER_MIN = 1;
	private final int SLIDER_MAX = 1000;
	private final int SLIDER_Tic = 100;
	private final int MINOR_TIC = 50;
	private final int MAJOR_TIC = 150;
	private StrokingPanel strokeDisplay;
	
	public GraphPrefDialog(FsaFrame frame)
	{
		super(frame,"Line Thickness");
		this.frame = frame;
		this.panel = this.frame.getFsaPanel();
		this.setSize(300,185);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		init();
	}
	
	private void init()
	{
		slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN,SLIDER_MAX,SLIDER_Tic);
		this.strokeDisplay = new StrokingPanel();
		slider.setMinorTickSpacing(MINOR_TIC);
        slider.setMajorTickSpacing(MAJOR_TIC);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setBackground(Color.WHITE);
        slider.addChangeListener(this);
        Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
		labelTable.put( SLIDER_MIN, new JLabel("Thin") );
		labelTable.put( SLIDER_MAX, new JLabel("Thick") );
		slider.setLabelTable(labelTable);
		closeButton.addActionListener(this);
		closeButton.setSize(10,10);
		JPanel button = new JPanel();
		button.add(closeButton);
        add(slider, BorderLayout.NORTH);
        add(strokeDisplay,BorderLayout.CENTER);
        add(button,BorderLayout.SOUTH);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == closeButton)
		{
			
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		
	}
	public void stateChanged(ChangeEvent e) 
	{
		JSlider source = (JSlider)e.getSource();
        float fps = source.getValue();
        strokeDisplay.setStroke(fps/precision);
        this.panel.setStrokeSize(fps/precision);
	}
	public void setDialog()
	{
		slider.setValue(getLineStoke());
		strokeDisplay.setStroke(panel.getStrokeSize());
	}
	
	public int getLineStoke()
	{
		return (int)panel.getStrokeSize() * precision;
	}
	
	public class StrokingPanel extends JPanel
	{
		private static final long serialVersionUID = 1L;
		BasicStroke bs;
		float strokeSize = 0.9f;
		public StrokingPanel()
		{
			setSize(100,50);
			setBackground(Color.WHITE);
			setBorder(BorderFactory.createTitledBorder("Line Thinkness"));
			bs = new BasicStroke(this.strokeSize,BasicStroke.CAP_ROUND,BasicStroke.JOIN_MITER);
		}
		public void paintComponent(Graphics g)
		{
			Graphics2D g2 = (Graphics2D)g;
			g2.setColor(Color.WHITE);
			g2.fillRect(0, 0, getWidth(), getHeight());
			g2.setColor(Color.BLACK);
			g2.setStroke(bs);
			g2.drawLine((int)(getWidth()*0.2), (int)(getHeight()*0.5),(int)(getWidth()*0.75), (int)(getHeight()*0.5));
		}
		public void setStroke(float size)
		{
			this.strokeSize = size;
			bs = new BasicStroke(this.strokeSize,BasicStroke.CAP_ROUND,BasicStroke.JOIN_MITER);
			repaint();
		}
		public float getStrokeSize()
		{
			return strokeSize;
		}
	}


}
