package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Hashtable;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import viewer.FsaFrame;
import viewer.FsaPanel;

public class DetailLevelDialog extends JDialog implements ActionListener,ChangeListener
{
	private static final long serialVersionUID = 1L;
	private FsaFrame frame;
	private FsaPanel panel;
	private JButton closeButton = new JButton("Close");
	private JSlider slider;
	private final int SLIDER_MIN = 1;
	private final int SLIDER_MAX = 10;
	private final int SLIDER_Tic = 1;
	
	public DetailLevelDialog(FsaFrame frame)
	{
		super(frame,"Graph detail");
		this.frame = frame;
		this.panel = this.frame.getFsaPanel();
		this.setSize(300,185);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		init();
	}
	
	@Override
	public void stateChanged(ChangeEvent e)
	{
		panel.getParentFrame().setDetailLevel((float)slider.getValue());
		panel.forceRedraw();
	}
	
	private void init()
	{
		slider = new JSlider(JSlider.HORIZONTAL, SLIDER_MIN,SLIDER_MAX,SLIDER_Tic);
        slider.setPaintTicks(true);
        slider.setPaintLabels(true);
        slider.setBackground(Color.WHITE);
        slider.addChangeListener(this);
        slider.setValue((int)frame.getDetailLevel());
        Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
		labelTable.put( SLIDER_MIN, new JLabel("Less detail") );
		labelTable.put( SLIDER_MAX, new JLabel("More detail") );
		slider.setLabelTable(labelTable);
		closeButton.addActionListener(this);
		closeButton.setSize(10,10);
		JPanel button = new JPanel();
		button.add(closeButton);
        add(slider, BorderLayout.NORTH);
        add(button,BorderLayout.SOUTH);
        JTextArea area = new JTextArea();
        area.setText("\nThis control is in development.\nIt's use is currently discouraged!");
        area.setEditable(false);
        add(area,BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == closeButton)
		{
			
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		
	}

	public int getDetailValue()
	{
		return slider.getValue();
	}
	
}

