package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import java.awt.event.ItemListener;
import binning.AbstractPeakCallBinningMethod;
import binning.TRFLPSimpleBin;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.AverageDistance;
import de.linuxusers.clustering.linkage.FurthestNeighbour;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.NearestNeighbour;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;
import experimentSets.StandardWeights;
import experimentSets.VirtualSpectra;
import viewer.FsaFrame;

public class TrflpDialogFromSetup //extends JDialog implements ActionListener, ItemListener
{
	/*
	
	private static final long serialVersionUID = 1L;
	private FsaFrame frame;
	private JTable table;
	private JPanel mainPanel,cOptionsPanel, clusterPanel,botPanel, panelOptionsPanel, clusterMethodPanel;
	private JRadioButton AvgDistance,NearestNeighbor, FurthestNeighbor, Wards, YesBinary, NoBinary, SimpleBin, RandomBin;
	private JTextArea weights;
	private final JTextPane binaryThresholdTextPane = new JTextPane();
	private final JTextPane simpleBinSizeTextPane = new JTextPane();
	private final JTextPane startRangeTextPane = new JTextPane();
	private final JTextPane stopRangeTextPane = new JTextPane();
	private JTextPane setupFilePane = new JTextPane();
	private final JTextPane randomNumberofTimesTextPane = new JTextPane();
	private JPanel infoLaunchBox = new JPanel();
	private JPanel infoClusterBox = new JPanel();
	private JButton launchGoButton = new JButton("Create virtual spectra");
	private JButton launchClusterButton = new JButton("Create TRFLP Cluster");
	private JButton cancelButton = new JButton("Cancel");
	private JButton outputDirButton = new JButton("Choose Output Dir");
	private JButton setupFileButton = new JButton("Click to choose file");
	private JButton launchParameterButton = new JButton("Edit Parameters");
	private JButton launchStandardsButton = new JButton("Edit Standards");
	private JButton thresholdButton = new JButton("Choose threshold");
	private JButton simpleBinSizeButton = new JButton("Set Simple Bin size");
	private JButton randomBinIterButton = new JButton("Set # Random Runs");
	private JButton setRangeButton = new JButton("Set Spectra Range");
	private List<AbstractFSAFileDescriptor> expList;
	private DefaultComboBoxModel dropBoxModel = new DefaultComboBoxModel();
	private JComboBox dropBox;
	private List<StandardWeights> list;
	private int[] rows;
	private final int CH_DEFAULT = 3;
	private File outPutDir, setupFile;
	private ArrayList<AbstractPeakCallBinningMethod> bmList = new ArrayList<AbstractPeakCallBinningMethod>();
	private boolean isBinary, launchCluster;
	private double threshold = 10;
	LinkageMethod linkageMethod = new WardsMethod();
	private int bmMethodArray = 0;
	private float simpleBinSize = 3;
	private int randomNumofIterations = 10;
	private String currentBinSizingMethod = "Simple Bin";
	private String currentClusterMethod = "Googly";
	private int startRange = 25;
	private int stopRange = 900;
	List<VirtualSpectra> spectraList = new ArrayList<VirtualSpectra>(); 
	
	
	public TrflpDialogFromSetup(FsaFrame frame)
	{
		super(frame,"TRFLP Virtual Spectra");
		this.frame = frame;
		outPutDir = frame.getDirectory();
		this.setModal(true);
		this.setSize(760,280);
		this.setLocationRelativeTo(this.frame);
		
		if (this.frame.getStandardWeights() == null)
		{
			setUpSizeStandards();
		}
		setupFile = frame.getDirectory();
		createDialog();
		
		bmMethodArray = 0;	
		this.frame.setResizable(true);		
	}
	
	private void createDialog()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		buildTabPanelOptions();
		buildtabPanelLaunch();
		buildClusterMethodRadioMethodBox();
		buildTabPanelCluster();
		
		JTabbedPane tabbedPane = new JTabbedPane();
			
		tabbedPane.addTab("Choose TRFLP virtual Spectra options", null, panelOptionsPanel,
		                  "Where you files located at ???");
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);

		
		tabbedPane.addTab("Launch TRFLP Virtual Spectra",null, botPanel,
		                      "I hope you setup the file correctly....");
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);
		
		tabbedPane.addTab("Choose Cluster Method",null, clusterMethodPanel,
        "I hope you setup the file correctly....");
		tabbedPane.setMnemonicAt(2, KeyEvent.VK_3);
		
		tabbedPane.addTab("Launch T-RFLP Cluster",null, clusterPanel,
        "Let's Pick Wards because we think it is the best");
		tabbedPane.setMnemonicAt(3, KeyEvent.VK_4);
		
		mainPanel.add(tabbedPane);
		this.add(mainPanel);
		this.setResizable(true);
	}
	
	
	
	private void buildTabPanelOptions()
	{
		panelOptionsPanel = new JPanel();
		panelOptionsPanel.setLayout(new BorderLayout());
		
		panelOptionsPanel.setBorder(BorderFactory.createTitledBorder("Monkey"));
		
		buildTRFLPOptionsPanel();
		panelOptionsPanel.add(cOptionsPanel,BorderLayout.NORTH);
		
		JPanel binaryPanel = new JPanel();
		binaryPanel.setBorder(BorderFactory.createTitledBorder("Do you want to use Binary format?"));
		
		ButtonGroup buttonGroup = new ButtonGroup();
				 
	    NoBinary = new JRadioButton("No");
	    buttonGroup.add(NoBinary);
	    binaryPanel.add(NoBinary, BorderLayout.CENTER);
	    NoBinary.setSelected(true);
	    NoBinary.addActionListener(this);
	    
	    YesBinary = new JRadioButton("Yes");
	    buttonGroup.add(YesBinary);
	    binaryPanel.add(YesBinary, BorderLayout.CENTER);
	    YesBinary.addActionListener(this);		
	    
	    binaryThresholdTextPane.setPreferredSize(new Dimension(30, 20));
	    binaryThresholdTextPane.setText(String.valueOf(threshold));
	    binaryThresholdTextPane.setBackground(Color.darkGray);
	   	    
	    thresholdButton.setToolTipText("Change binary threshold level");
	    thresholdButton.setEnabled(false);
	    thresholdButton.addActionListener(this);
	    binaryPanel.add(thresholdButton, BorderLayout.CENTER);
	    binaryPanel.add(binaryThresholdTextPane,BorderLayout.SOUTH);
		panelOptionsPanel.add(binaryPanel,BorderLayout.CENTER);
		
		int maxRangeofSizeStandards = calcSmallestBiggestSizeStandard();
		stopRange = maxRangeofSizeStandards;
		
		JPanel rangePanel = new JPanel();
		rangePanel.setBorder(BorderFactory.createTitledBorder("Set the nucleotide range" +
				" for ARISA analysis (default = 25 to 900, current largest size standard is "
				+ maxRangeofSizeStandards +")"));
		
		startRangeTextPane.setPreferredSize(new Dimension(70, 20));
		startRangeTextPane.setText(String.valueOf(startRange));
		startRangeTextPane.setBackground(Color.white);
		
		
		stopRangeTextPane.setPreferredSize(new Dimension(70, 20));
		stopRangeTextPane.setText(String.valueOf(stopRange));
		stopRangeTextPane.setBackground(Color.white);
		
		setRangeButton.setToolTipText("Press me to make the new ranges from the boxes to my left");
		setRangeButton.setEnabled(true);
		setRangeButton.addActionListener(this);
	    
		rangePanel.add(startRangeTextPane);
		rangePanel.add(stopRangeTextPane);
		rangePanel.add(setRangeButton);		
		panelOptionsPanel.add(rangePanel,BorderLayout.SOUTH);
	}
	
	private void buildtabPanelLaunch()
	{
		botPanel = new JPanel(); // will center everything in center of panel
		botPanel.setLayout(new GridBagLayout());
				
		JPanel inner4Panel = new JPanel(); // will hold buttons in north, and text summary in SOUth
		inner4Panel.setLayout(new BorderLayout());
		
		JPanel inner4UpperPanel = new JPanel(); // will hold buttons
		inner4UpperPanel.setLayout(new GridBagLayout());
		
		launchParameterButton.addActionListener(this);
		inner4UpperPanel.add(launchParameterButton);
		launchStandardsButton.addActionListener(this);
		inner4UpperPanel.add(launchStandardsButton);
		outputDirButton.addActionListener(this);
		inner4UpperPanel.add(outputDirButton);
		cancelButton.addActionListener(this);
		inner4UpperPanel.add(cancelButton);
		launchGoButton.addActionListener(this);
		launchGoButton.setEnabled(true);
		if (setupFile.isDirectory() || !(setupFile.exists()))
			{
				launchGoButton.setEnabled(false);
				launchGoButton.setText("No Setup file chosen, can't launch");
			}
		
		inner4UpperPanel.add(launchGoButton);
		inner4Panel.add(inner4UpperPanel,BorderLayout.SOUTH);
		
		JPanel inner4LowerPanel = new JPanel(); // will data summary info
		inner4LowerPanel.setLayout(new GridBagLayout());
		
		updateInfoBox();
		inner4LowerPanel.add(infoLaunchBox);
		
		inner4Panel.add(inner4LowerPanel,BorderLayout.NORTH);
		botPanel.add(inner4Panel); 	
	}
	
	private void buildClusterMethodRadioMethodBox()
    {
		
		clusterMethodPanel = new JPanel();
		clusterMethodPanel.setLayout(new GridLayout(2,2));
		
		ButtonGroup buttonGroup = new ButtonGroup();
		AvgDistance = new JRadioButton("Average Distance (UPGMA)");
	    AvgDistance.addActionListener(this);
		buttonGroup.add(AvgDistance);
		clusterMethodPanel.add(AvgDistance);
	   
	    NearestNeighbor = new JRadioButton("Nearest Neighbor (Single Linkage)");
	    NearestNeighbor.addActionListener(this);
	    buttonGroup.add(NearestNeighbor);
	    clusterMethodPanel.add(NearestNeighbor);
	    
	    FurthestNeighbor = new JRadioButton("Furthest Neighbor (Complete Linkage)");
	    FurthestNeighbor.addActionListener(this);
	    buttonGroup.add(FurthestNeighbor);
	    clusterMethodPanel.add(FurthestNeighbor);
	    
	    Wards = new JRadioButton("Wards");
	    Wards.addActionListener(this);
	    buttonGroup.add(Wards);
	    clusterMethodPanel.add(Wards);
	    
	    Wards.setSelected(true);
	    currentClusterMethod = "Wards";
    }
	
	private void buildTabPanelCluster()
	{
		clusterPanel = new JPanel(); // will center everything in center of panel
		clusterPanel.setLayout(new GridBagLayout());
				
		JPanel inner4Panel = new JPanel(); // will hold buttons in north, and text summary in SOUth
		inner4Panel.setLayout(new BorderLayout());
		
		JPanel inner4UpperPanel = new JPanel(); // will hold buttons
		inner4UpperPanel.setLayout(new GridBagLayout());
		
		launchParameterButton.addActionListener(this);
		inner4UpperPanel.add(launchParameterButton);
		launchStandardsButton.addActionListener(this);
		inner4UpperPanel.add(launchStandardsButton);
		outputDirButton.addActionListener(this);
		inner4UpperPanel.add(outputDirButton);
		cancelButton.addActionListener(this);
		inner4UpperPanel.add(cancelButton);
		
		
		launchClusterButton.addActionListener(this);
		launchClusterButton.setEnabled(true);
		if (setupFile.isDirectory())
			{
			launchClusterButton.setEnabled(false);
			launchClusterButton.setText("No Setup file chosen, can't launch");
			}
		
		inner4UpperPanel.add(launchClusterButton);
		inner4Panel.add(inner4UpperPanel,BorderLayout.SOUTH);
		
		JPanel inner4LowerPanel = new JPanel(); // will data summary info
		inner4LowerPanel.setLayout(new GridBagLayout());
		
		updateInfoClusterBox();
		inner4LowerPanel.add(infoClusterBox);
		
		inner4Panel.add(inner4LowerPanel,BorderLayout.NORTH);
		clusterPanel.add(inner4Panel); 	
	}
	
	
	private void updateInfoBox()
	{
		infoLaunchBox.removeAll();
		infoLaunchBox.setLayout(new BorderLayout());
		
		String info = "Setup File = " + setupFile.getAbsolutePath();
		JLabel label1 = new JLabel();
		label1.setText(info);
		
		infoLaunchBox.add(label1,BorderLayout.NORTH);
		
		info =  "Number of Experiments = " + frame.getSpectraList().size() + "                  Bin Size = " + (int) simpleBinSize +
			"                   Binary format = " + isBinary + "         Starting Range: " + startRange;
		
		JLabel label2 = new JLabel();
		label2.setText(info);
		infoLaunchBox.add(label2,BorderLayout.CENTER);
		
		info = "                        Bin Sizing Method = " + currentBinSizingMethod;
		info +=  "                      Stopping Range: " + stopRange; 
		
		JLabel label3 = new JLabel();
		label3.setText(info);
		infoLaunchBox.add(label3,BorderLayout.SOUTH);
		infoLaunchBox.setSize(700,280);
		infoLaunchBox.setBackground(Color.PINK) ;
		infoLaunchBox.repaint();
		infoLaunchBox.validate();
	}
	
	private void updateInfoClusterBox()
	{
		infoClusterBox.removeAll();
		infoClusterBox.setLayout(new BorderLayout());
		
		String info = "Setup File = " + setupFile.getAbsolutePath();
		JLabel label1 = new JLabel();
		label1.setText(info);
		
		infoClusterBox.add(label1,BorderLayout.NORTH);
		
		info =  "Number of Experiments = " + frame.getSpectraList().size() + "                  Bin Size = " + (int) simpleBinSize +
			"                   Binary format = " + isBinary + "         Starting Range: " + startRange;
		
		JLabel label2 = new JLabel();
		label2.setText(info);
		infoClusterBox.add(label2,BorderLayout.CENTER);
		info = "Clustering Method = " + currentClusterMethod;
		info += "                        Bin Sizing Method = " + currentBinSizingMethod;
		info +=  "                      Stopping Range: " + stopRange; 
		
		JLabel label3 = new JLabel();
		label3.setText(info);
		infoClusterBox.add(label3,BorderLayout.SOUTH);
		infoClusterBox.setSize(700,280);
		infoClusterBox.setBackground(Color.PINK) ;
		infoClusterBox.repaint();
		infoClusterBox.validate();
	}

	private void buildTRFLPOptionsPanel() 
	{
		cOptionsPanel = new JPanel();
		cOptionsPanel.setLayout(new GridLayout(2,3));
		
		cOptionsPanel.setBorder(BorderFactory.createTitledBorder("TRFLP options:"));
			
		
		setupFilePane.setPreferredSize(new Dimension(30, 20));
		setupFilePane.setText("No file yet selected");
		setupFilePane.setBackground(Color.white);
	    
		setupFileButton.setToolTipText("Select a setup File");
		setupFileButton.setEnabled(true);
		setupFileButton.addActionListener(this);
		
		cOptionsPanel.add(new JLabel("Select your Set up file: "));
	    cOptionsPanel.add(setupFileButton);
	    cOptionsPanel.add(setupFilePane);
		
		simpleBinSizeTextPane.setPreferredSize(new Dimension(30, 20));
	    simpleBinSizeTextPane.setText(String.valueOf(simpleBinSize));
	    simpleBinSizeTextPane.setBackground(Color.white);
	    
	    simpleBinSizeButton.setToolTipText("Choose size of Bins");
	    simpleBinSizeButton.setEnabled(true);
	    simpleBinSizeButton.addActionListener(this);
	    
	    cOptionsPanel.add(new JLabel("Choose Bin Size: "));
	    cOptionsPanel.add(simpleBinSizeButton);
	    cOptionsPanel.add(simpleBinSizeTextPane);  
	}
	
	public void setDisplay()
	{
		try
		{
			this.table = this.frame.getTable();
			this.rows = this.table.getSelectedRows();
			//displaySelectedFiles();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void displayWeights(List<Integer> list)
	{
		weights.setText(null);
		for(Integer i: list)
			weights.append(i+"\n");
	}
	
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == dropBox)
		{
			int index = dropBox.getSelectedIndex();
			if(!list.isEmpty() && index > -1)
				displayWeights(list.get(index).getWeights());
		}
		
		if(e.getSource() == cancelButton)
		{
			this.setVisible(false);
		}
		if(e.getSource() == launchGoButton)
		{
			this.setVisible(false);
			try 
			{
				frame.setCursor(new Cursor(Cursor.WAIT_CURSOR));
				launchVirtualSpectraMaker();
				frame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			} catch (Exception e1) 
			{
				e1.printStackTrace();
			}
		}
		if(e.getSource() == launchClusterButton)
		{
			this.setVisible(false);
			try 
			{
				frame.setCursor(new Cursor(Cursor.WAIT_CURSOR));
				launchClusterAnalysis();
				frame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			} catch (Exception e1) 
			{
				e1.printStackTrace();
			}
		}
		
		
		if(e.getSource() == launchStandardsButton)
		{
			StndDialog  stdSetDialog = new StndDialog(frame);
			stdSetDialog.setVisible(true);	
		}
		if(e.getSource() == launchParameterButton)
		{
			ParameterSetDialog psd = new ParameterSetDialog(frame);
			psd.setSpectra();
			psd.setVisible(true);
		}
		if(e.getSource() == outputDirButton)
		{
			loadOutPutDirFile();
			System.out.println("We launched the dir change, the dis is " + frame.getDirectory().getName());
			updateInfoBox();
		}
		
		if(e.getSource() == setupFileButton)
		{
			loadSetUpFile();
			System.out.println("We chosen a setup file, the dir is " + frame.getDirectory().getName());
			updateInfoBox();
			updateInfoClusterBox();
			setupFilePane.setText(setupFile.getName());
			launchGoButton.setEnabled(true);
			launchGoButton.setText("LAUNCH VIRTUAL SPECTRA");
			launchClusterButton.setEnabled(true);
			launchClusterButton.setText("LAUNCH TRFLP CLUSTER");
		}
		
		if (e.getSource() == NoBinary)
		{
			isBinary = false;
			thresholdButton.setEnabled(false);
			binaryThresholdTextPane.setBackground(Color.darkGray);
			updateInfoBox();
		}
		
		if (e.getSource() ==YesBinary)
		{
			isBinary = true;
			thresholdButton.setEnabled(true);
			binaryThresholdTextPane.setBackground(Color.white);
			
		}
		
		if (e.getSource() ==thresholdButton)
		{
			if (ParameterSetDialog.isNumber(binaryThresholdTextPane.getText()))
			{
				threshold = Double.valueOf(binaryThresholdTextPane.getText());
			}
			binaryThresholdTextPane.setText(String.valueOf(threshold));  // reverting back to original threshold number
			
		}
		
		if (e.getSource() ==FurthestNeighbor)
		{
			currentClusterMethod = "Furthest Neighbour";
			System.out.println("Cluster method is now " + currentClusterMethod);
		}
		
		if (e.getSource() ==NearestNeighbor)
		{
			currentClusterMethod = "Nearest Neighbour";
			System.out.println("Cluster method is now " + currentClusterMethod);
		}
		
		if (e.getSource() ==AvgDistance)
		{
			currentClusterMethod = "Average Distance";
			System.out.println("Cluster method is now " + currentClusterMethod);
			
		}
		
		if (e.getSource() ==Wards)
		{
			currentClusterMethod = "Wards";
			System.out.println("Cluster method is now " + currentClusterMethod);
			
		}
		if (e.getSource() ==SimpleBin)
		{
			bmMethodArray = 0;  //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(false);
			randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
			randomNumberofTimesTextPane.setEnabled(false);
			
			simpleBinSizeButton.setEnabled(true);
			simpleBinSizeTextPane.setBackground(Color.WHITE);
			simpleBinSizeTextPane.setEnabled(true);
			
			startRangeTextPane.setBackground(Color.WHITE);
			startRangeTextPane.setEnabled(true);
			stopRangeTextPane.setBackground(Color.WHITE);
			stopRangeTextPane.setEnabled(true);
			setRangeButton.setEnabled(true);
			
			currentBinSizingMethod = "Simple Bin";
			System.out.println("Cluster method is now " + currentBinSizingMethod);
		}
		if (e.getSource() ==RandomBin)
		{
			bmMethodArray = 1; //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(true);
			randomNumberofTimesTextPane.setBackground(Color.WHITE);
			randomNumberofTimesTextPane.setEnabled(true);
			
			simpleBinSizeButton.setEnabled(false);
			simpleBinSizeTextPane.setBackground(Color.LIGHT_GRAY);
			simpleBinSizeTextPane.setEnabled(false);
			
			startRangeTextPane.setBackground(Color.WHITE);
			startRangeTextPane.setEnabled(true);
			stopRangeTextPane.setBackground(Color.WHITE);
			stopRangeTextPane.setEnabled(true);
			setRangeButton.setEnabled(true);
			
			currentBinSizingMethod = "Random Bin";
			System.out.println("Cluster method is now " + currentBinSizingMethod);
		}
				
		if (e.getSource() ==simpleBinSizeButton)
		{
			if (ParameterSetDialog.isNumber(simpleBinSizeTextPane.getText()))
			{
				simpleBinSize = Float.valueOf(simpleBinSizeTextPane.getText());
			}
			simpleBinSizeTextPane.setText(String.valueOf(simpleBinSize)); 	
		}
		
		if (e.getSource() ==randomBinIterButton)
		{
			if (ParameterSetDialog.isNumber(randomNumberofTimesTextPane.getText()))
			{
				randomNumofIterations = Integer.valueOf(randomNumberofTimesTextPane.getText());
			}
			randomNumberofTimesTextPane.setText(String.valueOf(randomNumofIterations)); 
			
		}
		
		if (e.getSource() == setRangeButton)
		{
			int startTemp = startRange;
			int stopTemp = stopRange;
			if (ParameterSetDialog.isNumber(startRangeTextPane.getText()))
			{
				startRange = Integer.valueOf(startRangeTextPane.getText());
				
			}
			if (ParameterSetDialog.isNumber(stopRangeTextPane.getText()))
			{
				
				stopRange = Integer.valueOf(stopRangeTextPane.getText());
				
			}
			if (startRange < stopRange)
			{
				startRangeTextPane.setText(String.valueOf(startRange));
				stopRangeTextPane.setText(String.valueOf(stopRange));
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Your ending range value is smaller than the starting value",
	                       "Sorry, this ain't gonna work, Hombre.", JOptionPane.WARNING_MESSAGE);
				startRangeTextPane.setText(String.valueOf(startTemp));
				stopRangeTextPane.setText(String.valueOf(stopTemp));
			}	
		}
		
		updateInfoBox();
		updateInfoClusterBox();
		infoLaunchBox.revalidate();
		infoLaunchBox.repaint();
	}
	
	private void launchVirtualSpectraMaker() throws Exception 
	{
		System.out.println("Starting Virtual Spectra Maker");
		try 
		{
			BufferedReader br = new BufferedReader(new FileReader(setupFile));					
			String nextLine =  br.readLine();
			nextLine =  br.readLine(); // just a comment line
			
			// getting the size standard
			StringTokenizer standardGetter = new StringTokenizer(nextLine,":");
			standardGetter.nextToken(); //throw away Title 
			int standardChannel = Integer.valueOf(standardGetter.nextToken());
			
			nextLine =  br.readLine(); // just a comment line
			// getting the data channels
			nextLine =  br.readLine();
			
			StringTokenizer channelGetter = new StringTokenizer(nextLine,":,");
			ArrayList<Integer> channelList = new ArrayList<Integer>();
			channelGetter.nextToken(); // throw away the description of what this line is to be....
			
			int count = channelGetter.countTokens();
			for (int i = 0; i < count; i++)
			{
				int dataChannel = Integer.valueOf(channelGetter.nextToken());
				channelList.add(dataChannel);
			}
						
			nextLine =  br.readLine(); // just a comment line for the setup File
			nextLine =  br.readLine(); // just a comment line, there are 3 of them here.
			nextLine =  br.readLine(); // just a comment line
			
			//get the file names where each Row is a set of .FSA files for a an experiment
			//       Each line will be a new File Descriptor ?
			//
			
			nextLine =  br.readLine();
			
			while (nextLine != null )
			{
				ArrayList<AbstractFSAFileDescriptor> fsaList = new ArrayList<AbstractFSAFileDescriptor>();
				
				StringTokenizer st = new StringTokenizer(nextLine,",");
				int fileCount = st.countTokens();
				for (int i = 0; i < fileCount; i++)
				{
					String filename = st.nextToken();
					File file = new File(setupFile.getParentFile() + File.separator + filename.trim());
					System.out.println("working on this file: " + file.getAbsolutePath() + "\t" + filename);
					
					//FsaFileDescriptor fsa = new FsaFileDescriptor(this.frame.getStandardWeights(), file, this.frame.getExperimentSet(), 
					//	    channelList, standardChannel);
					AbstractFSAFileDescriptor fsa = this.frame.addData(file, channelList, standardChannel);
					fsa.callAllPeaks();
					fsaList.add(fsa);
					//System.out.println(fsa.getFileNamePrefix() + " is our FSA file we created, " + fsa.getStandardChannel());
				}
				
				List<Spectra> innerList = fillUpTheSpectraList(fsaList, channelList);
				VirtualSpectra vs = new VirtualSpectra(innerList, fsaList.get(0).getFileNamePrefix());
				spectraList.add(vs);
				nextLine = br.readLine();
			}
			
			addVirtualSpectraToFrame();  
			br.close();
			System.out.println("We just completed Virtual Spectra Maker");
		} catch (Exception e) 
		{
			JTextPane error = new JTextPane();
			error.setText(e.getMessage());
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,error, ("Error trying to make Virtual Spectra"), CH_DEFAULT);
		}		
	}
	
	

	public void launchClusterAnalysis() throws Exception 
	{
		try 
		{
			launchVirtualSpectraMaker();
			int a= bmMethodArray;
		      switch (a)
		      {      
		        case 0:
		        	//simple bin, yes this is a hack so to avoid changing exception errors
		        	System.out.println(" We are starting binning method loading....");
		        			        	
		        	bmList.add(new TRFLPSimpleBin(simpleBinSize,startRange, stopRange, spectraList, threshold, isBinary, true));
		        	break;
		        case 1:
		        	for (int i = 0; i < randomNumofIterations; i++)
		        	{
		        		//bmList.add(new PCRandomBin(nonStndList, isBinary, true, String.valueOf(i)));
		        	}
		          break;
		        default:
		          System.out.println("Invalid Entry!");
				
		      }
			
		    if (currentClusterMethod.contains("War") || linkageMethod.getName().contains("War")) linkageMethod = new WardsMethod();
		    else if (currentClusterMethod.contains("Furthest Neighbour")) linkageMethod = new FurthestNeighbour();
		    else if (currentClusterMethod.contains("Nearest Neighbour")) linkageMethod = new NearestNeighbour();
		    else if (currentClusterMethod.contains("Average Distance")) linkageMethod = new AverageDistance();
		    else throw new Exception(" Failed to create a linkage method. Please contact the Authors, because this is broken.");
		        
			for (AbstractPeakCallBinningMethod bm: bmList)
			{
				
				
				ArrayList<ArrayList<Double>> list = bm.getBinListofLists();
									
				ArrayList<DataPoint> branchesForCluster = new ArrayList<DataPoint>();
					
				for (int i = 0; i < spectraList.size(); i++)
				{
					String label = spectraList.get(i).getName(); // just choosing 1st name in the row from the setup textfile.
					ArrayList<Double> values = list.get(i);
					branchesForCluster.add( new LabeledDataPoint( i,values, label )); //This is what we feed into cluster code
				}
									
				Cluster topCluster = HierarchicalClusterer.cluster(
								branchesForCluster, linkageMethod);
					
				NewicktreeBuilder s = new NewicktreeBuilder();
				String treeinNewickFormat = s.getTree(topCluster);
				
				//write binned data to file to check for mistakes
				trflp.TrflpVirtualSpectra.writeBinsToFile(list, outPutDir, linkageMethod.getName(), bm, spectraList);
				
				//write newick file
				File file = AbstractPeakCallBinningMethod.writeNewickFormatToFile(treeinNewickFormat, outPutDir , bm);
				final String[] args = new String[1];
				args[0] = file.getAbsolutePath();
				org.forester.archaeopteryx.Archaeopteryx.main(args);
								
			}
		} catch (Exception e) 
		{
			JTextPane error = new JTextPane();
			error.setText(e.getMessage());
			e.printStackTrace();
		}		
	}
	
	public List<Spectra> fillUpTheSpectraList(ArrayList<AbstractFSAFileDescriptor> fsaList, ArrayList<Integer> channels) throws Exception
	{
		List<Spectra> innerList = new ArrayList<Spectra>();
			
		for (int i = 0; i < fsaList.size(); i++)
		{
			for (int j = 0; j < channels.size(); j++)
			{
				innerList.add( fsaList.get(i).getDataSpectra().get(j) );
				System.out.println("Inner fetchSpectraLoop: fsa:" + fsaList.get(i).getDataSpectra().get(j).getName() + " \t for channel " + j );
			}	
		}
		return innerList;
	}
	
	public void loadOutPutDirFile()
	 {
		 JFileChooser jfc = new JFileChooser();
		 jfc.setMultiSelectionEnabled(false);
		 jfc.setCurrentDirectory(outPutDir);
		 jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		 if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		 {
			 outPutDir = jfc.getSelectedFile();
		 }
	 }
	
	public void loadSetUpFile()
	 {
		 JFileChooser jfc = new JFileChooser();
		 jfc.setMultiSelectionEnabled(false);
		 jfc.setCurrentDirectory(outPutDir);
		 jfc.setFileSelectionMode(JFileChooser.FILES_ONLY);
		 if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		 {
			 setupFile = jfc.getSelectedFile();
		 }
	 }
	
	private int calcSmallestBiggestSizeStandard() 
	{
		int smallestMaxValue = 1200;
		List<StandardWeights> lsw = frame.getStndWeightsList();
		if (lsw.size() == 0) return 1200;
		
		for (StandardWeights sw : lsw)
		{
			int biggestSizerightNow = 0;
			for (int i = 0; i < sw.getWeights().size();i++)
			{
				if (sw.getWeights().get(i) > biggestSizerightNow) biggestSizerightNow = sw.getWeights().get(i);
			}
			if (smallestMaxValue > biggestSizerightNow) smallestMaxValue = biggestSizerightNow;
		}
		return smallestMaxValue;
	}
	

	@Override*
	public void itemStateChanged(ItemEvent e) 
	{
		
		
	}
	
	protected JComponent makeTextPanel(String text) 
	{
        JPanel panel = new JPanel(false);
        JLabel filler = new JLabel(text);
        filler.setHorizontalAlignment(JLabel.CENTER);
        panel.setLayout(new GridLayout(1, 1));
        panel.add(filler);
        return panel;
    }
	
	void setUpSizeStandards()
	{
		if(this.frame.getStndWeightsList().isEmpty())
		 {
			 String lastStnd = frame.getPrefs().get("lastStnd", null);
			 if(lastStnd == null)
			 {
				 JOptionPane.showMessageDialog(null, "Load Standards File!","Standards Warning!",JOptionPane.INFORMATION_MESSAGE);
			 }
			 else
			 {
				 File defStndFile = new File(lastStnd);
				 if(defStndFile.exists())
					 frame.readInStndFile(defStndFile);
				 else
				 {
					 JOptionPane.showMessageDialog(null, defStndFile.getName()+" Has been moved or deleted"+'\n'
		 						+"File Path"+defStndFile.getAbsolutePath(),"Standards Warning!",JOptionPane.INFORMATION_MESSAGE);
				 }
			 }
				
		 }
	}
	
	private void addVirtualSpectraToFrame() 
	{
		
		System.out.println("We are now adding VS spectra to the frame and the list size added is " + spectraList.size() );
		
		
		for (VirtualSpectra vs: spectraList)
		{
			frame.getSpectraList().add(vs.getVirtualSpectra());
			frame.getSpectraList().add(vs.getOriginalSmallerSpectra().get(0));
			try 
			{
				vs.writePeaksInBasepairSpaceToFile(frame.getDirectory().getAbsolutePath()+ "\\bp.txt");
				vs.writePeaksInIndexSpace(frame.getDirectory().getAbsolutePath() + "\\index.txt");
				vs.getOriginalSmallerSpectra().get(0).writePeaksInBasepairSpaceToFile(frame.getDirectory().getAbsolutePath() + "\\smallSpectraBP.txt");
				vs.getOriginalSmallerSpectra().get(0).writePeaksInIndexSpace(frame.getDirectory().getAbsolutePath() + "\\smallSpectraIndex.txt");
				
			} catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
				
		frame.getPanel().setForceReDraw(true);
		frame.repaint();
	}
}

class SetupEntry 
{
	String enzymeName;
	int channel;
	String id;
	int channelStd1;
	
	
	public SetupEntry(String name, int chan1, int channelStd1) {
		super();
		this.enzymeName = name;
		this.channel = chan1;
		this.channelStd1 = channelStd1;
		id = enzymeName + channel;
	}
	
	*/
}
