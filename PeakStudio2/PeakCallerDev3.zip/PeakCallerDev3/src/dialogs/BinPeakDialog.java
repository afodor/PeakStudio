package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import binning.BinPeaks;
import viewer.FsaFrame;

public class BinPeakDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private FsaFrame frame;
	private JButton cancelButton = new JButton("Cancel");
	private JButton runButton = new JButton("Ok");
	private JPanel bottomPanel,topPanel,mainPanel;
	private JTextField strBp,endBp,binNum,peakH;
	private JLabel startValue,endValue,binNumber,peakHeight;
	private final String  SPACER = "      ";
	private float _BP_START;
	private float _BP_END;
	private float _BIN_SIZE;
	private float _PEAK_HEIGHT;
	private BinPeaks binPeaks;
	private File file;
	
	public BinPeakDialog(FsaFrame frame,File f)
	{
		super(frame,"Binned Peaks Matrix");
		this.frame = frame;
		this.file = f;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(295,200);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		buildDialog();
	}
	private void setDefaultValues()
	{
		_BP_START = this.frame.getPrefs().getFloat("BP_Start", 25f);
		_BP_END = this.frame.getPrefs().getFloat("BP_End", 900f);
		_BIN_SIZE = this.frame.getPrefs().getFloat("Bin_Size", 3f);
		_PEAK_HEIGHT = this.frame.getPrefs().getFloat("Peak_Height", 25f);
	}
	private void buildDialog() 
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		buildTopPanel();
		buildMidPanel();
		buildBottomPanel();
		this.add(mainPanel);
	}
	
	private void buildMidPanel()
	{
		JPanel mid = new JPanel();
		mainPanel.add(mid,BorderLayout.CENTER);
	}
	private void buildTopPanel()
	{
		topPanel = new JPanel();
		topPanel.setLayout(new GridLayout(0,2));
		buildTextFields();
		topPanel.add(startValue);
		topPanel.add(strBp);
		topPanel.add(endValue);
		topPanel.add(endBp);
		topPanel.add(binNumber);
		topPanel.add(binNum);
		topPanel.add(peakHeight);
		topPanel.add(peakH);
		mainPanel.add(topPanel,BorderLayout.NORTH);
	}
	private void buildTextFields()
	{
		startValue = new JLabel(SPACER+"Start BasePair");
		strBp = new JTextField(7);
		strBp.setEditable(true);
		endValue = new JLabel(SPACER+"  End BasePair");
		endBp = new JTextField(7);
		endBp.setEditable(true);
		binNumber = new JLabel(SPACER+SPACER+"Bin Size");
		binNum = new JTextField(7);
		binNum.setEditable(true);
		peakHeight = new JLabel(" Peak Height Threshold");
		peakH = new JTextField(7);
		peakH.setEditable(true);
		
	}
	private void buildBottomPanel()
	{
		bottomPanel = new JPanel(new BorderLayout());
		bottomPanel.setBorder(BorderFactory.createBevelBorder(3));
		bottomPanel.setLayout(new FlowLayout());
		buildButtons();
		//bottomPanel.add(cancelButton);
		bottomPanel.add(runButton);
		mainPanel.add(bottomPanel,BorderLayout.SOUTH);
	}
	private void buildButtons()
	{
		cancelButton.addActionListener(this);
		cancelButton.setSize(10,10);
		runButton.addActionListener(this);
		//runButton.addPropertyChangeListener(this);
		runButton.setSize(10, 10);
		runButton.setEnabled(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == runButton)
		{
			runButton.setEnabled(false);
			binPeak();
			exitDialog();
		}
		if(e.getSource() == cancelButton)
		{
			exitDialog();
		}
		
	}
	public void setUpDialog()
	{
		setDefaultValues();
		strBp.setText(Float.toString(_BP_START));
		endBp.setText(Float.toString(_BP_END));
		binNum.setText(Float.toString(_BIN_SIZE));
		peakH.setText(Float.toString(_PEAK_HEIGHT));
	}
	private void binPeak()
	{
		try
		{
			binPeaks = new BinPeaks(Float.parseFloat(strBp.getText()),Float.parseFloat(endBp.getText()),
									Float.parseFloat(binNum.getText()),Float.parseFloat(peakH.getText()),this.frame);
			binPeaks.collectPeaks();
			double[][] d = binPeaks.getDoubleArray();	
			//BinPeaks.outPutMatrix(file, d, this.frame.getNonStndSpectraList(),binPeaks.getBins());
			binPeaks.outPutMatrix(file);
			this.frame.getPrefs().putFloat("BP_Start", Float.parseFloat(strBp.getText()));
			this.frame.getPrefs().putFloat("BP_End", Float.parseFloat(endBp.getText()));
			this.frame.getPrefs().putFloat("Bin_Size", Float.parseFloat(binNum.getText()));
			this.frame.getPrefs().putFloat("Peak_Height", Float.parseFloat(peakH.getText()));
		}
		catch(Exception e)
		{
			JOptionPane.showMessageDialog(frame, "Failed to Create Matrix " + e.getMessage(), "ERROR",
					JOptionPane.ERROR_MESSAGE);
			e.printStackTrace();
			
		}
		
		
	}
	private void exitDialog()
	{
		this.setVisible(false);
		this.dispose();
		System.gc();
	}	

}
