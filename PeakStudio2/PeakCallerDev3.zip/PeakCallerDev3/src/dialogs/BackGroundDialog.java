package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import viewer.FsaFrame;
import viewer.FsaPanel;

public class BackGroundDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = -6120389683234812126L;
	
	private FsaFrame frame;
	private FsaPanel panel;
	private JButton applyButton = new JButton("Ok");
	private JButton closeButton = new JButton("Close");
	private JTextField xTics,yTics;

	
	public BackGroundDialog(FsaFrame frame)
	{
		super(frame,"Axis Preferences");
		this.frame = frame;
		this.panel = frame.getFsaPanel();
		this.setSize(300,250);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		init();
	}
	
	private void init()
	{
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		mainPanel.add(getTextPanel(),BorderLayout.NORTH);
		mainPanel.add(getButtonPanel(),BorderLayout.CENTER);
		this.add(mainPanel);
	}
	
	private JPanel getTextPanel()
	{
		JPanel main = new JPanel();
		main.setLayout(new BorderLayout());
		JPanel west = new JPanel();
		west.setLayout(new FlowLayout());
		JLabel x_tic = new JLabel("X Tick Marks");
		xTics = new JTextField(10);
		xTics.setEditable(true);
		xTics.setBackground(Color.WHITE);
		west.add(x_tic);
		west.add(xTics);
		JPanel east = new JPanel();
		east.setLayout(new FlowLayout());
		JLabel y_tic = new JLabel("Y Tick Marks");
		yTics = new JTextField(10);
		yTics.setEditable(true);
		yTics.setBackground(Color.WHITE);
		east.add(y_tic);
		east.add(yTics);
		main.add(west,BorderLayout.NORTH);
		main.add(east,BorderLayout.SOUTH);
		return main;
	}
	
	private JPanel getButtonPanel()
	{
		JPanel main = new JPanel();
		main.setLayout(new BorderLayout());
		closeButton.addActionListener(this);
		closeButton.setSize(10,10);
		applyButton.addActionListener(this);
		applyButton.setSize(10, 10);
		JPanel button = new JPanel();
		button.add(applyButton);
		button.add(closeButton);
		main.add(button,BorderLayout.CENTER);
		return main;
	}

	
	public void setDisplay()
	{
		xTics.setText(Integer.toString(panel.getXticNumber()));
		yTics.setText(Integer.toString(panel.getYticNumber()));
		
	}
	
	private void applyChanges()
	{	
		panel.setXticNumber(Integer.parseInt(xTics.getText()));
		panel.setYticNumber(Integer.parseInt(yTics.getText()));
		frame.getFsaPanel().forceRedraw();
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == applyButton)
		{
			if(ParameterSetDialog.isNumber(xTics.getText()) && ParameterSetDialog.isNumber(yTics.getText()))
				applyChanges();
			else
				JOptionPane.showMessageDialog(null, "Enter Integers Only","Not a valid number",JOptionPane.INFORMATION_MESSAGE);
		}
		if(e.getSource() == closeButton)
		{
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		
	}
	
	

}
