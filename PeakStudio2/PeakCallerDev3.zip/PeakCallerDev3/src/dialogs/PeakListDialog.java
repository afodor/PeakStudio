package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.List;
import java.util.prefs.Preferences;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import dataProvider.DataProvider;

import experimentSets.Feature;
import experimentSets.Spectra;

import viewer.FsaFrame;

public class PeakListDialog extends JDialog implements ActionListener
{

	private FsaFrame parent;
	private JRadioButton dNs = new JRadioButton("Data and Standards");
	private JRadioButton d_Only = new JRadioButton("Data Only");
	private JRadioButton s_Only = new JRadioButton("Standards Only");
	private JButton runButton = new JButton("Ok");
	private JPanel mainPanel;
	private String action;
	private NumberFormat formatter = new DecimalFormat("0.0000");
	
	public PeakListDialog(FsaFrame frame)
	{
		this.setTitle("Export Peaks");
		this.parent = frame;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(200,150);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		
		buildDialog();
		this.setVisible(true);
	}
	
	private void buildDialog()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		mainPanel.add(buildTopPanel(),BorderLayout.NORTH);
		mainPanel.add(buildBottomPanel());
		this.add(mainPanel);
		
	}
	private JPanel buildTopPanel()
	{
		JPanel jp = new JPanel();
		jp.setLayout(new GridLayout(3,0));
		ButtonGroup bg = new ButtonGroup();
		bg.add(dNs);
		bg.add(d_Only);
		bg.add(s_Only);
		dNs.setSelected(true);
		this.action = dNs.getText();
		jp.add(dNs);
		jp.add(d_Only);
		jp.add(s_Only);
		dNs.addActionListener(this);
		d_Only.addActionListener(this);
		s_Only.addActionListener(this);
		return jp;
	}
	private JPanel buildBottomPanel()
	{
		JPanel jp = new JPanel();
		runButton.setSize(10, 10);
		runButton.setEnabled(true);
		runButton.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(action.equals("Data and Standards"))
				{
					outPutPeakList(parent.getSpectraList());
					exitDialog();
				}	
				else if (action.equals("Data Only"))
				{
					outPutPeakList(parent.getNonStndSpectraList());
					exitDialog();
				}	
				else if(action.equals("Standards Only"))
				{
					outPutPeakList(parent.getStndSpectraList());
					exitDialog();
				}		
			}
			
		});
		jp.add(runButton);
		return jp;
	}
	private void exitDialog()
	{
		this.setVisible(false);
		this.dispose();
		System.gc();
	}	

	@Override
	public void actionPerformed(ActionEvent e) 
	{
		JRadioButton jr = (JRadioButton) e.getSource();
		this.action = jr.getText();
	}
	private void outPutPeakList(List<Spectra> outList)
	{
		JFileChooser chooser = new JFileChooser();
		chooser.setDialogTitle(".txt");
		chooser.setSelectedFile(new File("Peak_List"+this.parent.getPeakListCounterThenIncrement() +".txt"));
		Preferences prefs = this.parent.getPrefs();
		chooser.setCurrentDirectory(new File(prefs.get(this.parent.getPrefName(), "")));
		if(chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION)
		{
			File f = chooser.getSelectedFile();
			if(!f.getAbsolutePath().endsWith(".txt"))
			{
				if(f.getAbsolutePath().lastIndexOf('.') > -1)
				{
					String newPath = f.getAbsolutePath().substring(0, f.getAbsolutePath().lastIndexOf('.'));
					File f2 = new File(newPath+".txt");
					f = f2;
				}
				else
				{
					f = new File(f.getAbsoluteFile()+".txt");
				}
			}
			try
			{
				writeOutPeakList(f,outList);
			}
			catch(Exception e)
			{
				JOptionPane.showMessageDialog(this, e.getMessage() + "\n"
						+ "Saving File Failed\n"
						+ "Check to make sure approiate files are open\n"
						+ "Restaring PeakStudio is recommended\n");
			}
			
		}
		
	}
	private void writeOutPeakList(File f,List<Spectra> spectra) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(f));
		writer.write("Sample"+"\t"+"Channel_Number"+"\t"+"Type"+"\t"+"Peak_Number"+"\t"
				+"Location(Index)"+"\t"+"Location(Base_Pair)"+"\t"+"Height"+"\t"+"Area(Index)"+"\t"+"Area(Base_Pair)"+"\n");
		for(Spectra s: spectra)
		{
			DataProvider<Float> bpCalls = s.getBasePairCalls();
			List<Feature> peaks = s.getLastGeneratedPeakSet();
			int peakNum = 1;
			for(Feature p: peaks)
			{
				String type = (s.getIsStandard() ? "Standard" : "Data");
				writer.write(s.getName()+"\t"+s.getDataChannel()+"\t"+type+"\t");
				writer.write(peakNum+"\t"+p.getIndexOfHighestPeak()+"\t");
				if(bpCalls == null)
					writer.write("NA");
				else
					writer.write(Float.toString(bpCalls.get(p.getIndexOfHighestPeak())));
				writer.write("\t"+p.getHeight()+"\t");
				writer.write(formatter.format(p.getAUC(true))+"\t");
				if(bpCalls == null)
					writer.write("NA");
				else
					writer.write(formatter.format(p.getAUC(false))+"\n");
				peakNum++;
			}
			
		}
		writer.flush(); writer.close();
	}
}
