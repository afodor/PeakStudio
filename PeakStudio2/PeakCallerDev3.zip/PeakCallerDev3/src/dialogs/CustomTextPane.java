package dialogs;

import javax.swing.JTextPane;
import javax.swing.text.StyledDocument;

public class CustomTextPane extends JTextPane
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public CustomTextPane()
	{
		super();
	}
	
	public CustomTextPane(StyledDocument doc)
	{
		super(doc);
	}
	
	public boolean getScrollableTracksViewportWidth()
	{
		return false;
	}
}
