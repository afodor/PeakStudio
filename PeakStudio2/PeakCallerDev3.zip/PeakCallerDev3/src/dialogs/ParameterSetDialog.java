package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import experimentSets.Spectra;
import viewer.FsaFrame;


public class ParameterSetDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private FsaFrame parentFrame;
	private JButton applyButton = new JButton("Apply to this spectra");
	private JButton closeButton = new JButton("Close");
	private JButton applyGlobal = new JButton("Apply To All Selected");
	private JPanel bottomPanel, midPanel,topPanel,mainPanel;
	private JTextField maxInterSlopeDist,numTrimBeg,numTrimEnd,regWinSize,negSlope,posSlope,pThreshHieght,pThresh,sd,smoothWindow;
	private JLabel maxInterMdist,numToTrimFromBeginning,numToTrimFromEnd,regressionWindowSize,requiredNegativeSlope,requiredPositiveSlope;
	private JRadioButton dataRB,stndRB,allRB;
	private ButtonGroup butGroup;
	private List<Spectra> localSpectra =new ArrayList<Spectra>();
	private List<Spectra> actionSpectra = new ArrayList<Spectra>();
	private DefaultComboBoxModel dropBoxModel = new DefaultComboBoxModel();
	private JComboBox dropBox;
	private JLabel dropMenuLabel = new JLabel("Spectra");
	private List<String> userInfo = new ArrayList<String>();
	private boolean applyAbrubtJump = true;
	private JCheckBox abrubtJumpBox = new JCheckBox("Apply Abrubt Jump When Calling Peaks");
	
	public ParameterSetDialog(FsaFrame frame)
	{
		super(frame,"Spectra Parameter Set");
	
		this.parentFrame= frame;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(525,500);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		buildDialog();
		
		int[] selectedRows = frame.getSpectraJTable().getSelectedRows();
		for( Integer i : selectedRows)
		{
			int index = frame.getSpectraJTable().getModel().getSpectraRowNumber(i);
			Spectra s = frame.getSpectraList().get(index);
			actionSpectra.add(s);
			localSpectra.add(s);
		}
	}
	
	private void buildDialog() 
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		buildTopPanel();
		buildMidPanel();
		buildBottomPanel();
		this.add(mainPanel);
	}
	
	private void buildTopPanel()
	{
		topPanel = new JPanel();
		JPanel rBpanel = new JPanel();
		rBpanel.setLayout(new FlowLayout());
		allRB = new JRadioButton("All");
		dataRB = new JRadioButton("Data");
		stndRB = new JRadioButton("Standards");
		dataRB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) 
			{
				dataRBselected();
			}
		});

		stndRB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) 
			{
				stndRBselected();
			}
		});
		allRB.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) 
			{
				allRBselected();
			}
		});
		butGroup = new ButtonGroup();
		butGroup.add(allRB);
		butGroup.add(dataRB);
		butGroup.add(stndRB);
		rBpanel.add(allRB);
		rBpanel.add(dataRB);
		rBpanel.add(stndRB);
		topPanel.setLayout(new BorderLayout());
		topPanel.setSize(500, 120);
		dropBox = new JComboBox(dropBoxModel);
		dropBox.setBackground(Color.WHITE);
		dropBox.addActionListener(this);
		topPanel.add(dropMenuLabel);
		topPanel.add(rBpanel);
		topPanel.add(dropBox,BorderLayout.SOUTH);
		mainPanel.add(topPanel,BorderLayout.NORTH);
	}
	public void setAllRBselected(boolean x)
	{
		allRB.setSelected(x);
	}
	private void allRBselected()
	{
		this.actionSpectra = new ArrayList<Spectra>();
		
		for(Spectra s : localSpectra)
				actionSpectra.add(s);
		
		applyGlobal.setText("Apply To All Selected");
		setUpDropMenu(this.actionSpectra);
	}
	private void stndRBselected()
	{
		this.actionSpectra = new ArrayList<Spectra>();
		
		for(Spectra s : localSpectra)
			if( s.getIsStandard())
				actionSpectra.add(s);
		
		applyGlobal.setText("Apply To All Selected Standards");
		setUpDropMenu(this.actionSpectra);
	}
	private void dataRBselected()
	{
		this.actionSpectra = new ArrayList<Spectra>();
		
		for(Spectra s : localSpectra)
			if(! s.getIsStandard())
				actionSpectra.add(s);
		
		applyGlobal.setText("Apply To All Selected Data");
		setUpDropMenu(this.actionSpectra);
	}
	private void buildBottomPanel()
	{
		//bottomPanel = new JPanel(new BorderLayout());
		bottomPanel = new JPanel();
		bottomPanel.setBorder(BorderFactory.createBevelBorder(3));
		bottomPanel.setLayout(new FlowLayout());
		buildButtons();
		bottomPanel.add(applyButton);
		bottomPanel.add(applyGlobal);
		bottomPanel.add(closeButton);
		mainPanel.add(bottomPanel,BorderLayout.SOUTH);
	}
	
	private void buildButtons()
	{
		closeButton.setSize(10,10);
		closeButton.addActionListener(new ActionListener(){

			public void actionPerformed(ActionEvent e)
			{
				closeDialog();	
			}
		});
		applyButton.setSize(10, 10);
		applyButton.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				applyChanges();
			}
		});
		applyGlobal.setSize(15, 10);
		applyGlobal.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e)
			{
				applyGlobally();
			}
		});
	}
	private void closeDialog()
	{
		this.setVisible(false);
		this.dispose();
		System.gc();
	}
	private void buildTextFields()
	{
		maxInterMdist = new JLabel("Max InterSlope Distance");
		maxInterSlopeDist = new JTextField(10);
		maxInterSlopeDist.setEditable(true);
		numToTrimFromBeginning = new JLabel("Num to Trim from Beginning");
		numTrimBeg = new JTextField(10);
		numTrimBeg.setEditable(true);
		numToTrimFromEnd = new JLabel("Num to Trim from End");
		numTrimEnd = new JTextField(10);
		numTrimEnd.setEditable(true);
		regressionWindowSize = new JLabel("Regression Window Size");
		regWinSize = new JTextField(10);
		regWinSize.setEditable(true);
		requiredNegativeSlope = new JLabel("Required Negative Slope");
		negSlope = new JTextField(10);
		negSlope.setEditable(true);
		requiredPositiveSlope = new JLabel("Required Positive Slope");
		posSlope = new JTextField(10);
		posSlope.setEditable(true);
		pThresh = new JTextField(10);
		pThresh.setEditable(true);
		pThreshHieght = new JTextField(10);
		pThreshHieght.setEditable(true);
		sd = new JTextField(10);
		sd.setEditable(true);
		smoothWindow = new JTextField(10);
		smoothWindow.setEditable(true);
		
	}
	
	private void buildMidPanel() 
	{
		buildTextFields();
		midPanel = new JPanel();
		midPanel.setBorder(BorderFactory.createEtchedBorder());
		midPanel.setLayout(new GridLayout(7,2));
		midPanel.add(maxInterMdist);
		midPanel.add(maxInterSlopeDist);
		midPanel.add(numToTrimFromBeginning);
		midPanel.add(numTrimBeg);
		midPanel.add(numToTrimFromEnd);
		midPanel.add(numTrimEnd);
		midPanel.add(regressionWindowSize);
		midPanel.add(regWinSize);
		midPanel.add(requiredNegativeSlope);
		midPanel.add(negSlope);
		midPanel.add(requiredPositiveSlope);
		midPanel.add(posSlope);
		JPanel thresholdValuesPanel = new JPanel();
		thresholdValuesPanel.setBorder(BorderFactory.createEtchedBorder());
		thresholdValuesPanel.setLayout(new GridLayout(3,2));
		JLabel thresh_1 = new JLabel("Threshold");
		JLabel thresh_2 = new JLabel("Height Threshold");
		JLabel thresh_3 = new JLabel("Standard Deviation");
		//JLabel smWin = new JLabel("Smooth Data Window");
		thresholdValuesPanel.add(thresh_1);
		thresholdValuesPanel.add(pThresh);
		thresholdValuesPanel.add(thresh_2);
		thresholdValuesPanel.add(pThreshHieght);
		thresholdValuesPanel.add(thresh_3);
		thresholdValuesPanel.add(sd);
		//thresholdValuesPanel.add(smWin);
		//thresholdValuesPanel.add(smoothWindow);
		JPanel middleContainer = new JPanel();
		JPanel thresholdContainerPanel = new JPanel();
		thresholdContainerPanel.setLayout(new FlowLayout());
		thresholdContainerPanel.add(new JPanel());
		thresholdContainerPanel.add(thresholdValuesPanel);
		thresholdContainerPanel.setBorder(BorderFactory.createTitledBorder("Peak Thresholds"));
		middleContainer.setLayout(new BorderLayout());
		middleContainer.add(midPanel,BorderLayout.NORTH);
		middleContainer.add(thresholdContainerPanel,BorderLayout.CENTER);
		
		
		abrubtJumpBox.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				AbstractButton abstractButton = (AbstractButton) e.getSource();
		        applyAbrubtJump = abstractButton.getModel().isSelected();
			}
		});
		middleContainer.add(abrubtJumpBox,BorderLayout.SOUTH);
		mainPanel.add(middleContainer,BorderLayout.CENTER);
		
	}
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == dropBox)
		{
			try
			{
				if(dropBox.getSelectedIndex() > -1 && !this.actionSpectra.isEmpty())
				{
					displayParameterSet(dropBox.getSelectedIndex());
				}
			}
			catch(Exception x){x.printStackTrace();}
		}
	}
	
	private void applyGlobally()
	{
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
		if(!this.actionSpectra.isEmpty())
		{
			try
			{
				getUserInfo(dropBox.getSelectedIndex());
				for(int x=0; x<this.actionSpectra.size(); x++)
				{
					setNewParameterSet(x);
					parentFrame.setDirty(true);
				}
				displayParameterSet(dropBox.getSelectedIndex());
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
			}
			
			parentFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			parentFrame.getSpectraJTable().getModel().fireTableDataChanged();
			parentFrame.getFsaPanel().forceRedraw();
		}
		parentFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
	
	private void applyChanges()
	{
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
		if(!this.actionSpectra.isEmpty())
		{
			try
			{
				getUserInfo(dropBox.getSelectedIndex());
				setNewParameterSet(dropBox.getSelectedIndex());
				
			}
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(this, e.getMessage(),"Error",JOptionPane.ERROR_MESSAGE);
			}
		}
		
		parentFrame.getSpectraJTable().getModel().fireTableDataChanged();
		parentFrame.getFsaPanel().forceRedraw();
		parentFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
	}
	
	private void getUserInfo(int row)
	{
		userInfo.clear();
		if(isNumber(maxInterSlopeDist.getText()))
			userInfo.add(maxInterSlopeDist.getText());
		else
			userInfo.add("X");
		if(isNumber(numTrimBeg.getText()))
			userInfo.add(numTrimBeg.getText());
		else
			userInfo.add("X");
		if(isNumber(numTrimEnd.getText()))
			userInfo.add(numTrimEnd.getText());
		else
			userInfo.add("X");
		if(isNumber(regWinSize.getText()))
			userInfo.add(regWinSize.getText());
		else
			userInfo.add("X");
		
		if(isNumber(negSlope.getText()))
			userInfo.add(negSlope.getText());
		else
			userInfo.add("X");
		if(isNumber(posSlope.getText()))
			userInfo.add(posSlope.getText());
		else
			userInfo.add("X");
		if(isNumber(pThresh.getText()))
			userInfo.add(pThresh.getText());
		else
			userInfo.add("X");
		if(isNumber(pThreshHieght.getText()))
			userInfo.add(pThreshHieght.getText());
		else
			userInfo.add("X");
		if(isNumber(sd.getText()))
			userInfo.add(sd.getText());
		else
			userInfo.add("X");
		
	}
	private void setNewParameterSet(int row) throws Exception
	{
		Spectra s = this.actionSpectra.get(row);
		if(isNumber(userInfo.get(0)))
			s.getParameterSet().setMaxInterslopeDistance((int)Float.parseFloat(userInfo.get(0)));
		if(isNumber(userInfo.get(1)))
			s.getParameterSet().setNumToTrimFromBeginning((int)(Float.parseFloat(userInfo.get(1))));
		if(isNumber(userInfo.get(2)))
			s.getParameterSet().setNumToTrimFromEnd((int)Float.parseFloat(userInfo.get(2)));
		if(isNumber(userInfo.get(3)))
			s.getParameterSet().setRegressionWindowSize((int)Float.parseFloat(userInfo.get(3)));
		if(isNumber(userInfo.get(4)))
			s.getParameterSet().setRequiredNegativeSlope(Float.parseFloat(userInfo.get(4)));
		if(isNumber(userInfo.get(5)))
			s.getParameterSet().setRequiredPositiveSlope(Float.parseFloat(userInfo.get(5)));
		if(isNumber(userInfo.get(6)))
			s.getParameterSet().setPeakThreshold(Float.parseFloat(userInfo.get(6)));
		if(s.getIsStandard() && isNumber(userInfo.get(7)))
			s.getParameterSet().setPeakHeightThreshold(Float.parseFloat(userInfo.get(7)));
		if(s.getIsStandard() && isNumber(userInfo.get(8)))
			s.getParameterSet().setStandardDev(Float.parseFloat(userInfo.get(8)));
		
		s.getParameterSet().setCheckAbrutJump(applyAbrubtJump);
		displayParameterSet(row);
		
		s.callFeatures();
		
		if( s.getFileDescriptor().getSizeStandards() != null 
				&& s.getFileDescriptor().getSizeStandards().size()>3 )
			s.getFileDescriptor().generateBasePairCalls(false);
		
		this.parentFrame.getFsaPanel().forceRedraw();
		
	}
	
	public static boolean isNumber(String s)
	{
		try
		{
			Double.parseDouble(s);
		}
		catch(Exception x)
		{
			return false;
		}
		return true;
		
	}
	
	public void setSpectra()
	{
		setUpDropMenu(actionSpectra);
	}
	
	private void setUpDropMenu(List<Spectra> specList)
	{
		try
		{
			if(!specList.isEmpty())
			{
				dropBoxModel.removeAllElements();
				abrubtJumpBox.setEnabled(true);
				for(Spectra s: specList)
				{
					dropBoxModel.addElement(s.getName()+"   "+s.getDataChannel());
				}
				dropBox.setSelectedIndex(0);
				displayParameterSet(dropBox.getSelectedIndex());
			}
			else
			{
				dropBoxModel.removeAllElements();
				dropBoxModel.addElement("Spectra Not Selected");
				blankDisplay();
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	private void displayParameterSet(int row) throws Exception
	{
		Spectra s = this.actionSpectra.get(row);
		maxInterSlopeDist.setText(Integer.toString(s.getParameterSet().getMaxInterslopeDistance()));
		numTrimBeg.setText(Integer.toString(s.getParameterSet().getNumToTrimFromBeginning()));
		numTrimEnd.setText(Integer.toString(s.getParameterSet().getNumToTrimFromEnd()));
		regWinSize.setText(Integer.toString(s.getParameterSet().getRegressionWindowSize()));
		negSlope.setText(Float.toString(s.getParameterSet().getRequiredNegativeSlope()));
		posSlope.setText(Float.toString(s.getParameterSet().getRequiredPositiveSlope()));
		pThresh.setText(Float.toString(s.getParameterSet().getPeakThreshold()));
		
		abrubtJumpBox.setSelected(s.getParameterSet().checkAbruptJumpSet());
		if(!s.getIsStandard())
		{
			pThreshHieght.setText("NA");
			pThreshHieght.setEditable(false);
			pThreshHieght.setBackground(new Color(225,225,225));
			sd.setText("NA");
			sd.setEditable(false);
			sd.setBackground(new Color(225,225,225));
			smoothWindow.setEditable(true);
			smoothWindow.setBackground(Color.WHITE);
			smoothWindow.setText(Integer.toString(s.getParameterSet().getSmoothWindow()));
		}
		else
		{
			pThreshHieght.setEditable(true);
			pThreshHieght.setBackground(Color.WHITE);
			pThreshHieght.setText(Float.toString(s.getParameterSet().getPeakHeightThreshold()));
			sd.setEditable(true);
			sd.setBackground(Color.WHITE);
			sd.setText(Float.toString(s.getParameterSet().getStandardDev()));
			smoothWindow.setText("NA");
			smoothWindow.setEditable(false);
			smoothWindow.setBackground(new Color(225,225,225));
		}
			
		
	}
	
	private void blankDisplay()
	{
		maxInterSlopeDist.setText(null);
		numTrimBeg.setText(null);
		numTrimEnd.setText(null);
		regWinSize.setText(null);
		negSlope.setText(null);
		posSlope.setText(null);
		pThresh.setText(null);
		pThreshHieght.setText(null);
		sd.setText(null);
		smoothWindow.setText(null);
		abrubtJumpBox.setEnabled(false);
	}

}
