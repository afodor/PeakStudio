package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import experimentSets.Spectra;
import experimentSets.StandardWeights;
import viewer.FsaFrame;

public class StndDialog extends JDialog implements ActionListener, ItemListener
{
	private static final long serialVersionUID = -3034519295495220964L;
	private FsaFrame fsaFrame;
	private JPanel mainPanel,topPanel,midPanel,botPanel;
	private JTextArea weights;
	private JLabel dropMenuLabel = new JLabel("Standards File");
	private JButton closeButton = new JButton("Close");
	private JButton stndButton = new JButton("Import Standards");
	private JButton deleteButton = new JButton("Remove");
	private JButton applyGlobalButton = new JButton("Apply To All Spectra");
	private JButton applySelectedSpectra = new JButton("Apply To Selected Spectra");
	private DefaultComboBoxModel dropBoxModel = new DefaultComboBoxModel();
	private JComboBox dropBox;
	private List<StandardWeights> stndList;
	private MyApplyWeightsWorker myWorker;
	private MyApplySelectedWorker mySelectedWorker;
	private JCheckBox autoPeakAdjust = new JCheckBox("Automated Standard Peak Adjusting");
	private boolean autoAdjustOn = true;
	
	public StndDialog(FsaFrame frame)
	{
		super(frame,"Standard Weights");
		this.fsaFrame = frame;
		this.setModal(true);
		this.setSize(600,400);
		this.setLocationRelativeTo(this.fsaFrame);
		this.setResizable(false);
		createDialog();
		setUpDropMenu();
	}
	
	private void createDialog()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		buildTopPanel();
		buildMidPanel();
		buildBottomPanel();
		this.add(mainPanel);
	}
	
	private void buildTopPanel()
	{
		topPanel = new JPanel();
		topPanel.setLayout(new FlowLayout());
		topPanel.setSize(600, 300);
		dropBox = new JComboBox(dropBoxModel);
		dropBox.addActionListener(this);
		topPanel.add(dropMenuLabel);
		topPanel.add(dropBox);
		stndButton.addActionListener(this);
		topPanel.add(stndButton);
		deleteButton.addActionListener(this);
		topPanel.add(deleteButton);
		mainPanel.add(topPanel,BorderLayout.NORTH);
	}
	
	private void buildMidPanel()
	{
		midPanel = new JPanel();
		midPanel.setLayout(new BorderLayout());
		midPanel.setPreferredSize(new Dimension(600,300));
		JPanel hold1 = new JPanel();
		hold1.setLayout(new GridLayout(3, 1));
		hold1.add(new JPanel());
		hold1.add(buildAutoPeakAdjustPanel());
		hold1.setSize(300, 300);
		midPanel.add(hold1,BorderLayout.WEST);
		midPanel.add(buildWeightPanel(), BorderLayout.EAST);
		//midPanel.add(new JPanel());
		mainPanel.add(midPanel,BorderLayout.CENTER);
	}
	private JPanel buildAutoPeakAdjustPanel()
	{
		JPanel apa = new JPanel();
		JPanel inner = new JPanel();
		inner.setLayout(new BorderLayout());
		apa.setLayout(new BorderLayout());
		autoPeakAdjust.addItemListener(this);
		autoPeakAdjust.setSelected(true);
		apa.add(autoPeakAdjust,BorderLayout.CENTER);
		JTextArea apaText = new JTextArea();
		//apaText.setText("*NOTE:\nAutomated adjustment of Standard Peaks\nassumes Peak Area follows a normal distribution");
		apaText.setBackground(new Color(225,225,225));
		apaText.setSize(500, 250);
		apaText.setEditable(false);
		inner.add(apa,BorderLayout.CENTER);
		JPanel text = new JPanel();
		text.add(apaText);
		inner.add(text,BorderLayout.WEST);
		return inner;
		
	}
	private JPanel buildWeightPanel()
	{
		JPanel weightPanel = new JPanel();
		weightPanel.setLayout(new BorderLayout());
		weights = new JTextArea();
		weights.setText("Weights");
		weights.setSize(100, 275);
		weights.setEditable(false);
		JScrollPane spWeights = new JScrollPane(weights);
		spWeights.setPreferredSize(new Dimension(100,275));
		weightPanel.add(new JLabel("Standard Weights"),BorderLayout.NORTH);
		weightPanel.add(spWeights,BorderLayout.SOUTH);
		return weightPanel;
	}
	
	private void toggleActionEnabledAsApproproiate()
	{
		if( fsaFrame.getSpectraList().size() == 0  )
			applyGlobalButton.setEnabled(false);
		else
			applyGlobalButton.setEnabled(true);
		
		if( fsaFrame.getSpectraJTable().getSelectedRowCount() == 0  )
			applySelectedSpectra.setEnabled(false);
		else
			applySelectedSpectra.setEnabled(true);
		
	}
	
	private void buildBottomPanel()
	{
		toggleActionEnabledAsApproproiate();
		botPanel = new JPanel();
		botPanel.setLayout(new FlowLayout());
		botPanel.setSize(500,300);
		applyGlobalButton.addActionListener(this);
		
		botPanel.add(applySelectedSpectra);
		applySelectedSpectra.addActionListener(this);
		
		botPanel.add(applyGlobalButton);
		closeButton.addActionListener(this);
		botPanel.add(closeButton);
		mainPanel.add(botPanel,BorderLayout.SOUTH);
	}
	
	private void displayWeights(List<Short> list)
	{
		weights.setText(null);
		for(Short i: list)
			weights.append(i+"\n");
	}
	
	private void setUpDropMenu()
	{
		this.stndList = this.fsaFrame.getStndWeightsList();
		if(!stndList.isEmpty())
		{
			dropBoxModel.removeAllElements();
			for(StandardWeights sw: stndList)
			{
				dropBoxModel.addElement(sw.getName());
			}
			dropBox.setSelectedIndex(dropBoxModel.getSize()-1);
			displayWeights(stndList.get(dropBox.getSelectedIndex()).getWeights());	
			toggleActionEnabledAsApproproiate();
			deleteButton.setEnabled(true);
		}
		else
		{
			dropBoxModel.removeAllElements();
			dropBoxModel.addElement("Standards not loaded");
			deleteButton.setEnabled(false);
			applyGlobalButton.setEnabled(false);
			applySelectedSpectra.setEnabled(false);
		}
	}
	
	
	private void deleteStndFromList(int index)
	{
		if(!stndList.isEmpty() && index > -1)
		{
			stndList.remove(index);
			setUpDropMenu();
		}
		if(stndList.isEmpty())
		{
			weights.setText(null);
			weights.setText("Weights");
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == dropBox)
		{
			int index = dropBox.getSelectedIndex();
			if(!stndList.isEmpty() && index > -1)
				displayWeights(stndList.get(index).getWeights());
		}
		if(e.getSource() == stndButton)
		{
			this.fsaFrame.loadStandardsFile();
			fsaFrame.setDirty(true);
			
			setUpDropMenu();
		}
		if(e.getSource() == closeButton)
		{
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		if(e.getSource() == applyGlobalButton)
		{
			MyProgressBarDialog mpd = new MyProgressBarDialog("Applying Weights",fsaFrame.getSpectraList().size());
			myWorker = new MyApplyWeightsWorker(mpd,mpd.getProgressBar(),this);
			myWorker.execute();
			mpd.setVisible(true);
		}
	
		if(e.getSource() == applySelectedSpectra)
		{
			MyProgressBarDialog mpd = new MyProgressBarDialog("Applying Weights",fsaFrame.getSpectraJTable().getSelectedRows().length);
			mySelectedWorker = new MyApplySelectedWorker(mpd,mpd.getProgressBar(),this);
			mySelectedWorker.execute();
			mpd.setVisible(true);
		}
		
		if(e.getSource() == deleteButton)
		{
			int index = dropBox.getSelectedIndex();
			deleteStndFromList(index);
		}
	}
	
	private class MyProgressBarDialog extends JDialog
	{
		private static final long serialVersionUID = 1L;
		private String string;
		private JProgressBar jbar;
		private int max;
		private JButton cancel;
		public MyProgressBarDialog(String s, int max) 
		{
			super(fsaFrame,"Working...");
			this.string = s;
			this.max = max;
			init();
			this.setAlwaysOnTop(true);
			this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			this.setSize(200,100);
			this.setLocationRelativeTo(null);
			this.setModal(true);
			this.pack();
			this.setResizable(true);
		}
		public JProgressBar getProgressBar()
		{
			return this.jbar;
		}
		public JButton getCancelButton()
		{
			return this.cancel;
		}
		private void init()
		{
			try
			{
				URL imageUrl = fsaFrame.getClass().getResource("PSlogoSmall.png");
				Image logoImage = ImageIO.read(imageUrl);
				ImageIcon icon = new ImageIcon(logoImage);
				jbar = new JProgressBar(0,max);
				jbar.setPreferredSize(new Dimension(200,20));
				cancel = new JButton("Cancel");
				jbar.setString("Working");
				jbar.setStringPainted(true);
				jbar.setValue(0); 
				JLabel label = new JLabel(this.string+": ");
				JPanel center_panel = new JPanel();
				center_panel.setSize(200, 75);
				center_panel.add(new JLabel(icon));
				center_panel.add(jbar);
				JPanel bot_panel = new JPanel();
				bot_panel.setSize(200, 75);
				//bot_panel.add(cancel);
				JPanel top_panel = new JPanel();
				top_panel.add(label);
				this.getContentPane().add(top_panel,BorderLayout.NORTH);
				this.getContentPane().add(center_panel, BorderLayout.CENTER);
				this.getContentPane().add(bot_panel,BorderLayout.SOUTH);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(fsaFrame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	private void displayErrors( List<String> errorList, Exception lastException )
	{
		StringBuffer buff = new StringBuffer();
		
		buff.append("Error for " + errorList.size() + " " + lastException.getMessage() + "\n");
		
		for( String s : errorList )
			buff.append( s + " " );
		
		JOptionPane.showMessageDialog(fsaFrame, buff.toString(), "Error", JOptionPane.ERROR_MESSAGE );
		
	}
	private class MyApplyWeightsWorker extends SwingWorker<Void, Void>
	{
		private JDialog jdialog;
		private JProgressBar jbar;
		private JDialog parent;
		private List<StandardWeights> s_weights;
		public MyApplyWeightsWorker(JDialog dialog, JProgressBar jbar,JDialog parent)
		{
			this.jdialog = dialog;
			this.jbar = jbar;
			this.parent = parent;
		}
		@Override
		protected Void doInBackground() throws Exception 
		{
			int index = dropBox.getSelectedIndex();
			List<String> errorList = new ArrayList<String>();
			Exception lastException = null;
			int x=0;
			s_weights = new ArrayList<StandardWeights>();
			for( Spectra s : fsaFrame.getSpectraList())
			{
				try
				{
					s_weights.add(s.getFileDescriptor().getStndWeightsObject());
					s.getFileDescriptor().setStndWeightsObject(stndList.get(index));
					s.callFeatures();
					
					s.getFileDescriptor().generateBasePairCalls(false);
					if(s.getIsStandard() && autoAdjustOn)
						s.autoAdjustPeaks();//fsaFrame.autoAdjustPeaks(s);
					//if(!s.getIsStandard())
						//s.adjustDataPeaks();
					fsaFrame.setDirty(true);
					SwingUtilities.invokeLater(new SetterClass(x));
					x++;
				}
				catch(Exception ex)
				{
					String name = "";
					
					try
					{
						name = s.getFileDescriptor().getFileNamePrefix();
					}
					catch(Exception ex2)
					{
						// at this point not much we can do
						ex2.printStackTrace();
					}
					
					errorList.add(name);
					lastException = ex;
					ex.printStackTrace();
				}
			}
			
			if( errorList.size() > 0 )
			{
				displayErrors(errorList, lastException);
			}
			return null;
		}
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				int size = fsaFrame.getSpectraList().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		protected void done() 
		{
			jdialog.dispose();
			fsaFrame.getSpectraJTable().getModel().fireTableDataChanged();
			fsaFrame.getFsaPanel().forceRedraw();
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			fsaFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			this.parent.dispose();
		}
	}
	
	private class MyApplySelectedWorker extends SwingWorker<Void, Void>
	{
		private JDialog jdialog;
		private JProgressBar jbar;
		private JDialog parent;
		public MyApplySelectedWorker(JDialog dialog, JProgressBar jbar,JDialog parent)
		{
			this.jdialog = dialog;
			this.jbar = jbar;
			this.parent = parent;
		}
		
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run()
			{
				jbar.setValue(x);
				int size = fsaFrame.getSpectraList().size();
				jbar.setString((int)(((float)x/size)*100)+" % "+"Complete");
				
			}
		}
		@Override
		protected Void doInBackground() throws Exception 
		{
			setCursor(new Cursor(Cursor.WAIT_CURSOR));
			int[] selectedRows = fsaFrame.getSpectraJTable().getSelectedRows();
			List<String> errorList = new ArrayList<String>();
			Exception lastEx = null;
			int x =0;
			for( Integer i : selectedRows)
			{
				int index = fsaFrame.getSpectraJTable().getModel().getSpectraRowNumber(i);
				Spectra s = fsaFrame.getSpectraList().get(index);
				
				try
				{
					s.getFileDescriptor().setStndWeightsObject(stndList.get(dropBox.getSelectedIndex()));
					s.callFeatures();
					s.getFileDescriptor().generateBasePairCalls(false);
					if(s.getIsStandard() && autoAdjustOn)
						s.autoAdjustPeaks();//fsaFrame.autoAdjustPeaks(s);
					//if(!s.getIsStandard())
					//	s.adjustDataPeaks();
					SwingUtilities.invokeLater(new SetterClass(x));
					x++;
					fsaFrame.setDirty(true);
				}
				catch(Exception ex)
				{
					String name = "";
					
					try
					{
						name = s.getFileDescriptor().getFileNamePrefix();
					}
					catch(Exception ex2)
					{
						// at this point not much we can do
						ex2.printStackTrace();
					}
					
					errorList.add(name);
					lastEx=ex;
					ex.printStackTrace();
				}
			}
		
			if( errorList.size() > 0 )
			{
				displayErrors(errorList, lastEx);
			}
			
			
			return null;
		}
		@Override
		protected void done() 
		{
			fsaFrame.getSpectraJTable().getModel().fireTableDataChanged();
			fsaFrame.getFsaPanel().forceRedraw();
			this.jdialog.dispose();
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			fsaFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			this.parent.dispose();
		}
	}
	@Override
	public void itemStateChanged(ItemEvent e)
	{
		JCheckBox jc = (JCheckBox) e.getSource();
    	if(jc.isSelected())
    	{
    		this.autoAdjustOn = true;
    	}
    	else
    		this.autoAdjustOn = false;
		
	}
	
}
