package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;

import viewer.FsaFrame;
import experimentSets.Spectra;

public class PeakDestroyerDialog extends JDialog implements ActionListener
{
	private static final long serialVersionUID = 1L;
	private FsaFrame parentFrame;
	private JButton applyButton = new JButton("Apply to this spectra");
	private JButton closeButton = new JButton("Close");
	private JButton applyGlobal = new JButton("Apply to all selected spectra");
	private JPanel bottomPanel, topPanel,mainPanel,midPanel;
	private JRadioButton dataRB,stndRB,allRB;
	private ButtonGroup butGroup;
	private List<Spectra> localSpectra =new ArrayList<Spectra>();
	private List<Spectra> actionSpectra = new ArrayList<Spectra>();
	private DefaultComboBoxModel dropBoxModel = new DefaultComboBoxModel();
	private JComboBox dropBox;
	private JLabel dropMenuLabel = new JLabel("Spectra");
	private JLabel peakCountLabel = new JLabel("");
	private JSpinner peakSpinner = new JSpinner();
	
	public PeakDestroyerDialog(FsaFrame frame)
	{
		super(frame,"Spectra Parameter Set");
	
		this.parentFrame= frame;
		this.setAlwaysOnTop(true);
		this.setModal(true);
		this.setSize(400,500);
		this.setLocationRelativeTo(frame);
		this.setResizable(false);
		buildDialog();
		
		int[] selectedRows = frame.getSpectraJTable().getSelectedRows();
		for( Integer i : selectedRows)
		{
			int index = frame.getSpectraJTable().getModel().getSpectraRowNumber(i);
			Spectra s = frame.getSpectraList().get(index);
			actionSpectra.add(s);
			localSpectra.add(s);
		}
		
		setSpectra();
	}
	
	private void buildDialog() 
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		buildTopPanel();
		buildMidPanel();
		buildBottomPanel();
		this.add(mainPanel);
	}
	
	private void buildTopPanel()
	{
		topPanel = new JPanel();
		JPanel rBpanel = new JPanel();
		rBpanel.setLayout(new FlowLayout());
		allRB = new JRadioButton("All");
		allRB.setSelected(true);
		dataRB = new JRadioButton("Data");
		stndRB = new JRadioButton("Standards");
		allRB.addActionListener(this);
		dataRB.addActionListener(this);
		stndRB.addActionListener(this);
		butGroup = new ButtonGroup();
		butGroup.add(allRB);
		butGroup.add(dataRB);
		butGroup.add(stndRB);
		rBpanel.add(allRB);
		rBpanel.add(dataRB);
		rBpanel.add(stndRB);
		topPanel.setLayout(new BorderLayout());
		topPanel.setSize(500, 120);
		dropBox = new JComboBox(dropBoxModel);
		dropBox.addActionListener(this);
		topPanel.add(dropMenuLabel);
		topPanel.add(rBpanel);
		topPanel.add(dropBox,BorderLayout.SOUTH);
		mainPanel.add(topPanel,BorderLayout.NORTH);
	}
	
	private void buildMidPanel() 
	{
		midPanel = new JPanel();
		midPanel.setBorder(BorderFactory.createEtchedBorder());
		midPanel.setLayout(new GridLayout(7,1));
		midPanel.add(peakCountLabel);
		mainPanel.add(midPanel);
		
		JPanel aPanel = new JPanel();
		aPanel.setLayout(new FlowLayout());
		aPanel.add(new JLabel("Delete peak: "));
		aPanel.add(peakSpinner);
		midPanel.add(aPanel);
		
	}
	
	private void buildBottomPanel()
	{
		bottomPanel = new JPanel(new BorderLayout());
		bottomPanel.setBorder(BorderFactory.createBevelBorder(3));
		bottomPanel.setLayout(new FlowLayout());
		buildButtons();
		bottomPanel.add(applyButton);
		bottomPanel.add(applyGlobal);
		bottomPanel.add(closeButton);
		mainPanel.add(bottomPanel,BorderLayout.SOUTH);
	}
	
	private void buildButtons()
	{
		closeButton.addActionListener(this);
		closeButton.setSize(10,10);
		applyButton.addActionListener(this);
		applyButton.setSize(10, 10);
		applyGlobal.addActionListener(this);
		applyGlobal.setSize(15, 10);
	}
	
	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource() == applyButton)
		{
			applyChanges();
		}
		if(e.getSource() == closeButton)
		{
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
		if(e.getSource() == applyGlobal)
		{
			applyGlobally();
		}
		if(e.getSource() == dropBox)
		{
			try
			{
				if(dropBox.getSelectedIndex() > -1 && !this.actionSpectra.isEmpty())
				{
					Spectra s = actionSpectra.get(dropBox.getSelectedIndex());
					
					if( s.getLastGeneratedPeakSet() == null )
					{
						peakCountLabel.setText("No peaks called");
						peakSpinner.setEnabled(false);
					}
					else
					{
						peakCountLabel.setText(s.getLastGeneratedPeakSet().size() + " peaks called");
						peakSpinner.setEnabled(true);
						peakSpinner.setModel(new 
								SpinnerNumberModel(1,1,s.getLastGeneratedPeakSet().size(),1 ));
					}
						
					
					validateTree();
				}
			}
			catch(Exception x){x.printStackTrace();}
		}
		if(e.getSource() == stndRB)
		{
			this.actionSpectra = new ArrayList<Spectra>();
			
			for(Spectra s : localSpectra)
				if( s.getIsStandard())
					actionSpectra.add(s);
			
			applyGlobal.setText("Apply to selected standards");
			setUpDropMenu(this.actionSpectra);
		}
		if(e.getSource() == dataRB )
		{
			this.actionSpectra = new ArrayList<Spectra>();
			
			for(Spectra s : localSpectra)
				if( !s.getIsStandard())
					actionSpectra.add(s);
			
			applyGlobal.setText("Apply to selected data spectra");
			setUpDropMenu(this.actionSpectra);
		}
		if(e.getSource() == allRB)
		{
			this.actionSpectra = new ArrayList<Spectra>();
			
			for(Spectra s : localSpectra)
					actionSpectra.add(s);
			
			applyGlobal.setText("Apply to all selected spectra");
			setUpDropMenu(this.actionSpectra);
		}
	}
	
	private void applyGlobally()
	{
		System.out.println("In apply global with " + actionSpectra.size());
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
		List<Exception> exList = new ArrayList<Exception>();
		List<String> nameList = new ArrayList<String>();
		
		for( Spectra s : actionSpectra )
		{
			Exception ex = deleteAPeak(s,  ((Integer) peakSpinner.getModel().getValue())-1);
			
			if( ex != null)
			{
				exList.add(ex);
				
				try{ nameList.add(s.getFileDescriptor().getFileNamePrefix()); } 
				catch(Exception ex2) { ex2.printStackTrace(); }
			}
			
			if( exList.size() != 0)
			{
				StringBuffer buff = new StringBuffer();
				
				for( String s2 : nameList)
					buff.append(s2 + " " );
				
				JOptionPane.showMessageDialog(this, "Failed " + exList.get(0) + "\n" +  buff.toString(),
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
		parentFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		dispose();
		parentFrame.getSpectraJTable().getModel().fireTableDataChanged();
		parentFrame.getFsaPanel().forceRedraw();
	}
	
	private void applyChanges()
	{
		setCursor(new Cursor(Cursor.WAIT_CURSOR));
		Spectra s = actionSpectra.get(dropBox.getSelectedIndex());
		
		Exception ex = deleteAPeak(s,  ((Integer) peakSpinner.getModel().getValue())-1);
		
		if( ex != null)
		{
			JOptionPane.showMessageDialog(this, "Failed " + ex.getMessage(), 
					"Error", JOptionPane.ERROR_MESSAGE);
		}
		else
		{
			parentFrame.getSpectraJTable().getModel().fireTableDataChanged();
			parentFrame.getFsaPanel().forceRedraw();
		}
		parentFrame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		dispose();
		parentFrame.getSpectraJTable().getModel().fireTableDataChanged();
		parentFrame.getFsaPanel().forceRedraw();
	}
	
	private Exception deleteAPeak(Spectra s, int peak) 
	{
		Exception ex=null;
		
		try
		{
			s.getLastGeneratedPeakSet().remove(peak);
			
			if( s.getFileDescriptor().getSizeStandards() != null )
				s.getFileDescriptor().generateBasePairCalls(false);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ex =e;
		}
		
		return ex;
	}
	
	public static boolean isNumber(String s)
	{
		try
		{
			Double.parseDouble(s);
		}
		catch(Exception x)
		{
			return false;
		}
		return true;
		
	}
	
	public void setSpectra()
	{
		setUpDropMenu(actionSpectra);
	}
	
	private void setUpDropMenu(List<Spectra> specList)
	{
		dropBoxModel.removeAllElements();
		try
		{
			if(!specList.isEmpty())
			{
				for(Spectra s: specList)
				{
					dropBoxModel.addElement(s.getName()+"   "+s.getDataChannel());
				}
				dropBox.setSelectedIndex(0);
				applyButton.setEnabled(true);
				applyGlobal.setEnabled(true);
			}
			else
			{
				dropBoxModel.addElement("Spectra Not Selected");
				applyButton.setEnabled(false);
				applyGlobal.setEnabled(false);
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
