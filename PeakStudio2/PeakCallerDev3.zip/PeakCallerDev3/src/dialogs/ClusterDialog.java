package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextPane;
import javax.swing.SwingWorker;

import java.awt.event.ItemListener;
import binning.AbstractPeakCallBinningMethod;
import binning.PCDynamicProgramming;
import binning.PCFuhrman04;
import binning.PCFuhrmanShiftingMethod;
import binning.PCRandomBin;
import binning.PCSimpleBinRange;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.AverageDistance;
import de.linuxusers.clustering.linkage.FurthestNeighbour;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.NearestNeighbour;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.FsaFileDescriptor;
import experimentSets.Spectra;
import experimentSets.StandardWeights;
import viewer.FsaFrame;

public class ClusterDialog extends JDialog implements ActionListener, ItemListener
{
	
	private static final long serialVersionUID = 1L;
	private FsaFrame frame;
	private ClusterDialog thisFrame;
	private MyClusterWorker myWorker;
	private JTable table;
	private JPanel mainPanel,topWestPanel, cOptionsPanel, topPanel, midPanel,botPanel, panel3Panel, clusterMethodPanel;
	private JRadioButton AvgDistance,NearestNeighbor, FurthestNeighbor, Wards, YesBinary, NoBinary, SimpleBin, RandomBin, DPbin, ShiftBin, Fuhrman04Bin;
	private JTextArea weights;
	private final JTextPane binaryThresholdTextPane = new JTextPane();
	private final JTextPane simpleBinSizeTextPane = new JTextPane();
	private final JTextPane startRangeTextPane = new JTextPane();
	private final JTextPane stopRangeTextPane = new JTextPane();
	private final JTextPane randomNumberofTimesTextPane = new JTextPane();
	private JPanel infoBox = new JPanel();
	private JButton launchClusterButton = new JButton("Launch Cluster");
	private JButton cancelButton = new JButton("Cancel");
	private JButton outputDirButton = new JButton("Choose Output Dir");
	private JButton launchParameterButton = new JButton("Edit Parameters");
	private JButton launchStandardsButton = new JButton("Edit Standards");
	private JButton thresholdButton = new JButton("Choose threshold");
	private JButton simpleBinSizeButton = new JButton("Set Simple Bin size");
	private JButton randomBinIterButton = new JButton("Set # Random Runs");
	private JButton setRangeButton = new JButton("Set Spectra Range");
	private JComboBox dropBox;
	private List<StandardWeights> list;
	private int[] rows;
	private final int CH_DEFAULT = 3;
	private File outPutDir;
	private ArrayList<AbstractPeakCallBinningMethod> bmList = new ArrayList<AbstractPeakCallBinningMethod>();
	private boolean isBinary;
	private double threshold = 10;
	LinkageMethod linkageMethod;
	private int bmMethodArray = 0;
	private float simpleBinSize = 1;
	private int randomNumofIterations = 10;
	private String currentBinSizingMethod = "Simple Bin";
	private String currentClusterMethod = "Googly";
	private int startRange = 400;
	private int stopRange = 1200;
	
	
	public ClusterDialog(FsaFrame frame)
	{
		super(frame,"ARISA Cluster Options");
		this.frame = frame;
		this.thisFrame = this;
		outPutDir = frame.getDirectory();
		this.setModal(true);
		this.setSize(760,280);
		this.setLocationRelativeTo(this.frame);
		//this.setResizable(false);
				
		//JFileChooser chooser = new JFileChooser();
		//FileSystemView view = chooser.;
		//outPutDir =view.getDefaultDirectory();
		
		createDialog();
		
		bmMethodArray = 0;	
		this.frame.setResizable(true);		
	}
	
	private void createDialog()
	{
		mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		buildTabPanel1();
		buildTabPanel2();
		buildTabPanel3();
		buildtabPanel4();
		
		JTabbedPane tabbedPane = new JTabbedPane();
		
		tabbedPane.addTab("Step 1: Choose Bin Size", null, topPanel, "Our paper says this choice doesn't matter much");
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);

		
		tabbedPane.addTab("Step 2: Choose Clustering Method", null, midPanel,
		                  "Wards is default for a reason");
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);

		
		tabbedPane.addTab("Step 3: Choose clustering options", null, panel3Panel,
		                  "Choose binary format here (or not)");
		tabbedPane.setMnemonicAt(2, KeyEvent.VK_3);

		
		tabbedPane.addTab("Step 4: Launch Cluster",null, botPanel,
		                      "This is the last step");
		tabbedPane.setMnemonicAt(3, KeyEvent.VK_4);
		mainPanel.add(tabbedPane);
		this.add(mainPanel);
		this.setResizable(true);
	}
	
	

	private void buildTabPanel1()
	{
		topPanel =  new JPanel();
		topPanel.setLayout(new BorderLayout());
		topWestPanel = new JPanel();
				
		buildBinSizingPanel();
			    	    
	    topWestPanel.setBorder(BorderFactory.createTitledBorder("Choose binning method"));
	    topPanel.add(topWestPanel,BorderLayout.CENTER);
	}
	
	private void buildTabPanel2()
	{
		midPanel = new JPanel();
		midPanel.setLayout(new GridBagLayout());
			
		buildRadioMethodBox();
		midPanel.add(clusterMethodPanel);
		midPanel.setBorder(BorderFactory.createTitledBorder("Select Clustering methods (Default = Wards)"));
	}
	
	private void buildRadioMethodBox()
    {
		
		clusterMethodPanel = new JPanel();
		clusterMethodPanel.setLayout(new GridLayout(2,2));
		
		ButtonGroup buttonGroup = new ButtonGroup();
		AvgDistance = new JRadioButton("Average Distance (UPGMA)");
	    AvgDistance.addActionListener(this);
		buttonGroup.add(AvgDistance);
		clusterMethodPanel.add(AvgDistance);
	   
	    NearestNeighbor = new JRadioButton("Nearest Neighbor (Single Linkage)");
	    NearestNeighbor.addActionListener(this);
	    buttonGroup.add(NearestNeighbor);
	    clusterMethodPanel.add(NearestNeighbor);
	    
	    FurthestNeighbor = new JRadioButton("Furthest Neighbor (Complete Linkage)");
	    FurthestNeighbor.addActionListener(this);
	    buttonGroup.add(FurthestNeighbor);
	    clusterMethodPanel.add(FurthestNeighbor);
	    
	    Wards = new JRadioButton("Wards");
	    Wards.addActionListener(this);
	    buttonGroup.add(Wards);
	    clusterMethodPanel.add(Wards);
	    
	    Wards.setSelected(true);
	    currentClusterMethod = "Wards";
    }
	
	
	private void buildTabPanel3()
	{
		panel3Panel = new JPanel();
		panel3Panel.setLayout(new BorderLayout());
		//panel3Panel.add(new JLabel("Grayed out buttons are that way due to choices made elsewhere"));
		//eastPanel.add(new JPanel());
		panel3Panel.setBorder(BorderFactory.createTitledBorder("Monkey"));
		
		buildClusterOptionsPanel();
		panel3Panel.add(cOptionsPanel,BorderLayout.NORTH);
		
		JPanel binaryPanel = new JPanel();
		binaryPanel.setBorder(BorderFactory.createTitledBorder("Do you want to use Binary format?"));
		
		ButtonGroup buttonGroup = new ButtonGroup();
				 
	    NoBinary = new JRadioButton("No");
	    buttonGroup.add(NoBinary);
	    binaryPanel.add(NoBinary, BorderLayout.CENTER);
	    NoBinary.setSelected(true);
	    NoBinary.addActionListener(this);
	    
	    YesBinary = new JRadioButton("Yes");
	    buttonGroup.add(YesBinary);
	    binaryPanel.add(YesBinary, BorderLayout.CENTER);
	    YesBinary.addActionListener(this);		
	    
	    binaryThresholdTextPane.setPreferredSize(new Dimension(30, 20));
	    binaryThresholdTextPane.setText(String.valueOf(threshold));
	    binaryThresholdTextPane.setBackground(Color.darkGray);
	   	    
	    thresholdButton.setToolTipText("Change binary threshold level");
	    thresholdButton.setEnabled(false);
	    thresholdButton.addActionListener(this);
	    binaryPanel.add(thresholdButton, BorderLayout.CENTER);
	    binaryPanel.add(binaryThresholdTextPane,BorderLayout.SOUTH);
		panel3Panel.add(binaryPanel,BorderLayout.CENTER);
		
		
		JPanel rangePanel = new JPanel();
		int maxRangeofSizeStandards = calcSmallestBiggestSizeStandard();
		stopRange = maxRangeofSizeStandards;
		rangePanel.setBorder(BorderFactory.createTitledBorder("Set the nucleotide range for ARISA analysis (default = 400 to "
				+ maxRangeofSizeStandards + " NT)"));
		
		
		startRangeTextPane.setPreferredSize(new Dimension(70, 20));
		startRangeTextPane.setText(String.valueOf(startRange));
		startRangeTextPane.setBackground(Color.white);
		
		stopRangeTextPane.setPreferredSize(new Dimension(70, 20));
		stopRangeTextPane.setText(String.valueOf(stopRange));
		stopRangeTextPane.setBackground(Color.white);
		
		setRangeButton.setToolTipText("Press me to make the new ranges from the boxes to my left");
		setRangeButton.setEnabled(true);
		setRangeButton.addActionListener(this);
	    
		rangePanel.add(startRangeTextPane);
		rangePanel.add(stopRangeTextPane);
		rangePanel.add(setRangeButton);		
		panel3Panel.add(rangePanel,BorderLayout.SOUTH);
	}
	
	private int calcSmallestBiggestSizeStandard() 
	{
		int smallestMaxValue = 1200;
		List<StandardWeights> lsw = frame.getStndWeightsList();
		if (lsw.size() == 0) return 1200;
		
		for (StandardWeights sw : lsw)
		{
			int biggestSizerightNow = 0;
			for (int i = 0; i < sw.getWeights().size();i++)
			{
				if (sw.getWeights().get(i) > biggestSizerightNow) biggestSizerightNow = sw.getWeights().get(i);
			}
			if (smallestMaxValue > biggestSizerightNow) smallestMaxValue = biggestSizerightNow;
		}
		return smallestMaxValue;
	}

	private void buildtabPanel4()
	{
		botPanel = new JPanel(); // will center everything in center of panel
		botPanel.setLayout(new GridBagLayout());
				
		JPanel inner4Panel = new JPanel(); // will hold buttons in north, and text summary in SOUth
		inner4Panel.setLayout(new BorderLayout());
		
		JPanel inner4UpperPanel = new JPanel(); // will hold buttons
		inner4UpperPanel.setLayout(new GridBagLayout());
		
		launchParameterButton.addActionListener(this);
		inner4UpperPanel.add(launchParameterButton);
		launchStandardsButton.addActionListener(this);
		inner4UpperPanel.add(launchStandardsButton);
		outputDirButton.addActionListener(this);
		inner4UpperPanel.add(outputDirButton);
		cancelButton.addActionListener(this);
		inner4UpperPanel.add(cancelButton);
		launchClusterButton.addActionListener(this);
		launchClusterButton.setEnabled(true);
		if (frame.getSpectraList().size()< 4)
			{
				launchClusterButton.setEnabled(false);
				launchClusterButton.setText("Not enough expts chosen, can't launch");
			}
		
		inner4UpperPanel.add(launchClusterButton);
		inner4Panel.add(inner4UpperPanel,BorderLayout.SOUTH);
		
		JPanel inner4LowerPanel = new JPanel(); // will data summary info
		inner4LowerPanel.setLayout(new GridBagLayout());
		
		updateInfoBox();
		inner4LowerPanel.add(infoBox);
		
		inner4Panel.add(inner4LowerPanel,BorderLayout.NORTH);
		botPanel.add(inner4Panel); 	
	}
	
	private void updateInfoBox()
	{
		infoBox.removeAll();
		infoBox.setLayout(new BorderLayout());
		
		String info = "Output Directory = " + outPutDir.getAbsolutePath();
		JLabel label1 = new JLabel();
		label1.setText(info);
		
		infoBox.add(label1,BorderLayout.NORTH);
		info =  "Number of Experiments = " + frame.getExperimentSet().getFileDescriptors().size() + "                  Bin Size = " + (int) simpleBinSize +
			"                   Binary format = " + isBinary + "         Starting Range: " + startRange;
		
		JLabel label2 = new JLabel();
		label2.setText(info);
		infoBox.add(label2,BorderLayout.CENTER);
		info = "Clustering Method = " + currentClusterMethod;
		info += "                        Bin Sizing Method = " + currentBinSizingMethod;
		info +=  "                      Stopping Range: " + stopRange; 
		
		JLabel label3 = new JLabel();
		label3.setText(info);
		infoBox.add(label3,BorderLayout.SOUTH);
		infoBox.setSize(700,280);
		infoBox.setBackground(Color.PINK) ;
		infoBox.repaint();
		infoBox.validate();
	}
	

	private void buildBinSizingPanel() 
	{
		topWestPanel.setLayout(new GridLayout(3,2));
				
		ButtonGroup buttonGroup = new ButtonGroup();
		 
	    SimpleBin = new JRadioButton("Simple Binning Method");
	    buttonGroup.add(SimpleBin);
	    topWestPanel.add(SimpleBin);
	    SimpleBin.setSelected(true);
	    SimpleBin.addActionListener(this);
	    	    
	    RandomBin = new JRadioButton("random Binning Method");
	    buttonGroup.add(RandomBin);
	    topWestPanel.add(RandomBin);
	    RandomBin.addActionListener(this);
		
	    Fuhrman04Bin = new JRadioButton("Fuhrman's 2004 Expanding Bin Method");
	    buttonGroup.add(Fuhrman04Bin);
	    topWestPanel.add(Fuhrman04Bin);
	    Fuhrman04Bin.addActionListener(this);
	    
	    DPbin = new JRadioButton("Dynamic Programming Bin Method");
	    buttonGroup.add(DPbin);
	    topWestPanel.add(DPbin);
	    DPbin.addActionListener(this);
	    
	    ShiftBin = new JRadioButton("Fuhrman's Shifting Bin Method");
	    buttonGroup.add(ShiftBin);
	    topWestPanel.add(ShiftBin);
	    ShiftBin.addActionListener(this);
		
	}

	private void buildClusterOptionsPanel() 
	{
		cOptionsPanel = new JPanel();
		cOptionsPanel.setLayout(new GridLayout(2,4));
		cOptionsPanel.add(new JLabel("Choose Bin Size: "));
		cOptionsPanel.setBorder(BorderFactory.createTitledBorder("Binning options:"));
		//topEastPanel.add(new JLabel(" "));
		
	    simpleBinSizeTextPane.setPreferredSize(new Dimension(30, 20));
	    simpleBinSizeTextPane.setText(String.valueOf(simpleBinSize));
	    simpleBinSizeTextPane.setBackground(Color.white);
	    
	    simpleBinSizeButton.setToolTipText("Choose size of Bins");
	    simpleBinSizeButton.setEnabled(true);
	    simpleBinSizeButton.addActionListener(this);
	    
	    cOptionsPanel.add(simpleBinSizeButton);
	    cOptionsPanel.add(simpleBinSizeTextPane);
	    
	    cOptionsPanel.add(new JLabel("Set # of Random iterations: "));
	    //topEastPanel.add(new JLabel(" "));
	    randomNumberofTimesTextPane.setPreferredSize(new Dimension(30, 20));
	    randomNumberofTimesTextPane.setText(String.valueOf(randomNumofIterations));
	    randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
	    randomNumberofTimesTextPane.setEnabled(false);
	    
	    randomBinIterButton.setToolTipText("# of random runs");
	    randomBinIterButton.setEnabled(false);
	    randomBinIterButton.addActionListener(this);
	    
	    cOptionsPanel.add(randomBinIterButton);
	    cOptionsPanel.add(randomNumberofTimesTextPane);
	}
	
	public void setDisplay()
	{
		try
		{
			this.table = this.frame.getTable();
			this.rows = this.table.getSelectedRows();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	private void displayWeights(List<Short> list)
	{
		weights.setText(null);
		for(Short i: list)
			weights.append(i+"\n");
	}
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == dropBox)
		{
			int index = dropBox.getSelectedIndex();
			if(!list.isEmpty() && index > -1)
				displayWeights(list.get(index).getWeights());
		}
		
		if(e.getSource() == cancelButton)
		{
			this.setVisible(false);
		}
		if(e.getSource() == launchClusterButton)
		{
			this.setVisible(false);
			try 
			{
				frame.setCursor(new Cursor(Cursor.WAIT_CURSOR));
				//launchAnalysis();
				MyProgressBarDialog mpd = new MyProgressBarDialog("Clustering",10);
				mpd.getCancelButton().addActionListener(new ActionListener()
				{
					@Override
					public void actionPerformed(ActionEvent e) 
					{
						myWorker.cancel(true);	
					}
				});
				myWorker = new MyClusterWorker(mpd);
				myWorker.execute();
				mpd.setVisible(true);
				frame.setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			} catch (Exception e1) 
			{
				e1.printStackTrace();
			}
		}
		if(e.getSource() == launchStandardsButton)
		{
			StndDialog  stdSetDialog = new StndDialog(frame);
			stdSetDialog.setVisible(true);	
		}
		if(e.getSource() == launchParameterButton)
		{
			ParameterSetDialog psd = new ParameterSetDialog(frame);
			psd.setSpectra();
			psd.setVisible(true);
		}
		if(e.getSource() == outputDirButton)
		{
			loadOutPutDirFile();
			System.out.println("We launched the dir change, the dis is " + frame.getDirectory().getName());
			updateInfoBox();
		}
		
		if (e.getSource() == NoBinary)
		{
			isBinary = false;
			thresholdButton.setEnabled(false);
			binaryThresholdTextPane.setBackground(Color.darkGray);
			updateInfoBox();
		}
		
		if (e.getSource() ==YesBinary)
		{
			isBinary = true;
			thresholdButton.setEnabled(true);
			binaryThresholdTextPane.setBackground(Color.white);
			
		}
		
		if (e.getSource() ==thresholdButton)
		{
			if (ParameterSetDialog.isNumber(binaryThresholdTextPane.getText()))
			{
				threshold = Double.valueOf(binaryThresholdTextPane.getText());
			}
			binaryThresholdTextPane.setText(String.valueOf(threshold));  // reverting back to original threshold number
			
		}
		
		if (e.getSource() ==FurthestNeighbor)
		{
			//LinkageMethod lm = new FurthestNeighbour();
			//linkageMethod = lm;
			currentClusterMethod = "Furthest Neighbour";
			System.out.println("Cluster method is now " + currentClusterMethod);
		}
		
		if (e.getSource() ==NearestNeighbor)
		{
			//LinkageMethod lm = new NearestNeighbour();
			//linkageMethod = lm;
			currentClusterMethod = "Nearest Neighbour";
			System.out.println("Cluster method is now " + currentClusterMethod);
		}
		
		if (e.getSource() ==AvgDistance)
		{
			//linkageMethod = new AverageDistance();
			currentClusterMethod = "Average Distance";
			System.out.println("Cluster method is now " + currentClusterMethod);
			
		}
		
		if (e.getSource() ==Wards)
		{
			//linkageMethod = new WardsMethod();
			currentClusterMethod = "Wards";
			System.out.println("Cluster method is now " + currentClusterMethod);
			
		}
		if (e.getSource() ==SimpleBin)
		{
			bmMethodArray = 0;  //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(false);
			randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
			randomNumberofTimesTextPane.setEnabled(false);
			
			simpleBinSizeButton.setEnabled(true);
			simpleBinSizeTextPane.setBackground(Color.WHITE);
			simpleBinSizeTextPane.setEnabled(true);
			
			startRangeTextPane.setBackground(Color.WHITE);
			startRangeTextPane.setEnabled(true);
			stopRangeTextPane.setBackground(Color.WHITE);
			stopRangeTextPane.setEnabled(true);
			setRangeButton.setEnabled(true);
			
			currentBinSizingMethod = "Simple Bin";
			System.out.println("Cluster method is now " + currentBinSizingMethod);
		}
		if (e.getSource() ==RandomBin)
		{
			bmMethodArray = 1; //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(true);
			randomNumberofTimesTextPane.setBackground(Color.WHITE);
			randomNumberofTimesTextPane.setEnabled(true);
			
			simpleBinSizeButton.setEnabled(false);
			simpleBinSizeTextPane.setBackground(Color.LIGHT_GRAY);
			simpleBinSizeTextPane.setEnabled(false);
			
			startRangeTextPane.setBackground(Color.WHITE);
			startRangeTextPane.setEnabled(true);
			stopRangeTextPane.setBackground(Color.WHITE);
			stopRangeTextPane.setEnabled(true);
			setRangeButton.setEnabled(true);
			
			currentBinSizingMethod = "Random Bin";
			System.out.println("Cluster method is now " + currentBinSizingMethod);
		}
		if (e.getSource() ==DPbin)
		{
			bmMethodArray = 2; //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(false);
			randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
			randomNumberofTimesTextPane.setEnabled(false);
			
			simpleBinSizeButton.setEnabled(false);
			simpleBinSizeTextPane.setBackground(Color.LIGHT_GRAY);
			simpleBinSizeTextPane.setEnabled(false);
			
			startRangeTextPane.setBackground(Color.LIGHT_GRAY);
			startRangeTextPane.setEnabled(false);
			stopRangeTextPane.setBackground(Color.LIGHT_GRAY);
			stopRangeTextPane.setEnabled(false);
			setRangeButton.setEnabled(false);
			
			currentBinSizingMethod = "Dynamic Programming";
		}
		if (e.getSource() ==ShiftBin)
		{
			bmMethodArray = 3; //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(false);
			randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
			randomNumberofTimesTextPane.setEnabled(false);
			
			simpleBinSizeButton.setEnabled(false);
			simpleBinSizeTextPane.setBackground(Color.LIGHT_GRAY);
			simpleBinSizeTextPane.setEnabled(false);
			
			startRangeTextPane.setBackground(Color.LIGHT_GRAY);
			startRangeTextPane.setEnabled(false);
			stopRangeTextPane.setBackground(Color.LIGHT_GRAY);
			stopRangeTextPane.setEnabled(false);
			setRangeButton.setEnabled(false);
			
			currentBinSizingMethod = "Shifting Bins";
		}
		
		if (e.getSource() ==Fuhrman04Bin)
		{
			bmMethodArray = 4; //hack !! see launchAnalysis method for corresponding values...
			randomBinIterButton.setEnabled(false);
			randomNumberofTimesTextPane.setBackground(Color.LIGHT_GRAY);
			randomNumberofTimesTextPane.setEnabled(false);
			
			simpleBinSizeButton.setEnabled(false);
			simpleBinSizeTextPane.setBackground(Color.LIGHT_GRAY);
			simpleBinSizeTextPane.setEnabled(false);
			
			startRangeTextPane.setBackground(Color.LIGHT_GRAY);
			startRangeTextPane.setEnabled(false);
			stopRangeTextPane.setBackground(Color.LIGHT_GRAY);
			stopRangeTextPane.setEnabled(false);
			setRangeButton.setEnabled(false);
			
			currentBinSizingMethod = "Expanding Bins";
		}
		
		if (e.getSource() ==simpleBinSizeButton)
		{
			if (ParameterSetDialog.isNumber(simpleBinSizeTextPane.getText()))
			{
				simpleBinSize = Float.valueOf(simpleBinSizeTextPane.getText());
			}
			simpleBinSizeTextPane.setText(String.valueOf(simpleBinSize)); 
			
		}
		
		if (e.getSource() ==randomBinIterButton)
		{
			if (ParameterSetDialog.isNumber(randomNumberofTimesTextPane.getText()))
			{
				randomNumofIterations = Integer.valueOf(randomNumberofTimesTextPane.getText());
			}
			randomNumberofTimesTextPane.setText(String.valueOf(randomNumofIterations)); 
			
		}
		
		if (e.getSource() == setRangeButton)
		{
			int startTemp = startRange;
			int stopTemp = stopRange;
			if (ParameterSetDialog.isNumber(startRangeTextPane.getText()))
			{
				startRange = Integer.valueOf(startRangeTextPane.getText());
				
			}
			if (ParameterSetDialog.isNumber(stopRangeTextPane.getText()))
			{
				
				stopRange = Integer.valueOf(stopRangeTextPane.getText());
				
			}
			if (startRange < stopRange)
			{
				startRangeTextPane.setText(String.valueOf(startRange));
				stopRangeTextPane.setText(String.valueOf(stopRange));
			}
			else
			{
				JOptionPane.showMessageDialog(this, "Your ending range value is smaller than the starting value",
	                       "Sorry, this ain't gonna work, Hombre.", JOptionPane.WARNING_MESSAGE);
				startRangeTextPane.setText(String.valueOf(startTemp));
				stopRangeTextPane.setText(String.valueOf(stopTemp));
			}
			
		}
		
		
		updateInfoBox();
		infoBox.revalidate();
		infoBox.repaint();
	}
	
	private void launchAnalysis() throws Exception 
	{
		if (! outPutDir.canWrite())
		{
			loadOutPutDirFile();
		}
		
		try 
		{
			List<Spectra> nonStndList = frame.getNonStndSpectraList();
			
			int a= bmMethodArray;
		      switch (a)
		      {      
		        case 0:
		        	//simple bin, yes this is a hack so to avoid changing exception errors
		        	//bmList.add(new PCSimpleBinFractions(simpleBinSize, nonStndList, threshold, isBinary, true));
		        	bmList.add(new PCSimpleBinRange(simpleBinSize, nonStndList, threshold, isBinary, true,startRange,stopRange));
		           break;
		        case 1:
		        	for (int i = 0; i < randomNumofIterations; i++)
		        	{
		        		bmList.add(new PCRandomBin(nonStndList, isBinary, true, String.valueOf(i)));
		        	}
		          break;
		        case 2:
		        	bmList.add(new PCDynamicProgramming(nonStndList, isBinary, true));
		          break;
		        case 3:
		        	bmList.add(new PCFuhrmanShiftingMethod(nonStndList, isBinary, true));
		        case 4:
		        	bmList.add(new PCFuhrman04(nonStndList, isBinary, true));
		          break;
		        default:
		          System.out.println("Invalid Entry!");
				
		      }
			
		    if (currentClusterMethod.contains("War")) linkageMethod = new WardsMethod();
		    else if (currentClusterMethod.contains("Furthest Neighbour")) linkageMethod = new FurthestNeighbour();
		    else if (currentClusterMethod.contains("Nearest Neighbour")) linkageMethod = new NearestNeighbour();
		    else if (currentClusterMethod.contains("Average Distance")) linkageMethod = new AverageDistance();
		    else throw new Exception(" Failed to create a linkage method. Please contact the Authors, because this is broken.");
		    
		   		      
			for (AbstractPeakCallBinningMethod bm: bmList)
			{
				ArrayList<ArrayList<Double>> list = bm.getBinListofLists();
				//System.out.println(" Our binlistsoflists is " + list.size());
					
				ArrayList<DataPoint> temperatures = new ArrayList<DataPoint>();
					
				for (int i = 0; i < nonStndList.size(); i++)
				{
					String label = nonStndList.get(i).getName();
					ArrayList<Double> values = list.get(i);
					System.out.println(" Our Bin list size is " + values.size() + " for label: " + label);
					temperatures.add( new LabeledDataPoint( i,values, label ));
				}
									
				Cluster topCluster = HierarchicalClusterer.cluster(
								temperatures, linkageMethod);
					
				NewicktreeBuilder s = new NewicktreeBuilder();
				String test = s.getTree(topCluster);
				
											
				File file = AbstractPeakCallBinningMethod.writeNewickFormatToFile(test, outPutDir , bm);
				if (! file.exists())
				{
					// checking if we wrote file. If not rerun writing newick file with a new file.
					JOptionPane.showMessageDialog(frame,
						    "Eggs are not supposed to be green.",
						    "Choose a new location that is preferably writable.",
						    JOptionPane.WARNING_MESSAGE);

				}
				final String[] args = new String[1];
				args[0] = file.getAbsolutePath();
				org.forester.archaeopteryx.Archaeopteryx.main(args);
								
			}
		} catch (Exception e) 
		{	
			JTextPane error = new JTextPane();
			//JScrollPane pane = new JScrollPane();
			//pane.add( e.getStackTrace(),null);
			error.setText("Try a new directory output location \n" + e.getMessage());
			System.out.println(e.getMessage());
			JOptionPane.showMessageDialog(null,error, ("Cluster error Sorry!!"), CH_DEFAULT);
			//JOptionPane.showMessageDialog(null,e.getStackTrace(), ("Cluster error Sorry!" + e.getStackTrace()), JOptionPane.ERROR_MESSAGE);			
		}		
	}
	
	public void loadOutPutDirFile()
	 {
		 JFileChooser jfc = new JFileChooser();
		 jfc.setMultiSelectionEnabled(false);
		 jfc.setCurrentDirectory(outPutDir);
		 jfc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
		 if(jfc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION)
		 {
			 outPutDir = jfc.getSelectedFile();
		 }
	 }
	
	

	@Override
	public void itemStateChanged(ItemEvent e) 
	{
		
		
	}
	
	protected JComponent makeTextPanel(String text) 
	{
        JPanel panel = new JPanel(false);
        JLabel filler = new JLabel(text);
        filler.setHorizontalAlignment(JLabel.CENTER);
        panel.setLayout(new GridLayout(1, 1));
        panel.add(filler);
        return panel;
    }
	
	private class MyProgressBarDialog extends JDialog
	{
		private static final long serialVersionUID = 1L;
		private String string;
		private JProgressBar jbar;
		private int max;
		private JButton cancel;
		public MyProgressBarDialog(String s, int max) 
		{
			super(frame,"Working...");
			this.string = s;
			this.max = max;
			init();
			this.setAlwaysOnTop(true);
			this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			this.setSize(200,100);
			this.setLocationRelativeTo(null);
			this.setModal(true);
			this.pack();
			this.setResizable(true);
		}
		public JProgressBar getProgressBar()
		{
			return this.jbar;
		}
		public JButton getCancelButton()
		{
			return this.cancel;
		}
		private void init()
		{
			try
			{
				URL imageUrl = frame.getClass().getResource("PSlogoSmall.png");
				Image logoImage = ImageIO.read(imageUrl);
				ImageIcon icon = new ImageIcon(logoImage);
				jbar = new JProgressBar(0,max);
				jbar.setPreferredSize(new Dimension(200,20));
				cancel = new JButton("Cancel");
				jbar.setString("Working");
				jbar.setStringPainted(true);
				jbar.setIndeterminate(true); 
				JLabel label = new JLabel(this.string+": ");
				JPanel center_panel = new JPanel();
				center_panel.setSize(200, 75);
				center_panel.add(new JLabel(icon));
				center_panel.add(jbar);
				JPanel bot_panel = new JPanel();
				bot_panel.setSize(200, 75);
				//bot_panel.add(cancel);
				JPanel top_panel = new JPanel();
				top_panel.add(label);
				this.getContentPane().add(top_panel,BorderLayout.NORTH);
				this.getContentPane().add(center_panel, BorderLayout.CENTER);
				this.getContentPane().add(bot_panel,BorderLayout.SOUTH);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(frame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	

	private class MyClusterWorker extends SwingWorker<Void,Void>
	{
		private JDialog jd;
		
		public MyClusterWorker(JDialog jd)
		{
			this.jd = jd;
			
		}
		@Override
		protected Void doInBackground() throws Exception 
		{
			launchAnalysis();
			return null;
		}
		
		@Override
		protected void done()
		{
			if(isCancelled())
			{
				this.jd.dispose();
				thisFrame.dispose();
				System.gc();
			}
				
			else
			{
				this.jd.dispose();
				thisFrame.dispose();
				System.gc();
				
			}
	
		}
	}
}
