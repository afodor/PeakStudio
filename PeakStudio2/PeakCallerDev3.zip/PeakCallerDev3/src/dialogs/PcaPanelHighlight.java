package dialogs;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import javax.swing.text.Document;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;

import pca.PcaFrame;




public class PcaPanelHighlight extends JDialog implements ActionListener
{

	private static final long serialVersionUID = 1L;
	private JTextPane pane;
	private List<String> names;
	private List<Color> colors;
	private PcaFrame frame;
	private JButton closeButton = new JButton("Close");
	
	public PcaPanelHighlight(List<String>names,List<Color>colors,PcaFrame frame)
	{
		super(frame,"Highlighted "+names.size()+" Points");
		this.frame = frame;
		this.names = names;
		this.colors = colors;
		init();
	}

	private void init()
	{
		this.setSize(300,275);
		this.setLocationRelativeTo(this.frame);
		this.setResizable(false);
		buildDialog();
		setTextOnPane();
		this.setVisible(true);
	}
	
	private void setTextOnPane()
	{
		StringBuffer line = new StringBuffer();
		SimpleAttributeSet set = new SimpleAttributeSet();
		Document doc = pane.getStyledDocument();
		pane.setText(null);
		
		for(int index=0; index<this.names.size(); index++)
		{
			try
			{
				pane.setCharacterAttributes(set, true);
				StyleConstants.setForeground(set, this.colors.get(index));
				line.append(index+1+"\t"+this.names.get(index)+"\n");
				
				doc.insertString(doc.getLength(), line.toString(), set);
				line.delete(0, line.length()-1);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		pane.setEditable(false);
	}

	private void buildDialog()
	{
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BorderLayout());
		mainPanel.setBackground(new Color(225,225,225));
		mainPanel.add(buildMidPanel(),BorderLayout.NORTH);
		mainPanel.add(buildBottomPanel(),BorderLayout.SOUTH);
		this.add(mainPanel,BorderLayout.CENTER);
		
	}
	private JPanel buildMidPanel()
	{
		JPanel mid = new JPanel();
		mid.setLayout(new FlowLayout());
		mid.setPreferredSize(new Dimension(300,200));
		mid.add(buildPane());
		return mid;
	}
	
	private JPanel buildPane()
	{
		JPanel selFilesPanel = new JPanel();
		selFilesPanel.setLayout(new BorderLayout());
		pane = new CustomTextPane();
		pane.setText("Files");
		pane.setPreferredSize(new Dimension(300,175));
		pane.setBackground(Color.WHITE);
		JScrollPane spFiles = new JScrollPane(pane);
		spFiles.setBackground(Color.WHITE);
		spFiles.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		spFiles.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		spFiles.setPreferredSize(new Dimension(300,175));
		selFilesPanel.add(spFiles,BorderLayout.CENTER);
		return selFilesPanel;
	}
	private JPanel buildBottomPanel()
	{
		JPanel botPanel = new JPanel();
		botPanel.setLayout(new FlowLayout());
		botPanel.setSize(200,100);
		closeButton.addActionListener(this);
		botPanel.add(closeButton);
		return botPanel;
	}
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == closeButton)
		{
			this.setVisible(false);
			this.dispose();
			System.gc();
		}
	}

}
