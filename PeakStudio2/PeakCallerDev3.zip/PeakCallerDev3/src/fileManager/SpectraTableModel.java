package fileManager;

import java.awt.Color;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import javax.swing.JOptionPane;
import javax.swing.table.AbstractTableModel;

import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;
import viewer.FsaPanel;

public class SpectraTableModel extends AbstractTableModel
{
	private static final long serialVersionUID = -3280047300684154514L;
	private static final NumberFormat nf = NumberFormat.getInstance();
	private static final int FILE_NAME = 0;
	private static final int GRAPH_COLOR = 1;
	private static final int DYE_COLOR = 2;
	private static final int SHOWGRAPH = 3;
	private static final int PEAK_COLOR = 4;
	private static final int REJECTED_PEAK_COLOR=5;
	private static final int SELECTED_PEAK_COLOR=6;
	//private static final int QC_STATUS = 7;
	private static final int NUM_PEAKS = 7;
	private static final int SPECTRA_TYPE = 8;
	private static final int SIZE_STANDARDS_NAME = 9;
	private static final int NUM_SIZE_STANDARDS = 10;
	private static final int QC_NUMBER = 11;
	private static final int BASE_PAIRS_CALLED = 12;
	private static final int DATA_CHANNEL = 13;
	private static final int SMOOTHED = 14;
	// if you add to this list, be sure to update all code that marks
	// the start of metadata space by searching for the location of
	// BASE_PAIRS_CALLED in the array
	public static final String FILE_NAME_STRING = "File Name";
	public static final String GRAPH_COLOR_STRING = "Graph Color";
	public static final String DATA_CHANNEL_STRING = "Data Channel";
	public static final String SHOW_GRAPH_STRING = "Show Graph";
	public static final String PEAK_COLOR_STRING = "Peak Color";
	public static final String REJECTED_PEAK_COLOR_STRING = "Rejected Peak Color";
	public static final String SELECTED_PEAK_COLOR_STRING = "Selected Peak Color";
	public static final String QC_STAUS_STRING = null;//"QC Status";
	public static final String NUM_PEAKS_STRING = "NumPeaks";
	public static final String SPECTRA_TYPE_STRING = "Spectra Type";
	public static final String SIZE_STANDARDS_NAME_STRING = "Standards File";
	public static final String NUM_SIZE_STANDARDS_STRING = "Num Size Standard Peaks";
	public static final String QC_NUMBER_STRING = "QC Number";
	public static final String BASE_PAIRS_CALLED_STRING = "Base Pairs Called";
	public static final String DYE_COLOR_STRING = "Dye Color";
	public static final String SMOOTHED_STRING = "Smoothed";
	private FsaPanel parentPanel;
	
	private String[] cols = new String[]
	{ FILE_NAME_STRING, GRAPH_COLOR_STRING, DYE_COLOR_STRING,
			SHOW_GRAPH_STRING, PEAK_COLOR_STRING, REJECTED_PEAK_COLOR_STRING,
			SELECTED_PEAK_COLOR_STRING,
			NUM_PEAKS_STRING, SPECTRA_TYPE_STRING, SIZE_STANDARDS_NAME_STRING,
			NUM_SIZE_STANDARDS_STRING, QC_NUMBER_STRING,
			BASE_PAIRS_CALLED_STRING,DATA_CHANNEL_STRING,SMOOTHED_STRING };
	
	private final static Color[] COLORS = 
	{Color.BLACK,Color.RED,Color.GREEN,Color.BLUE,Color.MAGENTA,Color.ORANGE,Color.CYAN,Color.GRAY,Color.YELLOW,Color.PINK,Color.LIGHT_GRAY,Color.DARK_GRAY};
	

	private boolean[] visible =
	{ true, false, true, true, true, true, false, true, true, false, false, true,
			false,false,false};

	public boolean isMetaDataColumn(int aCol)
	{
		if( aCol < 0 )
			return false;
		
		aCol = getModelNumber(aCol);
		
		if( aCol > BASE_PAIRS_CALLED) // metadata space
			return true;
		
		return false;
	}
	
	public void renameAColumn(String newName, String oldName)
	{
		if( newName.equals(oldName))
			return;
		
		for( String s : cols )
			if( newName.equals(s) )
			{
				JOptionPane.showMessageDialog(parentPanel, 
						newName + " already exists as a metadata name");
				return;
			}
		
		int index = -1;
		
		for(int x=0; x < cols.length; x++)
			if( oldName.equals(cols[x]) )
				index = x;
		
		if( index == -1)
		{
			JOptionPane.showMessageDialog(parentPanel, 
					"Error: Could not find " + oldName, "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
		cols[index] = newName;
		
		for( Spectra s : parentPanel.getParentFrame().getSpectraList())
		{
			String val = s.getMetadataMap().remove(oldName);
			
			if( val != null)
				s.getMetadataMap().put(newName, val);
			
		}
			
		fireTableStructureChanged();
		fireTableDataChanged();
	}
	
	
	
	/*
	 * Not thread safe
	 */
	public void removeAColumn(String columnName)
	{
		int userResponse = 
		JOptionPane.showConfirmDialog(parentPanel, "Really remove metadata for " + columnName 
				+"?\n" + 
				"This operation cannot be undone", "Confirm delete metadata", 
				JOptionPane.YES_NO_OPTION);
		
		if( userResponse != JOptionPane.YES_OPTION)
			return;
		
		int columnNum = -1;
		
		for( int x=0;x < cols.length; x++)
			if( columnName.equals(cols[x]) )
				columnNum = x;
		
		if( columnNum == -1)
		{
			JOptionPane.showMessageDialog(parentPanel, "Could not delete " + columnName);
			return;
		}
		
		String[] newCols = new String[cols.length -1];
		boolean[] newVisible = new boolean[visible.length-1];
		int index = 0;
		
		for( int x=0; x < cols.length; x++)
		{
			if( x != columnNum )
			{
				newCols[index] = cols[x];
				newVisible[index] = visible[x];
				index++;
			}
		}
		
		cols = newCols;
		visible = newVisible;
		
		for( Spectra s : parentPanel.getParentFrame().getSpectraList())
			s.getMetadataMap().remove(columnName);
		
		fireTableStructureChanged();
		fireTableDataChanged();
	}
	
	private String getUniqueName(String inString)
	{
		boolean foundIt = false;

		for (String s : cols)
			if (s.equals(inString))
				foundIt = true;

		if (!foundIt)
			return inString;

		foundIt = false;
		int index = 2;

		while (true)
		{
			String newString = inString + index;

			for (String s : cols)
				if (newString.equals(s))
					foundIt = true;

			if (!foundIt)
				return newString;

			foundIt = false;
			index++;
		}
	}

	public void ensureMetaNamesComplete()
	{
		HashSet<String> metadataNames = new HashSet<String>();
		
		for(Spectra s : parentPanel.getParentFrame().getSpectraList())
		{
			metadataNames.addAll(s.getMetadataMap().keySet());
		}
		
		List<String> names = new ArrayList<String>(metadataNames);
		Collections.sort(names);
		HashSet<String> oldNames = getColumnNamesAsSet();
		for( String s : names)
			if( ! oldNames.contains(s) )
				addAColumn(s, true);
		
		fireTableStructureChanged();
	}
	
	/*
	 * Not thread safe
	 */
	public void addAColumn(String columnName, boolean isVisible)
	{

		columnName = getUniqueName(columnName);
		String[] newCols = new String[cols.length + 1];
		boolean[] newVisible = new boolean[cols.length + 1];

		for (int x = 0; x < cols.length; x++)
		{
			newCols[x] = cols[x];
			newVisible[x] = visible[x];
		}

		newCols[cols.length] = columnName;
		newVisible[cols.length] = isVisible;

		cols = newCols;
		visible = newVisible;
		fireTableStructureChanged();
	}

	
	public SpectraTableModel(FsaPanel parentPanel)
	{
		this.parentPanel = parentPanel;
		nf.setMinimumFractionDigits(2);
	}
	
	/*
	 * Not thread safe
	 */
	public HashSet<String> getColumnNamesAsSet()
	{
		HashSet<String> set = new HashSet<String>();
		
		for( String s : cols)
			set.add(s);
		
		return set;
	}

	public String[] getColumnNames()
	{
		String[] copy = new String[cols.length];

		for (int x = 0; x < cols.length; x++)
			copy[x] = cols[x];

		return copy;
	}

	public int getNumberOfUnderlyingColumns()
	{
		return visible.length;
	}

	public boolean getColumnIsVisible(int underlyingColumnNumber)
	{
		return visible[underlyingColumnNumber];
	}

	public void setColumnIsVisible(boolean b, int underlyingColumnNumber)
	{
		visible[underlyingColumnNumber] = b;
		fireTableStructureChanged();
	}

	public int getColumnCount()
	{
		int n = 0;

		for (int x = 0; x < visible.length; x++)
			if (visible[x])
				n++;

		return n;
	}

	protected int getModelNumber(int col)
	{
		// System.out.println("Searching for " + col);
		int numToFind = col;

		for (int x = 0; x < visible.length; x++)
		{
			if (visible[x])
				numToFind--;

			if (numToFind < 0)
				return x;
		}

		throw new RuntimeException("Logic error");
	}

	public String getColumnName(int col)
	{
		return cols[getModelNumber(col)];
	}

	public int getRowCount()
	{
		int returnNum = 0;

		for (Spectra s : parentPanel.getParentFrame().getSpectraList())
			if (s.isVisibleInTable())
				returnNum++;

		return returnNum;
	}

	public int getSpectraRowNumber(int row)
	{
		int numToFind = row;

		List<Spectra> spectraList = parentPanel.getParentFrame()
				.getSpectraList();
		for (int x = 0; x < spectraList.size(); x++)
		{
			if (spectraList.get(x).isVisibleInTable())
				numToFind--;

			if (numToFind < 0)
				return x;
		}

		throw new RuntimeException("Logic error");
	}
	
	@Override
	public Class<?> getColumnClass(int c)
	{
		return getValueAt(0, c).getClass();
	}

	public Object getValueAt(int row, int col)
	{
		col = getModelNumber(col);
		row = getSpectraRowNumber(row);

		try
		{
			Spectra s = (Spectra) parentPanel.getParentFrame().getSpectraList()
					.get(row);

			switch (col)
			{
			case FILE_NAME:
				return s.getName();
			case GRAPH_COLOR:
				return s.getGraphColor();
			case DATA_CHANNEL:
				return s.getDataChannel();
			case PEAK_COLOR:
				return s.getPeakColor();
			case SHOWGRAPH:
				return s.graphIsShown();
			//case QC_STATUS:
			//	return s.getQcStatus();
			case NUM_PEAKS:
				return s.getLastGeneratedPeakSet().size();
			case REJECTED_PEAK_COLOR:
				return s.getPossiblePeakColor();
			case SELECTED_PEAK_COLOR:
				return s.getSelectedPeakColor();
			case SPECTRA_TYPE:
				if (s.getIsStandard())
					return "Standard";
				else
					return "Data";

			case SIZE_STANDARDS_NAME:
				String name = "NA";

				AbstractFSAFileDescriptor fsa = s.getFileDescriptor();

				if (fsa != null)
				{
					String aName = fsa.getSizeStandardsName();

					if (aName != null)
						name = aName;
				}

				return name;

			case NUM_SIZE_STANDARDS:
				int returnVal = 0;

				AbstractFSAFileDescriptor anFsa = s.getFileDescriptor();

				if (anFsa != null)
				{
					List<Short> aList = anFsa.getSizeStandards();

					if (aList != null)
						returnVal = aList.size();
				}

				return returnVal;

			case QC_NUMBER:
				String qcString = "NA";

				AbstractFSAFileDescriptor myFsa = s.getFileDescriptor();

				if (myFsa != null)
				{
					Float qcNum = myFsa.getStandardsPeakQANumber();

					if (qcNum != null)
						qcString = nf.format(qcNum);
				}

				return qcString;

			case BASE_PAIRS_CALLED:
				AbstractFSAFileDescriptor yetAnotherFsa = s.getFileDescriptor();

				if (yetAnotherFsa == null
						|| yetAnotherFsa.getLastSetOfBasePairCalls() == null)
					return "no";

				return "yes";

			case DYE_COLOR:
				return s.getDyeColor();
				
			case SMOOTHED:
				return (s.getIsSmoothed() ? "YES" :"NO");
			default:
				String val = s.getMetadataMap().get(cols[col]);
				if (val != null)
					return val;
				else
					return "";

			}
		} catch (Exception x)
		{
			System.out.println("Catch / Not working");
			x.printStackTrace();
			JOptionPane.showMessageDialog(parentPanel, "Unexpected error", "Error",
					JOptionPane.ERROR);
			return null;
		}

	}

	public void setPeakColorsByMetadata(String columnName)
	{
		HashMap<String, Color> colorMap = new HashMap<String, Color>();
		int colorIndex =0;
		
		for( Spectra s : parentPanel.getParentFrame().getSpectraList() )
		{
			String val = s.getMetadataMap().get(columnName);
			if( val != null && val.trim().length() > 0)
			{
				Color c = colorMap.get(val);
				
				if( c== null)
				{
					c = COLORS[colorIndex];
					colorMap.put(val, c);
					colorIndex++;
					
					if( colorIndex == COLORS.length )
						colorIndex = 0;
				}
				
				s.setPeakColor(c);
			}
		}
		
		fireTableDataChanged();
		parentPanel.forceRedraw();
	}
	
	public void setValueAt(Object value, int row, int col)
	{
		col = getModelNumber(col);
		row = getSpectraRowNumber(row);

		try
		{

			Spectra s = (Spectra) parentPanel.getParentFrame().getSpectraList()
					.get(row);
			if (col == GRAPH_COLOR)
			{
				s.setGraphColor((Color) value);

			} else if (col == PEAK_COLOR)
			{
				s.setPeakColor((Color) value);
			} else if (col == SHOWGRAPH)
			{
				s.setGraphIsShown((Boolean) value);
			}
			else if ( col == REJECTED_PEAK_COLOR)
			{
				s.setPossiblePeakColor((Color) value);
			}
			else if (col == SELECTED_PEAK_COLOR)
			{
				s.setSelectedPeakColor((Color) value);
			}
			else if ( col > BASE_PAIRS_CALLED) // metadata space
			{
				String stringVal = (String) value;
				
				if( stringVal.trim().length() == 0 )
					s.getMetadataMap().remove(cols[col]);
				else
					s.getMetadataMap().put(cols[col], (String)value);
				
				// automatically propogate edits through all spectra associated with this spectra
				// todo:  allow a user to turn this off
				String fsaName = s.getFileDescriptor().getFileNamePrefix();
				
				for( Spectra sp : parentPanel.getParentFrame().getSpectraList() )
					if( sp != s)
						if( sp.getFileDescriptor().getFileNamePrefix().equals(fsaName) )
						{
							if( stringVal.trim().length() == 0 )
								sp.getMetadataMap().remove(cols[col]);
							else
								sp.getMetadataMap().put(cols[col], (String)value);
						}
			}

			fireTableDataChanged();
			fireTableCellUpdated(row, col);

			parentPanel.forceRedraw();
		} catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	public boolean isCellEditable(int row, int col)
	{

		col = getModelNumber(col);
		String name = cols[col];
		if (name.equals(GRAPH_COLOR_STRING) || name.equals(SHOW_GRAPH_STRING)
				|| name.equals(PEAK_COLOR_STRING) || name.equals(REJECTED_PEAK_COLOR_STRING)
				 || name.equals(SELECTED_PEAK_COLOR_STRING))
			return true;

		if( col > BASE_PAIRS_CALLED) // metadata space
			return true;
		return false;
	}

	// DEBUG *****************************************
	private void printDebugData()
	{
		int numRows = getRowCount();
		int numCols = getColumnCount();

		for (int i = 0; i < numRows; i++)
		{
			System.out.print("    row " + i + ":");
			for (int j = 0; j < numCols; j++)
			{
				System.out.print("  " + getValueAt(i, j));
			}
			System.out.println();
		}
		System.out.println("--------------------------");
	}
	// ************************************************

}
