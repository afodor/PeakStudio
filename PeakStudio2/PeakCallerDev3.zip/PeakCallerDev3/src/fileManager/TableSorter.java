package fileManager;

import javax.swing.table.TableModel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.swing.JTable;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumnModel;
import viewer.FsaFrame;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;

public class TableSorter 
{
    
    boolean ascending = true;
    private SpectraTableModel fileManger;
    private SpectraJTable tableView;
    private TableColumnModel columnModel;
    private final FsaFrame parentArisaFrame;
    
    public TableSorter(TableModel model, FsaFrame parent)
    {
    	fileManger = (SpectraTableModel) model;
    	this.parentArisaFrame = parent;
    }
    public void addMouseListenerToHeaderInTable(JTable table)
    { 
    	tableView = (SpectraJTable)table;
        tableView.setColumnSelectionAllowed(true); 
        JTableHeader th = tableView.getTableHeader(); 
        th.addMouseListener(new ListMouseListener()); 
        columnModel = tableView.getColumnModel();
    }
   
    public void colSort(int colNum)
    {
    	Collections.sort(parentArisaFrame.getSpectraList(), new ColSorter(ascending,colNum));
    	fileManger.fireTableDataChanged();
    	checkDirection();
    }
    public void checkDirection()
    {
    	if(ascending)
    		ascending = false;
    	else
    		ascending = true;
    }
    
    private class ListMouseListener implements MouseListener, MouseMotionListener
    {
    	
    	int colNum;
    	public ListMouseListener() 
    	{
			columnModel = tableView.getColumnModel();
		}
		public void mouseClicked(MouseEvent e)
		{
            colNum = columnModel.getColumnIndexAtX(e.getX()); 
            colNum = tableView.convertColumnIndexToModel(colNum);
            colSort(colNum);
		}
		public void mouseEntered(MouseEvent e) {}
		public void mouseExited(MouseEvent e) {}
		public void mousePressed(MouseEvent e) {	}
		public void mouseReleased(MouseEvent e) {	}
		public void mouseDragged(MouseEvent e){	}
		public void mouseMoved(MouseEvent e) {}
    	
    }
    
    public class ColSorter implements Comparator<Spectra>
    {
    	    boolean direction;
            int col;
            public ColSorter(boolean direction, int col)
            {
            	this.direction = direction;
            	this.col = col;
            }
            
    		public int compare(Spectra a , Spectra b)
    		{	
    			if (a == null && b == null) 
    			{
    				return 0;
    			} 
    			else if (a == null) 
    			{
    				return 1;
    			} 
    			else if (b == null)
    			{
    				return -1;
    			 } 
    			 else if(fileManger.getColumnName(col).equals( fileManger.FILE_NAME_STRING  ))
    			 {
    				 String titleA = a.getName();
    			     String titleB = b.getName();
    			     if(direction)
    			    	 return titleA.compareTo(titleB);
        			 else
        				 return titleB.compareTo(titleA);	
    			    }
    			 else if(fileManger.getColumnName(col).equals(fileManger.SMOOTHED_STRING))
    			 {
    				 
    				 if(direction)
    					 return (Boolean.toString(a.getIsSmoothed()).compareTo((Boolean.toString(b.getIsSmoothed()))));
    				 else
    					 return (Boolean.toString(b.getIsSmoothed()).compareTo((Boolean.toString(a.getIsSmoothed()))));
    			 }
    			    else if(fileManger.getColumnName(col).equals(fileManger.QC_STAUS_STRING ))
    			    {
    			    	String titleA = a.getQcStatus();
    			    	String titleB = b.getQcStatus();
    			    	if(direction)
    			    		return titleA.compareTo(titleB);
        			    else
        			    	return titleB.compareTo(titleA);	
    			    }
    			    else if(fileManger.getColumnName(col).equals(fileManger.DYE_COLOR_STRING))
    			    {
    			    	String dyeA = a.getDyeColor();
    			    	String dyeB = b.getDyeColor();
    			    	if(direction)
    			    		return dyeA.compareTo(dyeB);
    			    	else
    			    		return dyeB.compareTo(dyeA);
    			    }
    			    else if(fileManger.getColumnName(col).equals(fileManger.GRAPH_COLOR_STRING))
    			    {
    			    	if(direction)
    			    		return a.getGraphColor().toString().compareTo(b.getGraphColor().toString());
    			        else
    			        	return b.getGraphColor().toString().compareTo(a.getGraphColor().toString());
    			    }
    			    else if(fileManger.getColumnName(col).equals(fileManger.PEAK_COLOR_STRING))
    			    {
    			    	if(direction)
    			    		return a.getPeakColor().toString().compareTo(b.getPeakColor().toString());
    			        else
    			        	return b.getPeakColor().toString().compareTo(a.getPeakColor().toString());
    			    }
    			    else if(fileManger.getColumnName(col).equals(fileManger.SHOW_GRAPH_STRING))
    			    {
    			    	if(direction)
    			    		return  (Boolean.toString(a.graphIsShown()).compareTo(Boolean.toString(b.graphIsShown())));
    			        else
    			        	return (Boolean.toString(b.graphIsShown()).compareTo(Boolean.toString(a.graphIsShown())));
    		        }
    			    else if(fileManger.getColumnName(col).equals(fileManger.DATA_CHANNEL_STRING))
    			    {
			    		if(direction)
			    		{
			    			return Float.compare(a.getDataChannel(), b.getDataChannel());
			    		}
			    		else
			    		{
			    			return Float.compare(b.getDataChannel(), a.getDataChannel());
			    		}	
    			      }
    			      else if( fileManger.getColumnName(col).equals(fileManger.NUM_PEAKS_STRING))
    			      {
    			    	  if( direction)
    			    	  {
    			    		  return Float.compare(a.getLastGeneratedPeakSet().size(), 
    			    				  b.getLastGeneratedPeakSet().size());
    			    	  }
    			    	  else
    			    	  {
    			    		  return Float.compare(b.getLastGeneratedPeakSet().size(), 
    			    				  a.getLastGeneratedPeakSet().size());
    			    	  }
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.SPECTRA_TYPE_STRING))
    			      {
    			    	  if( direction)
    			    	  {
    			    		  return new Boolean( a.getIsStandard()).toString().compareTo(
    			    				  new Boolean( b.getIsStandard()).toString());
    			    	  }
    			    	  else
    			    	  {
    			    		  return new Boolean( b.getIsStandard()).toString().compareTo(
    			    				  new Boolean( a.getIsStandard()).toString());
    			    	  }
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.REJECTED_PEAK_COLOR_STRING) ) 
    			      {
    			    	  if(direction)
      			    		return a.getPossiblePeakColor().toString().compareTo(b.getPossiblePeakColor().toString());
      			        else
      			        	return b.getPossiblePeakColor().toString().compareTo(a.getPossiblePeakColor().toString());
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.SELECTED_PEAK_COLOR_STRING) ) 
    			      {
    			    	  if(direction)
      			    		return a.getSelectedPeakColor().toString().compareTo(b.getSelectedPeakColor().toString());
      			        else
      			        	return b.getSelectedPeakColor().toString().compareTo(a.getSelectedPeakColor().toString());
    			      }

    			      else if ( fileManger.getColumnName(col).equals(fileManger.SIZE_STANDARDS_NAME_STRING))
    			      {
    			    	  String aString = null;
    			    	  String bString = null;
    			    	  
    			    	  AbstractFSAFileDescriptor aFsa= a.getFileDescriptor();
    						
    			    	  if( aFsa!= null)
    			    	  {
    							String aName = aFsa.getSizeStandardsName();
    							
    							if( aName != null)
    								aString= aName;
    					  }
    			    	  

    			    	  AbstractFSAFileDescriptor bFsa= b.getFileDescriptor();
    						
    			    	  if( bFsa!= null)
    			    	  {
    							String bName = bFsa.getSizeStandardsName();
    							
    							if( bName != null)
    								aString= bName;
    					  }
    			    	  
    			    	  if (aString == null && bString == null) 
    		    			{
    		    				return 0;
    		    			} 
    		    			else if (aString == null) 
    		    			{
    		    				return direction ? 1 : 0;
    		    			} 
    		    			else if (bString == null)
    		    			{
    		    				return direction ? 0 : 1;
    		    			}
    		    			else if( direction)
    		    			{
    		    				return aString.compareTo(bString);
    		    			}
    		    			else
    		    			{
    		    				return bString.compareTo(aString);
    		    			}
    						
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.NUM_SIZE_STANDARDS_STRING))
    			      {
    			    	  int aNum = 0;
    			    	  int bNum = 0;
    			    	  
    			    	  AbstractFSAFileDescriptor aFsa= a.getFileDescriptor();
    						
    			    	  if( aFsa!= null)
    			    	  {
    							List<Short> aList = aFsa.getSizeStandards();
    			    		  
    							if( aList != null)
    								aNum = aList.size();
    					  }
    			    	  

    			    	  AbstractFSAFileDescriptor bFsa= b.getFileDescriptor();
    						
    			    	  if( bFsa!= null)
    			    	  {
    			    		  List<Short> bList = bFsa.getSizeStandards();
    			    		  
    			    		  if( bList != null)
    			    			  bNum = bList.size();
    					  }
    			    	  
    			    	  if( direction)
    		    		  {
    		    				return Float.compare(aNum, bNum);
    		    		  }
    		    			else
    		    			{
    		    				return Float.compare(bNum, aNum);
    		    			}
    						
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.QC_NUMBER_STRING))
    			      {
    			    	  try
    			    	  {
        			    	  float aNum =0;
        			    	  float bNum =0;
        			    	  
        			    	  AbstractFSAFileDescriptor aFsa= a.getFileDescriptor();
      						
        			    	  if( aFsa!= null)
        			    	  {
        			    		 Float qcNum = aFsa.getStandardsPeakQANumber();
        			    		 
        			    		 if( qcNum != null)
        			    			 aNum = qcNum;
        			    	  }
        			    	  
        			    	  AbstractFSAFileDescriptor bFsa= b.getFileDescriptor();
        						
        			    	  if( bFsa!= null)
        			    	  {
        			    		 Float qcNum = bFsa.getStandardsPeakQANumber();
        			    		 
        			    		 if( qcNum != null)
        			    			 bNum = qcNum;
        			    	  }
        			    	  
        			    	  if( direction)
        			    		  return Float.compare(aNum, bNum);
        			    	  else
        			    		  return Float.compare(bNum, aNum);
        			    	  
    			    	  }
    			    	  catch(Exception e)
    			    	  {
    			    		  System.out.println("Failed to sort!!");
    			    		  e.printStackTrace();
    			    		  return 0;
    			    	  }
    			      }
    			      else if ( fileManger.getColumnName(col).equals(fileManger.BASE_PAIRS_CALLED_STRING) )
			    	  {
    			    	  String aString = "no";
    			    	  String bString = "no";
    			    	  AbstractFSAFileDescriptor aFsa= a.getFileDescriptor();
    			    	  AbstractFSAFileDescriptor bFsa = b.getFileDescriptor();
    			    	  
    			    	  if( aFsa != null && aFsa.getLastSetOfBasePairCalls() != null)
    			    		  aString = "yes";
    			    	  
    			    	  if( bFsa != null && bFsa.getLastSetOfBasePairCalls() != null )
    			    		  bString = "yes";
    			    	  
    			    	  if( direction)
    			    		  return aString.compareTo(bString);
    			    	  else
    			    		  return bString.compareTo(aString);
			    	  }
    			      else 
    			      {
    			    	  String colName = fileManger.getColumnName(col);
    			    	  
    			    	  String aString = a.getMetadataMap().get(colName);
    			    	  if( aString== null) 
    			    		  aString = "";
    			    	  
    			    	  String bString = b.getMetadataMap().get(colName);
    			    	  
    			    	  if( bString == null)
    			    		  bString = "";
    			    	  
    			    	  if( direction)
    			    		  return aString.compareTo(bString);
    			    	  else
    			    		  return bString.compareTo(aString);
    			      }
    		}
    		
    }

}
