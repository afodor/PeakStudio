package fileManager;

import java.awt.Color;
import java.awt.Component;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableCellRenderer;

import experimentSets.Spectra;

import viewer.FsaFrame;

public class SpectraJTable extends JTable
{
	private static class MyJChecboxMenuItem extends JCheckBoxMenuItem
	{
		
		private static final long serialVersionUID = 2975970642359545910L;
		int index;

		private MyJChecboxMenuItem(String name, int index)
		{
			super(name);
			this.index = index;
		}
	}

	private static final long serialVersionUID = 1L;
	private JPopupMenu popUpMenu = new JPopupMenu();
	private JMenuItem selectAll = new JMenuItem("Select All");
	private JMenuItem unSelect = new JMenuItem("Unselect All");
	private JMenu showColumns = new JMenu("Show Columns");
	private JMenu spectra = new JMenu("Spectra");
	private JMenu selecter = new JMenu("Show");
	JMenuItem deleteColumn = new JMenuItem("Delete");
	JMenuItem renameColumn = new JMenuItem("Rename");
	JMenuItem colorBy = new JMenuItem("Color by");
	private FsaFrame frame;
	private boolean filesAreOpen = false;
	private Color whiteColor = Color.WHITE;
	private Color alternateColor = Color.LIGHT_GRAY;
	private Color selectedColor = new Color(61, 128, 223);
	private Color emptyTableColor = new Color(233, 233, 233);
	private final SpectraTableModel model;
	private int currentColNum = -1;
	private final int MAX_SPECTRA_AUTO_SELECTION = 40;
	
	// todo: These should really be generated dynamically!
	private static final MyJChecboxMenuItem[] SPECTRA_FILTERS =
	{ new MyJChecboxMenuItem("Blue", 1), new MyJChecboxMenuItem("Green", 2),
			new MyJChecboxMenuItem("Yellow", 3), new MyJChecboxMenuItem("Red", 4),
			new MyJChecboxMenuItem("Orange", 105) };

	public SpectraTableModel getModel()
	{
		return model;
	}
	
	public class ASelectionListener implements ListSelectionListener
	{
		public void valueChanged(ListSelectionEvent e)
		{
			if (e.getFirstIndex() == -1 || e.getLastIndex() == -1)
				frame.setSelectionSensitiveMenuItemsEnabled(false);
			else
				frame.setSelectionSensitiveMenuItemsEnabled(true);
			

			frame.getFsaPanel().forceRedraw();
		}
	}

	public void initializeTable()
	{
		addMouseListener(new MouseMotionHandler());

		getSelectionModel().addListSelectionListener(new ASelectionListener());

		selectAll.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				for (Spectra s : frame.getSpectraList())
					if (s.isVisibleInTable())
						s.setGraphIsShown(true);

				model.fireTableDataChanged();
				frame.getFsaPanel().forceRedraw();

			}
		});

		unSelect.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				for (Spectra s : frame.getSpectraList())
					if (s.isVisibleInTable())
						s.setGraphIsShown(false);

				model.fireTableDataChanged();
				frame.getFsaPanel().forceRedraw();
			}
		});

		/**************************************************
		 * Removed select all spectra option, could crash program
		 * if many spectra are all displayed at once.
		 * can always add it back in at any time.
		 **************************************************/
		//selecter.add(selectAll);
		selecter.add(unSelect);
		spectra.setEnabled(false);
		popUpMenu.addSeparator();
		popUpMenu.add(spectra);
		popUpMenu.addSeparator();
		popUpMenu.add(selecter);

		popUpMenu.add(showColumns);
		popUpMenu.addSeparator();

		JMenuItem newColumn = new JMenuItem("Add A Column");
		newColumn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				model.addAColumn("New Column", true);
			}
		});
		popUpMenu.add(newColumn);

		popUpMenu.addSeparator();
		
		deleteColumn = new JMenuItem("Delete ");
		deleteColumn.setEnabled(false);
		
		deleteColumn.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if( currentColNum != -1 )
				{	
					String name = model.getColumnName(currentColNum);
					model.removeAColumn(name);
				}
			}
		});
		
		renameColumn = new JMenuItem("Rename ");
		renameColumn.setEnabled(false);
		
		renameColumn.addActionListener( new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(currentColNum == -1)
					return;
				
				String oldName = model.getColumnName(currentColNum);
				String newName = JOptionPane.showInputDialog("Please enter new name", 
								oldName);
						
				if( newName != null && newName.trim().length() > 0 ) 
				{
							model.renameAColumn(newName, oldName);
				}
			}
		});
		
		colorBy = new JMenuItem("Color by");
		colorBy.setEnabled(false);
		
		colorBy.addActionListener( new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if( currentColNum == -1)
					return;
				
				String name= model.getColumnName(currentColNum);
				model.setPeakColorsByMetadata(name);
			}
		});
		
		popUpMenu.add(deleteColumn);
		popUpMenu.add(renameColumn);
		popUpMenu.add(colorBy);
		
		popUpMenu.addSeparator();

		for (final MyJChecboxMenuItem myJ : SPECTRA_FILTERS)
		{
			myJ.setSelected(true);

			myJ.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					for (Spectra s : frame.getSpectraList())
						if (myJ.index == s.getDataChannel())
							s.setIsVisibleInTable(myJ.isSelected());

					model.fireTableDataChanged();
					frame.setDirty(true);
					frame.fsaPanel.forceRedraw();
				}
			});

			spectra.add(myJ);
		}
		
		// make the table share key strokes with the rest of the application
		// on windows it is not doing this by itself.
		// todo:  Test on Mac
		addKeyListener( new KeyAdapter(){
			@Override
			public void keyTyped(KeyEvent e)
			{
				frame.handleKeyType(e);
			}
			
			@Override
			public void keyPressed(KeyEvent e)
			{
				frame.getFsaPanel().handleKeyPressed(e);
			}
		});
		
	}

	public SpectraJTable(FsaFrame frame, final SpectraTableModel model)
	{
		this.model = model;
		this.frame = frame;
	}

	public void paint(Graphics g)
	{
		super.paint(g);
		paintEmptyRows(g);

	}

	private void paintEmptyRows(Graphics g)
	{
		final int rowCount = getRowCount();
		final Rectangle tableBounds = g.getClipBounds();

		if (rowCount * this.rowHeight < tableBounds.height)
		{
			for (int i = rowCount; i <= tableBounds.height / this.rowHeight; ++i)
			{
				g.setColor(getRowColor(i));
				g.fillRect(tableBounds.x, i * this.rowHeight,
						tableBounds.width, this.rowHeight);
			}
		}
	}

	private Color getRowColor(int row)
	{
		return (row % 2 == 0) ? emptyTableColor : whiteColor;
	}

	public boolean getScrollableTracksViewportHeight()
	{
		if (getParent() instanceof JViewport)
		{
			JViewport parent = (JViewport) getParent();
			return (parent.getHeight() > getPreferredSize().height);
		}
		return false;
	}

	public Component prepareRenderer(TableCellRenderer renderer, int row,
			int col)
	{
		int modelCol = convertColumnIndexToModel(col);
		Component c = super.prepareRenderer(renderer, row, col);
		if (row % 2 == 0 && !isCellSelected(row, col)
				&& getModel().getColumnClass(modelCol) != Color.class)
		{
			c.setBackground(alternateColor);
		} else if (model.getValueAt(row, modelCol) instanceof Color)
		{
			c.setBackground((Color) getModel().getValueAt(row, modelCol));
		} else
		{
			c.setBackground(whiteColor);
		}
		if (isCellSelected(row, col)
				&& getModel().getColumnClass(modelCol) != Color.class)
		{
			c.setBackground(selectedColor);

		}
		return c;
	}

	public void setFilesOpen(boolean x)
	{
		filesAreOpen = x;
		checkOpenFiles();
	}

	private void checkOpenFiles()
	{
		if (!filesAreOpen)
		{
			spectra.setEnabled(false);
		} else
		{
			spectra.setEnabled(true);
		}
	}

	

	private class MouseMotionHandler implements MouseListener
	{

		public void mousePressed(MouseEvent e)
		{

			showPopUp(e);
		}

		public void mouseReleased(MouseEvent e)
		{

			showPopUp(e); // for windows
		}

		private void showPopUp(MouseEvent e)
		{
			if (e.isPopupTrigger())
			{
				if(model.getRowCount() > MAX_SPECTRA_AUTO_SELECTION)
					selectAll.setEnabled(false);
				else
					selectAll.setEnabled(true);
				String[] colNames = model.getColumnNames();
				showColumns.removeAll();
				for (int x = 0; x < model.getNumberOfUnderlyingColumns(); x++)
				{
					final MyJChecboxMenuItem anItem = new MyJChecboxMenuItem(
							colNames[x], x);
					anItem.setSelected(model.getColumnIsVisible(x));
					showColumns.add(anItem);

					anItem.addActionListener(new ActionListener()
					{
						public void actionPerformed(ActionEvent e)
						{
							model.setColumnIsVisible(anItem.isSelected(),
									anItem.index);
						}
					});
				}
				
				
					
				popUpMenu.show(e.getComponent(), e.getX(), e.getY());
				popUpMenu.setVisible(true);
			}
		}

		public void mouseClicked(MouseEvent e)
		{
		}

		public void mouseEntered(MouseEvent e)
		{
			setMetadataMenuStuff(e);
		}

		public void mouseExited(MouseEvent e)
		{
			setMetadataMenuStuff(e);
		}
	}
	
	private void setMetadataMenuStuff(MouseEvent e)
	{
		int colNum = columnModel.getColumnIndexAtX(e.getX()); 
        colNum = convertColumnIndexToModel(colNum);
        if( model.isMetaDataColumn(colNum))
		{
			deleteColumn.setText("Delete " + model.getColumnName(colNum));
			deleteColumn.setEnabled(true);
			renameColumn.setText("Rename " + model.getColumnName(colNum));
			renameColumn.setEnabled(true);
			colorBy.setText("Color by " +  model.getColumnName(colNum));
			colorBy.setEnabled(true);
			currentColNum = colNum;
		}
		else
		{
			deleteColumn.setText("Delete");
			deleteColumn.setEnabled(false);
			renameColumn.setText("Rename");
			renameColumn.setEnabled(false);
			colorBy.setText("Color by");
			colorBy.setEnabled(false);
			currentColNum = -1;
		}
	}

	// call when no threads are manipulating the data
	public void dataComplete()
	{
		// total hack - will break if the data channels are not {1,2,3,4,105}
		boolean[] hackedBool = new boolean[5];

		for (int x = 0; x < hackedBool.length; x++)
			hackedBool[x] = false;

		for (Spectra s : frame.getSpectraList())
		{
			int index = -1;

			if (s.getDataChannel() == 105)
				index = 4;
			else
				index = s.getDataChannel() - 1;

			if (index >= 0 && index <= 4)
				hackedBool[index] = true;
		}

		for (int x = 0; x < hackedBool.length; x++)
		{
			if (hackedBool[x])
			{
				SPECTRA_FILTERS[x].setEnabled(true);
				SPECTRA_FILTERS[x].setSelected(true);
				/*
				if (SPECTRA_FILTERS[x].isSelected())
					SPECTRA_FILTERS[x].setSelected(false);

				if (SPECTRA_FILTERS[x].isEnabled())
					SPECTRA_FILTERS[x].setEnabled(false); */
				
			}
			else
			{
				SPECTRA_FILTERS[x].setEnabled(false);
				SPECTRA_FILTERS[x].setSelected(false);
				
			}
		}
	}
}
