package progressBarDemo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRootPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;

public class ADemo
{
	public static void main(String[] args) throws Exception
	{
		JFrame frame = new JFrame();
		JPanel panel = new JPanel();
		panel.setBackground(Color.BLACK);
		panel.setSize(1000, 600);
		frame.add(panel);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(true);
		frame.setSize(1000, 600);
		frame.setLocationRelativeTo(null);
		frame.setBackground(Color.WHITE);
		frame.pack();
		frame.setVisible(true);
		JProgressBar jbar = new JProgressBar(0,243);
		jbar.setPreferredSize(new Dimension(175,20));
		JButton cancel = new JButton("Cancel");
		jbar.setString("Working");
		jbar.setStringPainted(true);
		jbar.setValue(0); 
		JLabel label = new JLabel("Progress: ");
		JPanel center_panel = new JPanel();
		center_panel.add(label);
		center_panel.add(jbar);
		center_panel.add(cancel);
		JDialog dialog = new JDialog(frame, "Working ...");
		dialog.setUndecorated(true);
		dialog.setSize(200,100);
		dialog.setLocation(200,200);
		dialog.getContentPane().add(center_panel, BorderLayout.CENTER);
		dialog.pack();
		dialog.setVisible(true);
		dialog.setModal(true);
		//dialog.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG);
		
		MyWorker myWorker = new MyWorker(jbar,dialog,cancel);
		//myWorker.execute();
		myWorker.run();
		
	
	}
	
	private static class MyWorker extends SwingWorker<String, Integer>
	{
		private final JProgressBar jbar;
		private final JDialog jdialog;
		private  JButton cancel;
		public MyWorker( JProgressBar jbar, JDialog dialog,JButton cancel )
		{
			this.jbar = jbar;
			this.jdialog = dialog;
			this.cancel = cancel;
			this.cancel.addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent e)
				{
					cancel(true);
				}
				
			});
		}
		
		private class SetterClass implements Runnable
		{
			final int x;
			
			public SetterClass(int x) 
			{
				this.x = x;
			}

			@Override
			public void run() {
				jbar.setValue(x);
				
			}
		}
		
		@Override
		protected String doInBackground() throws Exception
		{
			for( int x=0; x < 243; x++)
			{
				//publish(new Integer(x));
				Thread.sleep(50);
				System.out.println(x);
				SwingUtilities.invokeLater(
						new SetterClass(x));
				
				
			}
			
			return "Finished";
		}
		
		@Override
		protected void done() 
		{
			jdialog.dispose();
			
			if( isCancelled())
			{
				System.out.println("Cancelled");
				// closeAll
			}
		}
		
	}
	
		
	
}
