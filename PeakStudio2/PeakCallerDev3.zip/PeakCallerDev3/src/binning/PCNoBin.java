package binning;

import java.util.ArrayList;
import java.util.List;
import scripts.ParseUnifracResults;
import dataProvider.DataProvider;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;



public class PCNoBin extends AbstractPeakCallBinningMethod
{
	public ArrayList<ArrayList<Double>> binListofLists;
	final double threshold;
	final boolean isBINARY;
	final boolean isPeak;
	final int startRange, stopRange;
	
	public PCNoBin( List<Spectra> spectra, double threshold, boolean isBinary, boolean isPeak) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + spectra.size() );
		this.threshold = threshold;
		this.isBINARY = isBinary;
		startRange = 400;
		stopRange = 1200;
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(spectra);
		System.out.println(" Our binlistsoflists is " + binListofLists.size());
	}
	
	public PCNoBin( List<Spectra> spectra, double threshold, boolean isBinary, boolean isPeak, int start, int stop) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + spectra.size() );
		this.threshold = threshold;
		this.isBINARY = isBinary;
		startRange = start;
		stopRange = stop;
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(spectra);
		System.out.println(" Our binlistsoflists is " + binListofLists.size());
	}
			
	@Override
	public String getName() throws Exception
	{
		if (isPeak) return "NoBin" + isBINARY +"Peaked";
		return "SimpleBinFraction" + isBINARY;
	}
	
	
	public ArrayList<Double> fillBins(AbstractFSAFileDescriptor fsa) throws Exception
	{
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		if (isPeak)
		{
			theData = super.convertToPeakSpace(specs, basepairdata, isBINARY, threshold);
		}
		//System.out.println("Before " + count + " and after " + theData.length);
		ArrayList<Double> returnList = new ArrayList<Double>();
		
		//System.out.println(" Spectra list is " + specs.size() + " and the bpData size is " + basepairdata.length + "and the data array is " + theData.length);
		
		double start = startRange ; //shiftBin is the Fuhrman bin shifting method.....
		double stop = stopRange;
		
		for (int i = 0; i < theData.getLength(); i++)
		{
			//ArisaObject ao = aoList.get(i);
			float basepair = basepairdata.get(i);
			
			//System.out.println( " Start is " + start + " and stop is " + "stop + and ID is " + basepair + " and binTotal is " + binTotal);
			if (basepair > start && basepair < stop)
			{
					if (isBINARY == false)
					{
						returnList.add(Double.valueOf(theData.get(i)));
					}
					else 
					{
						if (Double.valueOf(theData.get(i)) > threshold)
						{
							returnList.add(1.0); //present!!
							//System.out.println("Bin tally is " + binTally + " and threshold was " + threshold);
						}
						else
						{
							returnList.add(0.0); //absent !!
							//System.out.println("BELOW THRESHOLD !!  Bin tally is " + binTally + " and threshold was " + threshold);
						}
					}	
					//returnList.add(binTotal);   // USE this to check the bin sizes.....
			}
		}
		return returnList;
	}
	

	private static ArrayList<Double> convertBinsToFractions(ArrayList<Double> list)
	{
		double sumIntensity = 0;
		for (Double d: list)
		{
			sumIntensity += d;
		}
		for (int i=0; i < list.size(); i++)
		{
			double d = list.get(i) / sumIntensity;
			list.set(i,d);
		}
		return list;
	}
	
	
	@Override
	public ArrayList<ArrayList<Double>> fillBins()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBinDescription()
	{
		String desc = "NoBins-" + isBINARY + isPeak;
		return desc;
	}

	@Override
	public int getNumberOfBins()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	public double getThreshold()
	{
		return threshold;
	}

	@Override
	public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception
	{
		ArrayList<ArrayList<Double>> binList = new ArrayList<ArrayList<Double>>();
		
		for (int i = 0; i < spectra.size(); i++)
		{
			ArrayList<Double> list = fillBins(spectra.get(i).getFileDescriptor());
			System.out.println(" BinnedList" + i + " = " + list.size());
			if (dataAsFractions == true) list = convertBinsToFractions(list); 
			binList.add(list); 
		}
		System.out.println("binList is now " + binList.size() + " And it's 1st value size is " + binList.get(0).size());
		
		return binList;
	}

	@Override
	public ArrayList<ArrayList<Double>> getBinListofLists()
	{
		return binListofLists;
	}


	public boolean isDataAsFractions()
	{
		return dataAsFractions;
	}


	public boolean isBINARY()
	{
		return isBINARY;
	}


	public boolean isPeak()
	{
		return isPeak;
	}
}
