package binning;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import scripts.ParseUnifracResults;
import dataProvider.DataProvider;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;



public class PCFuhrman04 extends AbstractPeakCallBinningMethod
{
	public ArrayList<ArrayList<Double>> binListofLists;
	public boolean dataAsFractions = false;
	final boolean isBINARY;
	final boolean isPeak;
	
	public PCFuhrman04(List<Spectra> nonStndList,  boolean isBinary, boolean isPeak) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + nonStndList.size() );
		
		this.isBINARY = isBinary;
		if (isBinary == true) dataAsFractions = false; //can't calculate fractions when in binary.
		
		//if (isBinary && isPeak) throw new Exception(" HEY, we can't do both bonary and peak binning choices at ONCE !! So Stop it.");
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(nonStndList);
		System.out.println(" Our binlistsoflists is " + binListofLists.size());
		
	}
	
			
	@Override
	public String getName() throws Exception
	{
		if (isPeak) return "Fuhrman04" + "Peaked";
		return "Fuhrman04"  + isBINARY;
	}
	
	@Override
	public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception
	{
		ArrayList<ArrayList<Double>> binList = new ArrayList<ArrayList<Double>>();
		for (int i = 0; i < spectra.size(); i++)
		{
		
			ArrayList<Double> list = fillViaChangingSizes(spectra.get(i).getFileDescriptor());
			System.out.println(" BinnedList" + i + " = " + list.size());
			if (dataAsFractions == true) list = convertBinsToFractions(list); 
			binList.add(list); 
		}
		System.out.println("binList is now " + binList.size() + " And it's 1st value size is " + binList.get(0).size());
		//binList = truncateBinListToEqualSize(binList);
		return binList;
	}
	
	static ArrayList<Double> fillViaChangingSizes(AbstractFSAFileDescriptor fsa) throws Exception
	{
		
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		
		int binSize = 3;
		int start = 399;
		double stop = 700;
		double binTotal = 399 + 3 ; // this is where we stop the next bin
		
		for (int i = 0; i < basepairdata.getLength(); i++)
		{
			double basepair = basepairdata.get(i); 
			
			if (basepair > (start) && basepair < stop)
			{	
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}	
			}
			else if (basepair > 700 && basepair < 1000)
			{
				binSize = 5;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
			else if (basepair > 1000 && basepair < 1200)
			{
				binSize = 10;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
		}
		System.out.println(" BIN FILLED with this many:" + returnList.size());
		return returnList;
	}
	
	
	private static ArrayList<Double> convertBinsToFractions(ArrayList<Double> list)
	{
		double sumIntensity = 0;
		for (Double d: list)
		{
			sumIntensity += d;
		}
		for (int i=0; i < list.size(); i++)
		{
			double d = list.get(i) / sumIntensity;
			list.set(i,d);
		}
		
		return list;
	}
	
	

	@Override
	public ArrayList<ArrayList<Double>> fillBins()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBinDescription()
	{
		String desc = "Fuhrman04 expanding bins method";
		return desc;
	}

	@Override
	public int getNumberOfBins()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	
	
	

	@Override
	public ArrayList<ArrayList<Double>> getBinListofLists()
	{
		return binListofLists;
	}


	public boolean isDataAsFractions()
	{
		return dataAsFractions;
	}


	public boolean isBINARY()
	{
		return isBINARY;
	}


	public boolean isPeak()
	{
		return isPeak;
	}


}
