package binning;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import dataProvider.ArrayBasedDataProvider;
import dataProvider.DataProvider;

import experimentSets.AbstractExperimentSet;
import experimentSets.Feature;
import experimentSets.Spectra;


public abstract class AbstractPeakCallBinningMethod implements BinningInterface
{	
	abstract public String getBinDescription() throws Exception;
	
	abstract public String getName() throws Exception;
	
	abstract public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception;
	
	public static File writeNewickFormatToFile(String test,AbstractExperimentSet sz, AbstractPeakCallBinningMethod meth) throws Exception
	{
		
		File newDir = new File( sz.getFileDescriptors().get(0).getFSAFile().getParentFile() + File.separator + 
		"NH_Files");
		
		if( ! newDir.exists())
			newDir.mkdir();
		
		File file = new File(newDir.getAbsoluteFile() + File.separator + "clusterInfo-" + meth.getName() + ".nh");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		writer.write(test + "\n");
		
		writer.flush(); writer.close();
		return file;
	}
	
	public static File writeNewickFormatToFile(String test,File fileDir, AbstractPeakCallBinningMethod meth) throws Exception
	{
		
		File newDir = new File( fileDir.getParentFile() + File.separator + 
		"NH_Files");
		
		if( ! newDir.exists())
			newDir.mkdir();
		
		File file = new File(newDir.getAbsoluteFile() + File.separator + "clusterInfo-" + meth.getName() + ".nh");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		writer.write(test + "\n");
		
		writer.flush(); writer.close();
		return file;
	}

	public static DataProvider<Short> convertToPeakSpace(List<Spectra> specs,DataProvider<Float> basepairdata, boolean isBinary, double threshold)
	{
		Short[] newArray = new Short[basepairdata.getLength()];
		List<Feature> peakList = specs.get(0).getLastGeneratedPeakSet();
		int peakCount = 0;
		int currentPeakIndex = peakList.get(0).getFinalIndex();
		
		for (int i = 0; i < basepairdata.getLength(); i++)
		{
			if (i < currentPeakIndex)
			{
				newArray[i] = 0;
				//System.out.println("Index = " + i + " and current peak index is " + currentPeakIndex);
			}
			else if (i >= currentPeakIndex)
			{
				if (isBinary)
				{
					if ((peakList.get(peakCount).getMaxValue()-peakList.get(peakCount).getMinValue()) > threshold)
					{
						newArray[i] = 1;
					}
					else
					{
						newArray[i] = 0;
					}
				}
				else
				{
					//Have an issue with casting to Short
					//newArray[i] =  (peakList.get(peakCount).getMaxValue()-peakList.get(peakCount).getMinValue());
				}
				
				
				peakCount++;
				if (peakList.size() > peakCount)
				{
					currentPeakIndex = peakList.get(peakCount).getFinalIndex();
					System.out.println("Index = " + i + " and current peak index is " + currentPeakIndex + " and the value for array is " + newArray[i]);
				}
				else
				{
					currentPeakIndex = Integer.MAX_VALUE;
				}	
			}
		}
		return new ArrayBasedDataProvider<Short>( newArray);
	}
	
	abstract public ArrayList<ArrayList<Double>> getBinListofLists();
}
