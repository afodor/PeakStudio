package binning;

import java.util.ArrayList;
import java.util.List;

import dataProvider.DataProvider;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;





public class PCFuhrmanShiftingMethod extends AbstractPeakCallBinningMethod
{
	public ArrayList<ArrayList<Double>> binListofLists;
	public boolean dataAsFractions = false;
	final boolean isBINARY;
	final boolean isPeak;
	
	public PCFuhrmanShiftingMethod(List<Spectra> spectra,  boolean isBinary, boolean isPeak) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + spectra.size() );
		
		this.isBINARY = isBinary;
		if (isBinary == true) dataAsFractions = false; //can't calculate fractions when in binary.
		
		if (isBinary && isPeak) throw new Exception(" HEY, we can't do both bonary and peak binning choices at ONCE !! So Stop it.");
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(spectra);
	}
	
			
	@Override
	public String getName() throws Exception
	{
		if (isPeak) return "FuhrmanShifting" + "Peaked";
		return "FuhrmanShifting"  + isBINARY;
	}
	
	@Override
	public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception
	{
		ArrayList<ArrayList<Double>> binList = new ArrayList<ArrayList<Double>>();
		
		ArrayList<Double> allTheShifts = calcBestShiftsForEachBin(spectra);
		
		int bestShift = fetchLowestShiftScore(allTheShifts);
		
		for (int i = 0; i < spectra.size(); i++)
		{
			//System.out.println(" List" + i + " = " + expt.getFileDescriptors().get(i).getFileNamePrefix());
			ArrayList<Double> list = fillViaChangingSizes(spectra.get(i).getFileDescriptor(), bestShift);
			if (dataAsFractions == true) list = convertBinsToFractions(list); 
			binList.add(list); 
		}
		System.out.println("ShiftMethod: binList is now " + binList.size() + " And it's 1st value size is " + binList.get(0).size());
		return binList;
	}
	
	static int fetchLowestShiftScore(ArrayList<Double> listOfShiftsForBins)
	{
		int shift = 0; //start with no shift
		double lowestScore = listOfShiftsForBins.get(0);
		for (int i = 1; i < listOfShiftsForBins.size(); i++)
		{
			if (lowestScore > listOfShiftsForBins.get(i))
			{
				shift = i;
				lowestScore = listOfShiftsForBins.get(i);
			}
		}
		return shift;
	}
	
	private static ArrayList<Double> calcBestShiftsForEachBin(List<Spectra> spectra) throws Exception
	{
		ArrayList<Double> sumShiftList = new ArrayList<Double>(); //10 score (euclidian distance) entries, one for each shift
		ArrayList<ArrayList<Double>> exptList = new ArrayList<ArrayList<Double>>(); //list, each entry is expt pair list (of 10 shift scores), 
		
		for (int i = 0; i < spectra.size(); i=i+2)
		{
			ArrayList<Double> shiftList = getScoreForEachShiftFor2Expts(spectra.get(i).getFileDescriptor(), spectra.get(i+1).getFileDescriptor());
			exptList.add(shiftList); 
		}
		System.out.println("ExptList is now " + exptList.size() + " And it's 1st value size is " + exptList.get(0).size());
		sumShiftList  = sumScoresForEachShift(exptList);
		return sumShiftList;
	}
	
	private static ArrayList<Double> getScoreForEachShiftFor2Expts(AbstractFSAFileDescriptor list1, AbstractFSAFileDescriptor list2) throws Exception
	{
		//System.out.println(" Map sizes are " + treeMap.size() + " and "  + treeMap2.size());
		ArrayList<Double> returnList = new ArrayList<Double>();
			
		//TIME to SHIFT!, num is 10 because that is far as we want to shift
		for (int i = 0; i < 10; i++)
		{
			ArrayList<Double> bin1 = fillViaChangingSizes(list1, i);
			ArrayList<Double> bin2 = fillViaChangingSizes(list2, i);
			ArrayList<Double> deltaBin = subtractOneBinResultFromTheOther(bin1,bin2);
			double binSum = 0;
			for (int j = 0; j < deltaBin.size(); j++)
			{
				binSum += deltaBin.get(j);
			}
			returnList.add(binSum);
		}
		return returnList;
	}
	
	static ArrayList<Double> subtractOneBinResultFromTheOther(ArrayList<Double> bin1, ArrayList<Double> bin2)
	{
		/*this line accounts for shifting by adding a large nonsense number to
		 * the front of list 2 until the sizes match.
		 * It will then discard that number in the comparison step in the getBestShiftFor2Expts method.
		 * 		 */
		while (bin2.size() < bin1.size()) bin2.add(0, 10000.00);
		ArrayList<Double> tempList = new ArrayList<Double>();
		//now compare the 2 lists and take the smallest value
		for (int i = 0; i < bin1.size(); i++)
		{
			double tempValue = bin2.get(i);
			tempValue = Math.abs(bin2.get(i) - bin1.get(i));
			tempList.add(i, tempValue);
		}
		
		return tempList;
	}
	
	static ArrayList<Double> fillViaChangingSizes(AbstractFSAFileDescriptor fsa, int howMuchToShift) throws Exception
	{
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		
		int binSize = 3;
		int start = 399 ;
		double stop = 700;
		double binTotal = 399 + 3 + howMuchToShift; // this is where we stop the next bin
		if (howMuchToShift <= binSize)
		{
			start += howMuchToShift;
			stop += howMuchToShift;
		}
		for (int i = 0; i < basepairdata.getLength(); i++)
		{
			double basepair = basepairdata.get(i); 
			
			if (basepair > (start) && basepair < stop)
			{	
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}	
			}
			else if (basepair > 700 && basepair < 1000)
			{
				binSize = 5;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
			else if (basepair > 1000 && basepair < 1200)
			{
				binSize = 10;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
		}
		System.out.println(" BIN FILLED with this many:" + returnList.size());
		return returnList;
	}
	
	static ArrayList<Double> sumScoresForEachShift(ArrayList<ArrayList<Double>> megaListOfBinShifts)
	{
		ArrayList<Double> sumShiftList = new ArrayList<Double>();
		
		//summing each shift
		for (int i = 0; i < megaListOfBinShifts.get(0).size(); i++)
		{
			double temp = 0;
			for (int j = 0; j < megaListOfBinShifts.size(); j++)
			{
				temp += megaListOfBinShifts.get(j).get(i);
			}
			sumShiftList.add(temp);
		}
		return sumShiftList;
	}
	
	public static ArrayList<Double> fillSimpleBin(AbstractFSAFileDescriptor fsa,AbstractExperimentSet sz, float fraction, double threshold, boolean isBinary) throws Exception
	{
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		//System.out.println(" Spectra list is " + specs.size() + " and the bpData size is " + basepairdata.length + "and the data array is " + theData.length);
		
		
		double start = 400-(fraction/2.0) ; //shiftBin is the Fuhrman bin shifting method.....
		double stop = 1200 + (fraction/2.0);
		double binTotal = start + fraction; // this is where we stop the next bin
		for (int i = 0; i < theData.getLength(); i++)
		{
			//ArisaObject ao = aoList.get(i);
			float basepair = basepairdata.get(i);
			
			//System.out.println( " Start is " + start + " and stop is " + "stop + and ID is " + basepair + " and binTotal is " + binTotal);
			if (basepair > start && basepair < stop)
			{
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					//binTally = Math.log(binTally);
				
					if (isBinary == false)
					{
						returnList.add(binTally);
					}
					else 
					{
						if (binTally > threshold)
						{
							returnList.add(1.0); //present!!
							System.out.println("Bin tally is " + binTally + " and threshold was " + threshold);
						}
						else
						{
							returnList.add(0.0); //absent !!
							System.out.println("BELOW THRESHOLD !!  Bin tally is " + binTally + " and threshold was " + threshold);
						}
					}	
					//returnList.add(binTotal);   // USE this to check the bin sizes.....
					binTally = 0;
					binTotal += fraction;
				}
			}
		}
		return returnList;
	}
	
	private static ArrayList<Double> convertBinsToFractions(ArrayList<Double> list)
	{
		double sumIntensity = 0;
		for (Double d: list)
		{
			sumIntensity += d;
		}
		for (int i=0; i < list.size(); i++)
		{
			double d = list.get(i) / sumIntensity;
			list.set(i,d);
		}
		
		return list;
	}
	
	

	@Override
	public ArrayList<ArrayList<Double>> fillBins()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBinDescription()
	{
		String desc = "Fuhrman Shifting bins method";
		return desc;
	}

	@Override
	public int getNumberOfBins()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	public ArrayList<ArrayList<Double>> getBinListofLists()
	{
		return binListofLists;
	}


	public boolean isDataAsFractions()
	{
		return dataAsFractions;
	}


	public boolean isBINARY()
	{
		return isBINARY;
	}


	public boolean isPeak()
	{
		return isPeak;
	}
}
