package binning;

import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;

public class BinParameters 
{
	 

	boolean dataAsFractions;
	 boolean isPeak;
	 boolean isBinary;
	 int binSize;
	 String name;
	 double threshold;
	 LinkageMethod clusterMethod;
	
	public BinParameters(boolean dataAsFractions, boolean isPeak,
			boolean isBinary, int binSize, String name, double threshold, LinkageMethod lm) 
	{
		super();
		this.dataAsFractions = dataAsFractions;
		this.isPeak = isPeak;
		this.isBinary = isBinary;
		this.binSize = binSize;
		this.name = name;
		this.threshold = threshold;
		this.clusterMethod = lm;
	}
	
	public BinParameters(boolean dataAsFractions, boolean isPeak,
			 int binSize, String name,  LinkageMethod lm ) 
	{
		super();
		this.dataAsFractions = dataAsFractions;
		this.isPeak = isPeak;
		this.isBinary = false;
		this.binSize = binSize;
		this.name = name;
		this.threshold = 0.00;
		this.clusterMethod = lm;
	}
	
	public BinParameters() 
	{
		super();
		this.dataAsFractions = false;
		this.isPeak = true;
		this.isBinary = false;
		this.binSize = 1;
		this.name = "Default";
		this.threshold = 0.00;
		this.clusterMethod = new WardsMethod();
	}

	public LinkageMethod getClusterMethod() {
		return clusterMethod;
	}

	public void setClusterMethod(LinkageMethod clusterMethod) {
		this.clusterMethod = clusterMethod;
	}

	public boolean isDataAsFractions() {
		return dataAsFractions;
	}

	public boolean isPeak() {
		return isPeak;
	}

	public boolean isBinary() {
		return isBinary;
	}

	public int getBinSize() {
		return binSize;
	}

	public String getName() {
		return name;
	}

	public double getThreshold() {
		return threshold;
	}

		
	public void setDataAsFractions(boolean dataAsFractions) {
		this.dataAsFractions = dataAsFractions;
	}

	public void setPeak(boolean isPeak) {
		this.isPeak = isPeak;
	}

	public void setBinary(boolean isBinary) {
		this.isBinary = isBinary;
	}

	public void setBinSize(int binSize) {
		this.binSize = binSize;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setThreshold(double threshold) {
		this.threshold = threshold;
	}


}
