package binning;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import dataProvider.DataProvider;
import experimentSets.Feature;
import experimentSets.FsaFileDescriptor;
import experimentSets.GuiDerivedExperimentSet;
import experimentSets.Spectra;

import viewer.FsaFrame;

public class BinPeaks
{
	private float bp_start,bp_end,bin_size,peak_height;
	private FsaFrame fsaFrame;
	private GuiDerivedExperimentSet gdes;
	private int num_of_bins;
	private double[][] data_matrix;
	private List<String> bins;
	private int number_cols;
	private int max_spectra_channels;
	private List<String> fdHeader = new ArrayList<String>();
	
	
	public BinPeaks(float bps,float bpe, float bs,float ph, FsaFrame frame) 
	{
		this.bp_start = bps;
		this.bp_end = bpe;
		this.bin_size = bs;
		this.peak_height = ph;
		this.fsaFrame = frame;
		this.gdes = this.fsaFrame.getExperimentSet();
		setUpPeakArrays();
		setUpBins();
	}
	
	private void setUpPeakArrays() 
	{
		try
		{
			this.num_of_bins = (int)((this.bp_end - this.bp_start)/this.bin_size);

			for(FsaFileDescriptor fd: this.gdes.getFileDescriptors())
			{
				this.fdHeader.add(fd.getFileNamePrefix());
				for(Spectra s: fd.getDataSpectra())
				{
					s.setSumPeaksSize(this.num_of_bins);
				}	
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.fsaFrame, "Error: "
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	private void setUpBins()
	{
		bins = new ArrayList<String>();
		for(int x=0; x<this.num_of_bins; x++)
		{
			int str = (int)(this.bp_start + (x * this.bin_size));
			int end = str + (int)this.bin_size;
			bins.add(Integer.toString(str)+"-"+Integer.toString(end));
		}
	}
	
	public void collectPeaks()
	{
		try
		{
			for(FsaFileDescriptor fd: this.gdes.getFileDescriptors())
			{
				for(Spectra s: fd.getDataSpectra())
				{
					DataProvider<Float> bpCalls = s.getBasePairCalls();
					List<Feature> peaks = s.getLastGeneratedPeakSet();
					for(int x = 0; x< s.getSumPeaks().length; x++)
					{
						float str = this.bp_start + (x * this.bin_size);
						float end = str + this.bin_size;
						for(Feature p: peaks)
						{
							if(bpCalls.get(p.getIndexOfHighestPeak()) > str && 
									bpCalls.get(p.getIndexOfHighestPeak()) < end)
							{
								if(p.getHeight() >= this.peak_height)
									s.getSumPeaks()[x] += p.getHeight();
							}
								
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.fsaFrame, "Error: "
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	public double[][] getDoubleArray()
	{
		try
		{
			this.max_spectra_channels = 0;
			this.number_cols = 0;
			for(FsaFileDescriptor fd: this.gdes.getFileDescriptors())
			{
				int size = fd.getDataChannels().size();
				this.max_spectra_channels = Math.max(this.max_spectra_channels, size);
				for(Spectra s: fd.getDataSpectra())
				{
					this.number_cols = Math.max(this.number_cols, s.getSumPeaks().length);
				}
			}
			double[][] matrix = new double[this.gdes.getFileDescriptors().size()][this.num_of_bins*this.max_spectra_channels];
			for(int row=0; row<this.gdes.getFileDescriptors().size(); row++)
			{
				int col =0;
				List<Spectra> spectra = this.gdes.getFileDescriptors().get(row).getDataSpectra();
				for(Spectra s: spectra)
				{
					float[] sumPeaks = s.getSumPeaks();
					for(int index=0; index<sumPeaks.length; index++)
					{
						matrix[row][col] = sumPeaks[index];
						col++;
					}
					
				}
			}
			this.data_matrix = removeZeroCols(matrix);
			return this.data_matrix;
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.fsaFrame, "Error: "
					+ e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
		}
		return null;
		
	}
	private double[][] removeZeroCols(double[][] d)
	{
		int cols = d[0].length;
		int rows = d.length;
		List<String> totalBins = new ArrayList<String>();
		int size = cols/this.bins.size();
		for(int x=0; x<size; x++)
		{
			for(String s: this.bins)
				totalBins.add(s+"_"+(x+1));
		}
		
		List<double[]> colList = new ArrayList<double[]>();
		for(int y=0; y<cols; y++)
		{
			double[] f = new double[rows];
			for(int x=0; x<rows; x++)
			{
				f[x] = (int)d[x][y];
			}
			colList.add(f);
		}
		List<double[]> nonZeroList = new ArrayList<double[]>();
		List<String> nonZeroBins = new ArrayList<String>();
		for(int y=0; y<colList.size(); y++)
		{
			int numOverThreshold = 0;
			for(int x=0; x<colList.get(y).length; x++)
			{
				if(colList.get(y)[x] > 0)
					numOverThreshold++;
				
			}
			if(numOverThreshold >0)
			{
				nonZeroList.add(colList.get(y));
				nonZeroBins.add(totalBins.get(y));
			}
		}
		double[][] data = new double[nonZeroList.get(0).length][nonZeroList.size()];
		for(int y=0; y<nonZeroList.size(); y++)
		{
			for(int x=0; x<nonZeroList.get(y).length; x++)
			{
				data[x][y] = nonZeroList.get(y)[x];
			}
		}
		this.data_matrix = data;
		this.bins = nonZeroBins;
		return data;
	}
	
	public List<String> getBins()
	{
		return this.bins;
	}
	
	public void outPutMatrix(File outFile) throws Exception
	{		
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile ));
		for(String s: this.bins)
			writer.write("\t"+"BP_"+s);
		writer.write("\n");
		for(int x=0; x<this.data_matrix.length; x++)
		{
			writer.write(this.gdes.getFileDescriptors().get(x).getFileNamePrefix()+"\t");
			for(int y=0; y<this.data_matrix[x].length; y++)
			{
				writer.write(this.data_matrix[x][y]+"\t");
			}
			writer.write("\n");
		}
		writer.flush(); writer.close();

	}
	public double[][] getDataMatrix()
	{
		return this.data_matrix;
	}
}
