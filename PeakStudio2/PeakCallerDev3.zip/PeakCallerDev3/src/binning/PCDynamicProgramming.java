package binning;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import scripts.ParseUnifracResults;
import dataProvider.DataProvider;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;

public class PCDynamicProgramming extends AbstractPeakCallBinningMethod
{
	public ArrayList<ArrayList<Double>> binListofLists;
	public boolean dataAsFractions = false;
	final boolean isBINARY;
	final boolean isPeak;
	static int MAXBINSIZE = 10;
	
	
	public PCDynamicProgramming(List<Spectra> spectra,  boolean isBinary, boolean isPeak) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + spectra.size() );
		
		this.isBINARY = isBinary;
		if (isBinary == true) dataAsFractions = false; //can't calculate fractions when in binary.
		
		if (isBinary && isPeak) throw new Exception(" HEY, we can't do both bonary and peak binning choices at ONCE !! So Stop it.");
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(spectra);
		System.out.println(" Our binlistsoflists is " + binListofLists.size());
	}
	
			
	@Override
	public String getName() throws Exception
	{
		if (isPeak) return "DynamicProg" + "Peaked";
		return "DynamicProg"  + isBINARY;
	}
	
	@Override
	public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception
	{
		ArrayList<ArrayList<Double>> binList = new ArrayList<ArrayList<Double>>();
	
		int[] binSizesList = dpUsingMaps(spectra);
		
		for (Spectra fst: spectra)
		{
			//DataProvider<Integer> rawReads = fst.getData();
			DataProvider<Short> rawReads = fst.getData();
			ArrayList<Double> data = fillBinsUsingDPResults(rawReads, binSizesList);
			binList.add(data);
		}
		//RandomBinClusters.writeFinalDataToFile(finalBinLists, expt,resultDir, "dpBin");
		return binList;		
	}
	
	private static int[] dpUsingMaps(List<Spectra> spectra) throws Exception
	{
		
		ArrayList<ArrayList<DynaObject>> listofDynas = new ArrayList<ArrayList<DynaObject>>();
		//List<AbstractFSAFileDescriptor> fsaList = expt.getFileDescriptors();
		
		for (int i = 0; i <  spectra.size(); i = i + 2)
		{
			ArrayList<DynaObject> bestSizesForEachBin = calcBestSizesForeachBin(spectra.get(i).getFileDescriptor(),spectra.get(i+1).getFileDescriptor()); 
			listofDynas.add(bestSizesForEachBin);
		} // got all the bins from all the pairs, now go figure out what bin sizes occur most often at each location
		//writeDynaListToFile(listofDynas, resultDir, nameList);
		
		int[] mostCommonBinSizes = determineHighestTallyForEachBin(listofDynas);
		//writeMostPopularBinsToFile(mostCommonBinSizes, resultDir);
		return mostCommonBinSizes;
	}
	
	private static int[] determineHighestTallyForEachBin(ArrayList<ArrayList<DynaObject>> listofDynas) throws Exception
	{
		int[] mostCommonBinSizes = new int[listofDynas.get(0).size()]; 
		
		int smallestList = Integer.MAX_VALUE;
		for (ArrayList<DynaObject> ado : listofDynas)
		{
			if (smallestList > ado.size())
			{
				smallestList = ado.size();
			}
			System.out.println(" this list is this big: " + ado.size());
		}
		
		int[][] binSizesList  = new int[listofDynas.get(0).size()][MAXBINSIZE]; //this will keep tabs of how often each bin size 
		//occurs at each base pair position, ie each bp will have an integer[] as big as MAXBINSIZE.
		// initialize teh arrays by iterating thru 1 dynaobject list....
		for (int i = 0; i< smallestList;i++)
		{
			for (int z = 0; z < MAXBINSIZE; z++) {binSizesList[i][z] = 0;}  //setting all array values from null to 0;	
		}
		//System.out.println(" Bins size list is " + binSizesList.length + " and the Dynas List size is " + listofDynas.size()); // is correct !
		
		for (ArrayList<DynaObject> fud: listofDynas)
		{
			for (int i = 0; i< smallestList;i++)
			{
				int thisBinSize = fud.get(i).getBinSize(); //1st list, ith dynaobject, getting bin size
				System.out.println("before and teh bin size is " + thisBinSize);
				
				Integer currentTally = (binSizesList[i][thisBinSize]);
				currentTally++;
				binSizesList[i][thisBinSize] = currentTally;
				System.out.println("We just set binSize:currenT tally :  " + thisBinSize + "\t" + currentTally );
			}
			mostCommonBinSizes = calcMostOftenOccuringBin(binSizesList, listofDynas.get(0).size());	
		}
		return mostCommonBinSizes;
	}
	
	private static int[] calcMostOftenOccuringBin(int[][] binSizesList, int size)
	{
		int[] array = new int[size];
		
		for (int i = 0; i < size; i++)
		{
			int binWithMostHits = 0;
			for (int j = 0; j < MAXBINSIZE; j++)
			{
				if (binSizesList[i][j] > binWithMostHits) binWithMostHits = j;
			}
			array[i] = binWithMostHits;
			System.out.println(" Biggest bin was " + binWithMostHits);
		}
		
		return array;
	}
	
	private static ArrayList<DynaObject> calcBestSizesForeachBin(AbstractFSAFileDescriptor list1, AbstractFSAFileDescriptor list2) throws Exception
	{
		list1.callAllPeaks();
		list2.callAllPeaks();
		
		DataProvider<Float> basepairdata1 = list1.getLastSetOfBasePairCalls();
		List<Spectra> specs1 = list1.getDataSpectra();
		DataProvider<Short> theData1 = specs1.get(0).getData();
		Integer originalStartPosition = 398; // 400 is the first integer, decided elsewhere.
		
		DataProvider<Float> basepairdata2 = list2.getLastSetOfBasePairCalls();
		List<Spectra> specs2 = list2.getDataSpectra();
		DataProvider<Short> theData2 = specs2.get(0).getData();
		
		int startLocation1 = fetchStart(basepairdata1, originalStartPosition);
		int startLocation2 = fetchStart(basepairdata2, originalStartPosition);
		
		ArrayList<DynaObject> doList = new ArrayList<DynaObject>();
		
		
		//first score, is simply score1 - score2, very easy 
		double score1 = theData1.get(startLocation1); 
		double score2 = theData2.get(startLocation2); 
		double difference = Math.abs(score1-score2);	
		
		DynaObject firstDO = new DynaObject(originalStartPosition,Integer.valueOf(0),difference);
		doList.add(firstDO);
		
		for (int i = 399; i < basepairdata1.get(basepairdata1.getLength()-1); i++)
		{
			int startPOsition = Math.max(i-MAXBINSIZE, 398);
			int currentPosition = i;
			double[] differences;
			double[] previousScores;
			if (startPOsition == 398)
			{
				differences = new double[i-398];
				previousScores = new double[i-398];
			}
			else
			{
				differences = new double[MAXBINSIZE];
				previousScores = new double[MAXBINSIZE];
			}
			//
			
			//System.out.println(" Start position:differencesSize: PrevisouSize " + startPOsition + " " + differences.length + " " + previousScores.length);
			int count = 0;
			// get scores for possible bin size.... Need bin sized score + plus score prior to that point
			for (int tempBinSize = startPOsition; tempBinSize < currentPosition; tempBinSize++)
			{
				score1 =  0.0;
				score2 = 0.0;
				for (int j= tempBinSize; j <= currentPosition; j++)
				{
					score1 += theData1.get(j); //filling the bin 
					score2 += theData2.get(j);
					//System.out.println(" we are in the loop and j is " + j + " and score1 is " + score1);
				}
				//System.out.println(" we are out of the loop and score1 is " + score1 + " while score2 is " + score2);
				differences[count] = Math.abs(score1-score2);
				previousScores[count] = doList.get(tempBinSize-originalStartPosition).getBinScore(); 
				count++; // tested , counts work !!!
			} 
			DynaObject aDO = determineBestBinSize(differences, previousScores,i);
			doList.add(aDO);
			//if (i == 412) System.exit(1);  // for testing
			
		} //finished going through all the base pairs
		return doList;
	}
	
	private static DynaObject determineBestBinSize(double[] differences, double[] previousScores, int bpLocation)
	{
		
		double bestScore = Double.MAX_VALUE;;
		int binsize = 2000;
			
		for (int i = differences.length-1; i > -1; i--)
		{
			double score = previousScores[i] + differences[i];
			//System.out.println(" i is " + i + " and score is "  + score + " and difference was " + differences[i]);
			if ((score <= bestScore))
			{
				bestScore = differences[i]; // our current score, ie the best bin (we don't include the previous score
				binsize = i;
			}
		}
		//System.out.println(" location:BinSize:Score are " + bpLocation + "\t" + binsize + "\t" + bestScore);
		
			DynaObject aDO = new DynaObject(bpLocation,binsize, bestScore);
			return aDO;
	}
	
	private static int fetchStart(DataProvider<Float> basepairdata1, int startNT) 
	{
		int position = 0;
		for (int i=0; i < basepairdata1.getLength(); i++)
		{
			if (position == 0 && basepairdata1.get(i) <= startNT )
			{
				position = i;
			}
		}
		return position;
	}


	static ArrayList<Double> fillViaChangingSizes(AbstractFSAFileDescriptor fsa, AbstractExperimentSet sz) throws Exception
	{
		
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		
		
		int binSize = 3;
		int start = 399;
		double stop = 700;
		double binTotal = 399 + 3 ; // this is where we stop the next bin
		
		for (int i = 0; i < basepairdata.getLength(); i++)
		{
			double basepair = basepairdata.get(i); 
			
			if (basepair > (start) && basepair < stop)
			{	
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}	
			}
			else if (basepair > 700 && basepair < 1000)
			{
				binSize = 5;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
			else if (basepair > 1000 && basepair < 1200)
			{
				binSize = 10;
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					returnList.add(binTally);
					binTally = 0;
					binTotal += binSize;
				}
			}
		}
		System.out.println(" BIN FILLED with this many:" + returnList.size());
		return returnList;
	}
	
	public static ArrayList<Double> fillSimpleBin(AbstractFSAFileDescriptor fsa,AbstractExperimentSet sz, float fraction, double threshold, boolean isBinary) throws Exception
	{
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		//System.out.println(" Spectra list is " + specs.size() + " and the bpData size is " + basepairdata.length + "and the data array is " + theData.length);
		
		
		double start = 400-(fraction/2.0) ; //shiftBin is the Fuhrman bin shifting method.....
		double stop = 1200 + (fraction/2.0);
		double binTotal = start + fraction; // this is where we stop the next bin
		for (int i = 0; i < theData.getLength(); i++)
		{
			//ArisaObject ao = aoList.get(i);
			float basepair = basepairdata.get(i);
			
			//System.out.println( " Start is " + start + " and stop is " + "stop + and ID is " + basepair + " and binTotal is " + binTotal);
			if (basepair > start && basepair < stop)
			{
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					//binTally = Math.log(binTally);
				
					if (isBinary == false)
					{
						returnList.add(binTally);
					}
					else 
					{
						if (binTally > threshold)
						{
							returnList.add(1.0); //present!!
							System.out.println("Bin tally is " + binTally + " and threshold was " + threshold);
						}
						else
						{
							returnList.add(0.0); //absent !!
							System.out.println("BELOW THRESHOLD !!  Bin tally is " + binTally + " and threshold was " + threshold);
						}
					}	
					//returnList.add(binTotal);   // USE this to check the bin sizes.....
					binTally = 0;
					binTotal += fraction;
				}
			}
		}
		return returnList;
	}
	
	
	public static ArrayList<Double> fillBinsUsingDPResults(DataProvider<Short> dList, int[] randomBins) throws Exception
	{
				
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		int dListCount = 0;
			
		for (int i = 0; i < randomBins.length; i++)
		{
			int thisBin = randomBins[i];
			binTally = 0;
			for (int j = 0; j < thisBin; j++)
			{
				binTally += dList.get(dListCount);
				if (dListCount < dList.getLength()-1)
					dListCount++;
			}
			returnList.add(binTally);
			System.out.println("binTally = " + binTally + " and dListCount is " + dListCount + " and i is " + i + " and thisBin was " + thisBin);
		}
		return returnList;
	}

	@Override
	public String getBinDescription()
	{
		String desc = "Dynamic Programming bins method";
		return desc;
	}

	@Override
	public int getNumberOfBins()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	

	@Override
	public ArrayList<ArrayList<Double>> getBinListofLists()
	{
		return binListofLists;
	}


	public boolean isDataAsFractions()
	{
		return dataAsFractions;
	}


	public boolean isBINARY()
	{
		return isBINARY;
	}


	public boolean isPeak()
	{
		return isPeak;
	}

	@Override
	public ArrayList<ArrayList<Double>> fillBins()
	{
		// TODO Auto-generated method stub
		return null;
	}

}



class DynaObject
{
	int  bpLocation;
	int binSize;
	double binScore;
	
	public DynaObject(int bpLocation, int binSize, double binScore)
	{
		super();
		this.bpLocation = bpLocation;
		this.binSize = binSize;
		this.binScore = binScore;
	}
	public int getBpLocation()
	{
		return bpLocation;
	}
	
	public int getBinSize()
	{
		return binSize;
	}
	public void setBinSize(int previousBinStopLocation)
	{
		this.binSize = previousBinStopLocation;
	}
	public double getBinScore()
	{
		return binScore;
	}
	public void setBinScore(double binScore)
	{
		this.binScore = binScore;
	}
	

}
