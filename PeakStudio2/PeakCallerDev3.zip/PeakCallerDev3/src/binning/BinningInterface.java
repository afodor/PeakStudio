package binning;

import java.util.ArrayList;

public interface BinningInterface
{
	public ArrayList<ArrayList<Double>> binListofLists = new ArrayList<ArrayList<Double>>();
	
	public static boolean dataAsFractions = true;
	
	String getBinDescription() throws Exception;
	
	int getNumberOfBins() throws Exception;
	
	ArrayList<ArrayList<Double>> fillBins();
	
	
}
