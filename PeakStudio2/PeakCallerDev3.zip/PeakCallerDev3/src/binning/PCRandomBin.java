package binning;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import scripts.ParseUnifracResults;
import dataProvider.DataProvider;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;

import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;



public class PCRandomBin extends AbstractPeakCallBinningMethod
{
	public ArrayList<ArrayList<Double>> binListofLists;
	final boolean isBINARY;
	final boolean isPeak;
	static int MINBINSIZE = 1;
	static int MAXBINSIZE = 10;
	String name = "RandomBin";
	
	public PCRandomBin(List<Spectra> spectra, boolean isBinary, boolean isPeak, String nameID) throws Exception
	{
		System.out.println(" Beginning Simple Bin Fill: # of expts = " + spectra.size() );
		
		this.isBINARY = isBinary;
		if (isBinary && isPeak) throw new Exception(" HEY, we can't do both bonary and peak binning choices at ONCE !! So Stop it.");
		this.isPeak = isPeak;
		this.binListofLists = fillBinsUp(spectra);
		name += nameID;
		System.out.println(" Our binlistsoflists is " + binListofLists.size());	
	}
	
			
	@Override
	public String getName() throws Exception
	{
		if (isPeak) return name + isBINARY + "Peaked";
		return name + isBINARY;
	}
	
	
	public static ArrayList<Double> fillSimpleBin(AbstractFSAFileDescriptor fsa,AbstractExperimentSet sz, float fraction, double threshold, boolean isBinary) throws Exception
	{
		fsa.callAllPeaks();
		DataProvider<Float> basepairdata = fsa.getLastSetOfBasePairCalls();
		List<Spectra> specs = fsa.getDataSpectra();
		DataProvider<Short> theData = specs.get(0).getData();
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		//System.out.println(" Spectra list is " + specs.size() + " and the bpData size is " + basepairdata.length + "and the data array is " + theData.length);
		
		double start = 400-(fraction/2.0) ; //shiftBin is the Fuhrman bin shifting method.....
		double stop = 1200 + (fraction/2.0);
		double binTotal = start + fraction; // this is where we stop the next bin
		for (int i = 0; i < theData.getLength(); i++)
		{
			//ArisaObject ao = aoList.get(i);
			float basepair = basepairdata.get(i);
			
			//System.out.println( " Start is " + start + " and stop is " + "stop + and ID is " + basepair + " and binTotal is " + binTotal);
			if (basepair > start && basepair < stop)
			{
				if (basepair < binTotal)
				{
					binTally = binTally + theData.get(i);
				}
				else
				{
					//binTally = Math.log(binTally);
				
					if (isBinary == false)
					{
						returnList.add(binTally);
					}
					else 
					{
						if (binTally > threshold)
						{
							returnList.add(1.0); //present!!
							System.out.println("Bin tally is " + binTally + " and threshold was " + threshold);
						}
						else
						{
							returnList.add(0.0); //absent !!
							System.out.println("BELOW THRESHOLD !!  Bin tally is " + binTally + " and threshold was " + threshold);
						}
					}	
					//returnList.add(binTotal);   // USE this to check the bin sizes.....
					binTally = 0;
					binTotal += fraction;
				}
			}
		}
		return returnList;
	}
		
	

	@Override
	public ArrayList<ArrayList<Double>> fillBins()
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getBinDescription()
	{
		String desc = "Random Bins";
		return desc;
	}

	@Override
	public int getNumberOfBins()
	{
		// TODO Auto-generated method stub
		return 0;
	}
	

	@Override
	public ArrayList<ArrayList<Double>> fillBinsUp(List<Spectra> spectra) throws Exception
	{
		ArrayList<ArrayList<Double>> binList = new ArrayList<ArrayList<Double>>();
		
		PCSimpleBinFractions simple1 = new PCSimpleBinFractions(1, spectra,1,isBINARY, isPeak); //Random binning needs data in BP space so we call this method
		ArrayList<ArrayList<Double>> exptsAsDoubles = simple1.getBinListofLists();
		
		ArrayList<Integer> randomBins = calcRandomBins(calcSmallestListSize(exptsAsDoubles));
		
		for (int i = 0; i < exptsAsDoubles.size(); i++)
		{
			ArrayList<Double> list = fillRandomBin(exptsAsDoubles.get(i), randomBins);
			if (dataAsFractions == true) list = convertBinsToPercentIntensity(list); 
			binList.add(list); 
		}
		System.out.println("binList is now " + binList.size() + " And it's 1st value size is " + binList.get(0).size());
		return binList;
		
	}

	@Override
	public ArrayList<ArrayList<Double>> getBinListofLists()
	{
		return binListofLists;
	}

	private static ArrayList<Double> convertBinsToPercentIntensity(ArrayList<Double> list)
	{
		double sumIntensity = 0;
		for (Double d: list)
		{
			sumIntensity += d;
		}
		for (int i=0; i < list.size(); i++)
		{
			double d = list.get(i);
			d = (d/sumIntensity);
			list.set(i,d);
		}
		
		return list;
	}
	
	private int calcSmallestListSize(ArrayList<ArrayList<Double>> exptsAsDoubles)
	{
		int size = Integer.MAX_VALUE;
		
		for (ArrayList<Double> ad: exptsAsDoubles)
		{
			if ( ad.size() < size) size = ad.size();
		}
		return size;
	}
	
	public static ArrayList<Double> fillRandomBin(ArrayList<Double> dList, ArrayList<Integer> randomBins) throws Exception
	{
				
		ArrayList<Double> returnList = new ArrayList<Double>();
		double binTally = 0;
		int dListCount = 0;
			
		for (int i = 0; i < randomBins.size(); i++)
		{
			int thisBin = randomBins.get(i);
			binTally = 0;
			for (int j = 0; j < thisBin; j++)
			{
				binTally += dList.get(dListCount);
				if (dListCount < dList.size()-1)
					dListCount++;
			}
			returnList.add(binTally);
			System.out.println("binTally = " + binTally + " and dListCount is " + dListCount + " and i is " + i + " and thisBin was " + thisBin);
		}
		return returnList;
	}
	
	private  ArrayList<Integer> calcRandomBins(int num)
	{
		ArrayList<Integer> randomBins = new ArrayList<Integer>();
		
		int totalBasePairs = num;
		
		int count = 0;
		while (count < totalBasePairs)
		{
			Random aRand = new Random();
			int randomBin = aRand.nextInt(MAXBINSIZE) + MINBINSIZE; 
			count += randomBin;
			randomBins.add(randomBin);
		}
		
		/*for (int i = 0; i < randomBins.size(); i++)
		{
			System.out.println("At the " + i + "th position the value is " + randomBins.get(i));
		}*/
		return randomBins;
	}
	public boolean isDataAsFractions()
	{
		return dataAsFractions;
	}


	public boolean isBINARY()
	{
		return isBINARY;
	}


	public boolean isPeak()
	{
		return isPeak;
	}
}
