/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
*/


package de.linuxusers.clustering.linkage;

import java.util.List;

import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;

/**
 * Linkage using the distance between Cluster Centroids.
 * <br>&nbsp;<br>
 * <script type="text/javascript" src="../../../../LaTeXMathML.js"></script>
 * Formula as given by 
 * <a href="http://www.schulteimwalde.de/phd-thesis.html">Schulte im Walde (2003, p. 187)</a>:<br>
 * $d(C_i, C_j) = d_{mean}(C_i, C_j) = d(cen_i, cen_j)$
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: ClusterCentroid.java,v 1.1 2010/07/29 16:23:32 afodor Exp $
  */
public class ClusterCentroid implements LinkageMethod 
{

	/**
	 * @see de.linuxusers.clustering.linkage.LinkageMethod#computeDistance(de.linuxusers.clustering.data.Cluster, de.linuxusers.clustering.data.Cluster)
	 */
	public double computeDistance(Cluster cl1, Cluster cl2) 
	{
		
		// compute average of values in first cluster
		int i = 0;
		double sum = 0;
		double avg1 = 0;
		double avg2 = 0;
		boolean isList = cl1.getLeavesOrSelf().get(0).isList();
		
		if (! isList)
		{
			for ( DataPoint dp : cl1.getLeavesOrSelf())  
			{
				sum += dp.getValue();
				i++;
			}
		}
		else
		{
			for ( DataPoint dp : cl1.getLeavesOrSelf())  
			{
				sum += dp.getValue();
				i++;
			}
		}
		
		for ( DataPoint dp : cl1.getLeavesOrSelf())  
		{
			sum += dp.getValue();
			i++;
		}
		// FIXME: what happens with empty clusters?
		avg1 = sum/i;
		
		// compute average of values in second cluster
		i = 0;
		sum = 0;
		for ( DataPoint dp : cl2.getLeavesOrSelf())  
		{
			sum += dp.getValue();
			i++;
		}
		// FIXME: what happens with empty clusters?
		avg2 = sum/i;

		// return distance
		if (! isList)
		{
			return Math.abs(avg1 - avg2);
		}
		
		else
		{
			double listDifference = calcAvgViaLists(cl1.getLeavesOrSelf());
			return listDifference;
		}
	}
	
	private double calcAvgViaLists(List<DataPoint> dpList)
	{
		double avg = 0;
		return avg;
	}

	@Override
	public String getName() 
	{
		return "Cluster centroid";
	}

}
