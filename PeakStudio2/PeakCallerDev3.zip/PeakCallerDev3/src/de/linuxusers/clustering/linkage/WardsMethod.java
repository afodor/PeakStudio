/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301
*/

package de.linuxusers.clustering.linkage;

import java.util.ArrayList;
import java.util.List;

import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;

/**
 * Ward's method for linkage. Based on the following formula from
 * <a href="http://alumni.media.mit.edu/~tpminka/courses/36-350.2001/lectures/day9">
 * http://alumni.media.mit.edu/~tpminka/courses/36-350.2001/lectures/day9</a>:
 * <br> 
 * <script type="text/javascript" src="../../../../LaTeXMathML.js"></script>
 * $\Delta = \frac{n_a \cdot n_b}{n_a + n_b} (\bar{a} - \bar{b})^2$
 * @author Niels Ott
 * @author Ramon Ziai
 *
 */
public class WardsMethod implements LinkageMethod {

	/**
	 * @see de.linuxusers.clustering.linkage.LinkageMethod#computeDistance(de.linuxusers.clustering.data.Cluster, de.linuxusers.clustering.data.Cluster)
	 */
	public double computeDistance(Cluster cl1, Cluster cl2) {
		// compute average of values in first cluster
		double sum = 0;
		List<DataPoint> cl1Leaves = cl1.getLeavesOrSelf();
		
		if (! cl1Leaves.get(0).isList())
		{
			for ( DataPoint dp : cl1Leaves)  {
				sum += dp.getValue();
			}
			// FIXME: what happens with empty clusters?
			double centroid1 = sum/cl1Leaves.size();
			
			// compute average of values in second cluster
			sum = 0;
			List<DataPoint> cl2Leaves = cl2.getLeavesOrSelf();
			for ( DataPoint dp : cl2Leaves)  {
				sum += dp.getValue();
			}
			// FIXME: what happens with empty clusters?
			double centroid2 = sum/cl2Leaves.size();
			
			// calculate merging cost for the clusters
			return (double)(cl1Leaves.size() * cl2Leaves.size()) / (double)(cl1Leaves.size() + cl2Leaves.size())
					* Math.pow(centroid1 - centroid2, 2);
		}
		else
		{
			ArrayList<Double> sumList = new ArrayList<Double>();
			
			//initialize the sumList with zeroes....
			for (int i = 0;i < cl1Leaves.get(0).getListOfValues().size(); i++)
			{
				sumList.add(0.0);
			}
			//fill list1
			for ( DataPoint dp : cl1Leaves)  
			{
				for (int i = 0;i < dp.getListOfValues().size(); i++)
				{
					double temp = sumList.get(i) + dp.getListOfValues().get(i);
					sumList.set(i, temp);
				}	
			}
			ArrayList<Double> centroid1 = calcCentroid(sumList, cl1Leaves.size());
			
			// compute average of values in second cluster
			//clear sumList
			sumList.clear();
			List<DataPoint> cl2Leaves = cl2.getLeavesOrSelf();
			//initialize the sumList with zeroes....
			for (int i = 0;i < cl1Leaves.get(0).getListOfValues().size(); i++)
			{
				sumList.add(0.0);
			}
			//fill list1
			for ( DataPoint dp : cl2Leaves)  
			{
				for (int i = 0;i < dp.getListOfValues().size(); i++)
				{
					double temp = sumList.get(i) + dp.getListOfValues().get(i);
					sumList.set(i, temp);
				}	
			}sum = 0;
			
			for ( DataPoint dp : cl2Leaves)  {
				sum += dp.getValue();
			}
			
			ArrayList<Double> centroid2 = calcCentroid(sumList, cl2Leaves.size());
			double deltaCentroid = calcCentroidDifferences(centroid1, centroid2);
			// calculate merging cost for the clusters
			double distance = (double)(cl1Leaves.size() * cl2Leaves.size()) / (double)(cl1Leaves.size() + cl2Leaves.size())
			* Math.pow(deltaCentroid, 2);
			//System.out.println(" Centroid 1 = " + centroid1 + ", \ncentroid 2 = " + centroid2 + " \nand distance is " + distance);
			return distance;
			
			
		}
		
	}

	private ArrayList<Double> calcCentroid(ArrayList<Double> sumList, int size)
	{
		ArrayList<Double> centroidList = new ArrayList<Double>();
		for ( Double d: sumList)
		{
			double newValue = d / size;
			//System.out.println(" d = " + d + ", \nsize is = " + size + " \nand new value is " + newValue);
			centroidList.add(newValue);
		}
		return centroidList;
	}

	private double calcCentroidDifferences(ArrayList<Double>  centroid1, ArrayList<Double>  centroid2)
	{
		//System.out.println("Calcing the centroid differences");
		double diff = 0.0;
		if (! (centroid1.size()== centroid2.size()))
		{
			System.out.println(" We ran aground! Our centroid lists were of unequal size.");
			System.exit(0);
		}
		
		for (int i = 0; i < centroid1.size(); i++)
		{
			Number one = centroid1.get(i);
			Number two = centroid2.get(i);
			double delta = Math.abs(one.doubleValue() - two.doubleValue());
			diff += delta;
			//System.out.println(" Delta is now " + delta + " and diff is now " + diff);
		}
			
		return diff;
	}

	@Override
	public String getName() 
	{
		return "Wards";
	}

}
