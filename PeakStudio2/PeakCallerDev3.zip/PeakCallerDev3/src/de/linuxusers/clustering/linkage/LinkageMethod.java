/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/


package de.linuxusers.clustering.linkage;

import de.linuxusers.clustering.data.Cluster;

/**
 * Interface for linkage methods. A linkage method computes the distance
 * between two clusters and returns it as a double value.
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: LinkageMethod.java,v 1.1 2010/07/29 16:23:32 afodor Exp $
 *
 */
public interface LinkageMethod {
	
	/**
	 * Computes the distance between <code>cl1</code> and <code>cl2</code>
	 * and returns the result.
	 * @param cl1 The first cluster
	 * @param cl2 The second cluster
	 * @return The distance between the two clusters
	 * @throws Exception 
	 */
	public double computeDistance(Cluster cl1, Cluster cl2) throws Exception;

	public String getName();

}
