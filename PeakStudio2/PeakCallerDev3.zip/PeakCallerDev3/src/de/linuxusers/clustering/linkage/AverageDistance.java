/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/


package de.linuxusers.clustering.linkage;

import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;

/**
 * Linkage via average distance between Clusters.
 *
 * 
 * 
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: AverageDistance.java,v 1.1 2010/07/29 16:23:32 afodor Exp $
 *
 */
public class AverageDistance implements LinkageMethod {

	/**
	 * @see de.linuxusers.clustering.linkage.LinkageMethod#computeDistance(de.linuxusers.clustering.data.Cluster, de.linuxusers.clustering.data.Cluster)
	 */
	public double computeDistance(Cluster cl1, Cluster cl2) {

		
		// loop over both clusters, collecting the
		// sums of distances
		double overallSum = 0;
		int numOfDistances = 0;

		for ( DataPoint firstPoint : cl1.getLeavesOrSelf() ) {

			for ( DataPoint secondPoint : cl2.getLeavesOrSelf() ) 
			{
				
				// calculate distance and put it to sum
				double distance = 0;
				
				if (! firstPoint.isList())
				{
					distance = Math.abs( firstPoint.getValue() - secondPoint.getValue());
				}
				else
				{
					distance = calcDistanceViaLists(firstPoint, secondPoint);
				}
							
				overallSum += distance;
				numOfDistances++;
			}
		}
		
		// calculate the overall distance
		return (overallSum / numOfDistances);
	}

	public static double calcDistanceViaLists(DataPoint firstPoint, DataPoint secondPoint)
	{
		double diff = 0;
		
		int size = (firstPoint.getListOfValues().size() > secondPoint.getListOfValues().size()? secondPoint.getListOfValues().size(): firstPoint.getListOfValues().size());
		//System.out.println("Shifting Bin smallest size is " + size + " and 1st was " + firstPoint.getListOfValues().size()  + " and 2nd was " + secondPoint.getListOfValues().size());
		for (int i = 0; i < size; i++)
		{
			Number one = firstPoint.getListOfValues().get(i);
			Number two = secondPoint.getListOfValues().get(i);
			double delta = Math.abs(one.doubleValue() - two.doubleValue());
			diff += delta;
			//System.out.println(" Delta is now " + delta + " and diff is now " + diff);
		}
		double distance = diff/size;
		//System.out.println("This distance was " + distance);
		
		return distance;
	}

	@Override
	public String getName() 
	{
		
		return "Average Distance";
	}

}
