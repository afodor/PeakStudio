/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/

package de.linuxusers.clustering.diagrams;

import java.util.ArrayList;
import java.util.List;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;

/**
 * A simple class that converts clusters
 * into LaTeX code, presupposing that the qtree
 * package is installed. This is not too fancy
 * for real life applications. 
 * Therefore this class can serve for simple
 * debugging purposes and as an example of
 * cluster traversal. 
 * code from clusters
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: NewicktreeBuilder.java,v 1.1 2010/07/29 16:23:33 afodor Exp $
 */
public class NewicktreeBuilder {
	
	String nl = System.getProperty("line.separator");
	
	/**
	 * Get a LaTeX preamble
	 * @param dc the document class to use
	 * @param paper the paper to use.
	 * @return the LaTeX preamble
	 */
	public String getPreamble(String dc, String paper) {
		return("\\documentclass[" + paper + "]{"+ dc +"}" + nl 
				+ "\\usepackage{qtree}" + nl + nl
				+ "\\begin{document}" + nl
		);
	}
	
	/**
	 * Get a LaTeX preamble with <code>scrartcl</code>
	 * document class and <code>a4paper</code>.
	 * @return the LaTeX preamble
	 */
	public String getPreamble() {
		return getPreamble("scrartcl", "a4paper");
	}
	
	/**
	 * Get the ending part of a LaTeX document.
	 * Postamble is not a correct English word.
	 * @return the ending part of the LaTeX document.
	 */
	public String getPostamble() {
		return(nl + "\\end{document}" + nl);
	}
	
	/**
	 * Private function that does the actualy work of creating
	 * qtree code. This is done by recursively diving around
	 * in the cluster. 
	 * @param clusterIterable  clusterIterable an object implementing Cluster, or any collection
	 * of such a objects.
	 * @return  A line of LaTeX code to be used with the
	 * QTree package.
	 * @throws Exception 
	 */
	private String getQTreeRecursively(Iterable<Cluster> clusterIterable) throws Exception {
		String res ="";
		
		res += "(";
		
		// collect all items in the cluster
		for ( Cluster item : clusterIterable ) 
		{
			// add leaves directly
			// or go recursive for composites
			if ( item instanceof LabeledDataPoint ) 
			{
				res +=  
					((LabeledDataPoint)item).getLabel() +
					":1";   // leaves need no weight
			} 
			else if ( item instanceof DataPoint ) 
			{
				res += ((DataPoint)item).getValue();
			} 
			else 
			{
				res += getQTreeRecursively(item);
			}
			res += ",";
			
		}
		res = res.substring(0, (res.length()-1)); // this eats the last comma
		res += "):" ;
		
		List<DataPoint> theBiggerDPList = new ArrayList<DataPoint>();
		
		for ( Cluster item : clusterIterable ) 
		{
			List<DataPoint> dpList = item.getLeavesOrSelf();
			theBiggerDPList.addAll(dpList);
			//System.out.println("We called this loop !! " + ++f + " Bigger list holds  " + theBiggerDPList.size() );
		}
		double avg = calcAvgScore(theBiggerDPList);
		res += avg; 
		return res;
	}
	
	/**
	 * Creates a LaTeX QTree formatted tree from a Cluster.
	 * Note that <code>Iterable&lt;Cluster&gt;</code> also accepts
	 * any collection of Cluste, not just Cluster
	 * itsself.
	 * @param clusterIterable an object implementing Cluster, or any collection
	 * of such a objects.
	 * @return A line of LaTeX code to be used with the
	 * QTree package.
	 * @throws Exception 
	 */
	public String getTree(Iterable<Cluster> clusterIterable) throws Exception {

		return(getQTreeRecursively(clusterIterable)) + ";";
	}

	public static double calcAvgScore(List<DataPoint> theBiggerDPList) throws Exception
	{
		ArrayList<ArrayList<Double>> dataList = new ArrayList<ArrayList<Double>>();
		for (DataPoint dp:  theBiggerDPList)
		{
			dataList.add(dp.getListOfValues());
			if (dp.getListOfValues().size() == 0) throw new Exception(" OUr DP list was empty! That's bad" );
		}
		double avg = getAvgFromLists(dataList);
		return avg;
	}

	private static double getAvgFromLists(ArrayList<ArrayList<Double>> dataList)
	{
		ArrayList<Double> correlations = new ArrayList<Double>();
		
		for (int i=0; i < dataList.size(); i++)
		{
			ArrayList<Double> list1 = dataList.get(i);
			for (int j = i+1; j < dataList.size(); j++)
			{
				ArrayList<Double> list2 = dataList.get(j);
				double corr = utils.Pearson.getPearsonR(list1,list2 );
				correlations.add(corr);
			}
		}
		
		double total = 0;
		for (Double d: correlations)
		{
			total += d;
		}
		 total = (total / correlations.size());
		 total = Math.floor((100 * (1-total)));
		 return total;
	}

}
