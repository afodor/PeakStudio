/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/


package de.linuxusers.clustering.examples;

import java.util.ArrayList;

import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.NearestNeighbour;

/**
 * A simple example program that serves
 * as an introduction to this clustering library.
 * Please read the source code.
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: FirstClusteringTool.java,v 1.1 2010/07/29 16:23:31 afodor Exp $.
  */
public class FirstClusteringTool {

	public static void main(String[] args) throws Exception {
		
		// first, let's have some pieces of data
		ArrayList<Double> data = new ArrayList<Double>();
		data.add(1.0);
		data.add(2.0);
		data.add(3.0);
		data.add(5.0);
		data.add(6.0);
		data.add(7.0);
		data.add(9.0);
		data.add(10.0);
		data.add(11.0);
		data.add(13.0);
		data.add(14.0);
		data.add(15.0);
		
		// now let's pick some distance algorithm
		// (aka linkage method)
		LinkageMethod method = new NearestNeighbour();
		
		// do hierarchical clustering until there is only
		// one cluster left
		Cluster topCluster = HierarchicalClusterer.clusterDoubles(
				data, method);
		
		// print out this cluster including all its sub-clusters
		// and data points to the console
		System.out.println(topCluster);
		

	}

}
