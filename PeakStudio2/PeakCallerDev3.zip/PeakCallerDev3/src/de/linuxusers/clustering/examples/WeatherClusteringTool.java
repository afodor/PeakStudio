/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/


package de.linuxusers.clustering.examples;


import java.util.ArrayList;
import java.util.List;

import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.linkage.FurthestNeighbour;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;

/**
 * A a more complex example program using several
 * linkage methods and labeled data points.
 * Please read the source code.
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: WeatherClusteringTool.java,v 1.1 2010/07/29 16:23:31 afodor Exp $.
  */
public class WeatherClusteringTool {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		
		// these are the temparatures in Germany
		// on 2007-07-26 according to wetter24.de
		// (in degree Celsius)
		ArrayList<DataPoint> temperatures = new ArrayList<DataPoint>();
		temperatures.add( new LabeledDataPoint( 28, "Berlin" ));
		temperatures.add( new LabeledDataPoint( 25, "Hamburg" ));
		temperatures.add( new LabeledDataPoint( 27, "Cologne" ));
		temperatures.add( new LabeledDataPoint( 27, "Munich" ));
		temperatures.add( new LabeledDataPoint( 29, "Frankfurt/M." ));
		temperatures.add( new LabeledDataPoint( 27, "Leipzig" ));
		temperatures.add( new LabeledDataPoint( 27, "Nuremberg" ));
		temperatures.add( new LabeledDataPoint( 29, "Stuttgart" ));
		temperatures.add( new LabeledDataPoint( 25, "Rostock" ));
		
		// now we're comparing Ward's method to
		// the Furthest Neighbour method
		LinkageMethod ward = new WardsMethod();
		LinkageMethod neighbour = new FurthestNeighbour();
		
		// we want to have three clusters of temperature
		// regions
		int clusterCount = 3;
		
		// let's cluster!
		List<Cluster> wardResults = HierarchicalClusterer.cluster(
				temperatures, ward,	clusterCount);
		List<Cluster> neighbourResults = HierarchicalClusterer.cluster(
				temperatures, neighbour,	clusterCount);

		// let's take a look at the results, this
		// time we want the data points of the clusters only,
		// hierarchical structure is too geeky for us...
		System.out.println("Ward's Method:");
		for ( Cluster cl : wardResults ) {
			System.out.println(cl.getLeavesOrSelf());
		}
		System.out.println("Furthest Neighbour Method:");
		for ( Cluster cl : neighbourResults ) {
			System.out.println(cl.getLeavesOrSelf());
		}
		
		Cluster topCluster = HierarchicalClusterer.cluster(
				temperatures, ward);
		
		System.out.println(topCluster);

	}

}
