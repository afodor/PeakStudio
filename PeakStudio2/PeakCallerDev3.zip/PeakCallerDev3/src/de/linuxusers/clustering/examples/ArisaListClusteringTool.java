/*
Copyright (C) 2007 Niels Ott
Copyright (C) 2007 Ramon Ziai

This file is part of Clusterlib.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301

*/


package de.linuxusers.clustering.examples;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.FurthestNeighbour;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;

/**
 * A a more complex example program using several
 * linkage methods and labeled data points.
 * Please read the source code.
 * @author Niels Ott
 * @author Ramon Ziai
 * @version $Id: ArisaListClusteringTool.java,v 1.1 2010/07/29 16:23:31 afodor Exp $.
  */
public class ArisaListClusteringTool {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		File filedir = new File("C:\\arisaresults\\Zeizel3042\\diversity\\diversity_SimpleBinBinary1.txt");
		// these are the temparatures in Germany
		// on 2007-07-26 according to wetter24.de
		// (in degree Celsius)
		BufferedReader reader = new BufferedReader(new FileReader(filedir));
		
		reader.readLine();
		
		String nextLine = reader.readLine(); 
		ArrayList<DataPoint> temperatures = new ArrayList<DataPoint>();
		if(nextLine == null)
			throw new Exception("ARISA file EMPTY!");
		//This works!
		while(nextLine != null)
		{
			StringTokenizer st = new StringTokenizer(nextLine);
			String lable = st.nextToken();
			double value = Double.valueOf(st.nextToken());
			value = value * 10;
			value = Math.floor(value) / 10;
			
			temperatures.add( new LabeledDataPoint( value, lable ));
			nextLine = reader.readLine(); 
		}
		// now we're comparing Ward's method to
		// the Furthest Neighbour method
		LinkageMethod ward = new WardsMethod();
		LinkageMethod neighbour = new FurthestNeighbour();
		
		// we want to have three clusters of temperature
		// regions
		int clusterCount = 3;
		
		// let's cluster!
		List<Cluster> wardResults = HierarchicalClusterer.cluster(
				temperatures, ward,	clusterCount);
		List<Cluster> neighbourResults = HierarchicalClusterer.cluster(
				temperatures, neighbour, clusterCount);

		// let's take a look at the results, this
		// time we want the data points of the clusters only,
		// hierarchical structure is too geeky for us...
		System.out.println("Ward's Method:");
		for ( Cluster cl : wardResults ) {
			System.out.println(cl.getLeavesOrSelf());
		}
		System.out.println("Furthest Neighbour Method:");
		for ( Cluster cl : neighbourResults ) {
			System.out.println(cl.getLeavesOrSelf());
		}
		
		Cluster topCluster = HierarchicalClusterer.cluster(
				temperatures, ward);
		
		NewicktreeBuilder s = new NewicktreeBuilder();
		String test = s.getTree(topCluster);
		
		System.out.println("\n\n\n\n" + test);
		Runtime.getRuntime().exec("javaw -jar -Xmx256m "+ "C:\\forester.jar");
	

	}

}
