package dataProvider;

import java.io.Serializable;
import java.util.Arrays;

public class ArrayBasedDataProvider<E> extends DataProvider<E> implements Serializable
{
	private static final long serialVersionUID = 815305714200809634L;
	private final E[] array;
	
	public ArrayBasedDataProvider( E[] array )
	{
		this.array = array;
	}
	
	public E get(int index)
	{
		return array[index];
	}
	
	public int getLength()
	{
		return array.length;
	}
	
	public int search(E key)
	{
		return Arrays.binarySearch(array, key);
	}
}
