package dataProvider;

import java.io.Serializable;

/*
 * Provides a read-only view of an array like data structure
 */
public abstract class DataProvider<E> implements Serializable
{
	public abstract int getLength();
	public abstract E get(int index);
	public abstract int search(E key);
	
}
