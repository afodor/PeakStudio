package metaData;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import experimentSets.FsaFileDescriptor;
import experimentSets.Spectra;

import utils.TabReader;
import viewer.FsaFrame;
import viewer.FsaPanel;

public class MetaData
{
	private final static String NA_STRING = "NA";
	
	
	private static String returnStringOrNA(String s) 
	{
		if( s== null || s.trim().length() == 0 )
			return NA_STRING;
		
		return s;
	}
	
	/*
	 * Todo:  Need friendly error messages if metadata is not in the correct format
	 */
	public static void parseFile(File file, FsaFrame frame) throws Exception
	{
		BufferedReader reader = new BufferedReader(new FileReader(file));
		TabReader tReader = new TabReader(reader.readLine());
		List<String> headers = new ArrayList<String>();
		
		//skip the first token which should say something like "Filenames"
		if( tReader.hasMore() )
			tReader.nextToken();
		
		while( tReader.hasMore())
		{
			headers.add(returnStringOrNA(tReader.nextToken() ));
		}
		
		String nextLine = reader.readLine();
		
		while(nextLine != null)
		{
			tReader = new TabReader(nextLine);
			String name = returnStringOrNA(tReader.nextToken());
			
			if( name.toLowerCase().endsWith(".fsa"))
				name = name.substring(0, name.length() -4 );
			
			FsaFileDescriptor fsa = frame.getAFileDescriptor(name);
			
			if( fsa != null)
			{
				for( int x=0; x < headers.size(); x++)
				{
					String aString = NA_STRING;
					
					if( tReader.hasMore() )
						aString = returnStringOrNA(tReader.getNext());
					
					if( ! aString.equals(NA_STRING) && ! headers.get(x).equals(NA_STRING))
					{
						Spectra standSpec = fsa.getStandardSpectra();
						if( standSpec != null)
							standSpec.getMetadataMap().put(headers.get(x), aString);
						
						for( Spectra s : fsa.getDataSpectra() )
							s.getMetadataMap().put(headers.get(x), aString);
					}
				}
			}
			else
			{
				System.out.println("Could not find spectra : " + name);
			}
			
			nextLine = reader.readLine();
			
		}
	}

}
