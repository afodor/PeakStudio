package experimentSets;

import java.awt.image.BufferedImage;

public class CachedBufferedImage
{
	private final BufferedImage image;
	private final int width;
	private final int height;
	private final long nanoTimeStamp;
	
	public CachedBufferedImage(BufferedImage image, int width, int height,
			long nanoTimeStamp)
	{
		this.image = image;
		this.width = width;
		this.height = height;
		this.nanoTimeStamp = nanoTimeStamp;
	}
	
	public BufferedImage getImage()
	{
		return image;
	}
	
	public int getWidth()
	{
		return width;
	}
	
	public int getHeight()
	{
		return height;
	}
	
	public long getNanoTimeStamp()
	{
		return nanoTimeStamp;
	}
	
}
