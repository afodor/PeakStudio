package experimentSets;

import java.io.File;
import java.io.Serializable;
import java.util.List;

public class StandardWeights implements Serializable
{
	private static final long serialVersionUID = 7084437101874993299L;
	private String name;
	//private List<Integer> weights = null;
	private List<Short> weights = null;
	private String filePath;
	
	
	public StandardWeights(File f, List<Short> weights)
	{
		this.name = f.getName();
		this.filePath = f.getAbsolutePath();
		this.weights = weights;
	}
	public StandardWeights(String name, List<Short> weights)
	{
		this.name = name;
		this.weights = weights;
		//this.filePath = filePath;
	}
	public String getName() 
	{
		return name;
	}
	
	public String getFilePath()
	{
		return filePath;
	}
	
	public void setFilePath(String path)
	{
		this.filePath = path;
	}
	public void setName(String name)
	{
		this.name = name;
	}

	public List<Short> getWeights() 
	{
		return weights;
	}

	public void setWeights(List<Short> weights) 
	{
		this.weights = weights;
	}


}
