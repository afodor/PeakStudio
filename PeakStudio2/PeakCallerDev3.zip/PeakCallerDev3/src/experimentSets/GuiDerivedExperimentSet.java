package experimentSets;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import peakCaller.DefaultStandardPeakParameterSet;
import peakCaller.OTUPeakParameterSet;
import peakCaller.ParameterSet;

public class GuiDerivedExperimentSet extends AbstractExperimentSet implements Serializable
{
	private static final long serialVersionUID = -4778429052493631665L;
	private transient List<FsaFileDescriptor> usersList = new ArrayList<FsaFileDescriptor>();
	private String name;
	
	public List<FsaFileDescriptor> getUsersList() 
	{
		return usersList;
	}
	
	public void setUsersList(List<FsaFileDescriptor> usersList) 
	{
		this.usersList = usersList;
	}
	
	
	@Override
	public HashMap<String, String> getBadFSAFileNames() 
	{
		// todo:  make it so the user can add bad files
		return new HashMap<String, String>();
	}

	@Override
	public List<FsaFileDescriptor> getFileDescriptors()
	{
		return usersList;
	}
	
	public ParameterSet getLadderParameterSet() 
	{
		return new DefaultStandardPeakParameterSet();
	}
 
	@Override
	public ParameterSet getMainDataParameterSet() 
	{
		// user should be able to tweak this
		return new OTUPeakParameterSet();
	}

	@Override
	public String getName() 
	{
		return name;
	}
	
	
	public void setName(String name) 
	{
		this.name = name;
	}

	@Override
	public List<List<Spectra>> getSampleRuns() throws Exception 
	{
		// todo:  Let the user this tweak 
		return null;
	}

	@Override
	public List<List<Spectra>> getTechnicalReplicates() throws Exception 
	{
		// todo: let the user set these
		return null;
	}

	
 
}
