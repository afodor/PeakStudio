package experimentSets;

import java.util.ArrayList;
import java.util.List;

import dataProvider.DataProvider;

import peakCaller.ParameterSet;
import utils.Regression;

public class PeakScavanger
{
	public static enum Phase{ NON_PEAK, UP_PEAK, INTER_PEAK, DOWN_PEAK };
	
	private double maxUpSlope = 0;
	private double maxDownSlope = 0;
	private int peakInterval =0;
	private int minValue = Integer.MAX_VALUE;
	private int maxValue = Integer.MIN_VALUE;
	
	private Phase phase = Phase.NON_PEAK;
	
	private final int startIndex;
	private final ParameterSet parameterSet;
	private final Spectra parent;
	
	public void setPhase(Phase phase)
	{
		this.phase = phase;
	}
	
	public Phase getPhase()
	{
		return phase;
	}
	
	public int getStartIndex()
	{
		return startIndex;
	}
	
	public PeakScavanger(Spectra parent, int startIndex, ParameterSet parameterSet)
	{
		this.parent = parent;
		this.startIndex = startIndex;
		this.parameterSet=parameterSet;
	}
	
	private static double getSlopeForNextN( DataProvider<Short> data, int startIndex, int numToGet )
	throws Exception
	{
		List<Number> l1 = new ArrayList<Number>();
		List<Number> l2 = new ArrayList<Number>();
		
		int i = 1;
		while( startIndex < data.getLength()&& numToGet >0 )
		{
			l1.add(i);
			l2.add(data.get(startIndex));
			startIndex++;
			numToGet--;
			i++;		
		}
		
		Regression r = new Regression();
		r.fitFromList(l1, l2, new ArrayList<Number>(), false);
		return r.getB();
	}

	/*
	 * Returns null if the feature is not ready to be called
	 */
	public Feature scavage(DataProvider<Short> data, int index, List<Feature> peakList)
	throws Exception
	{
		double slope = getSlopeForNextN(data, index, parameterSet.getRegressionWindowSize());
		maxValue = Math.max(maxValue, data.get(index));
		minValue = Math.min(minValue, data.get(index));
		
		if( phase == Phase.NON_PEAK)
		{
			// this is the end of a non-phase transitioning to peak
			// the user should make a new PeakScavanger, set the
			// phase to UP_PEAK and re-call to get the next object in the list
			if( slope >= parameterSet.getRequiredPositiveSlope())
			{
				return new Feature(parent, startIndex, index, Feature.FeatureType.NON_PEAK );
			}
			else
			{
				return null;
			}
		} 
		
		
		if (phase == Phase.UP_PEAK )
		{
			if( slope <= 0 )
			{
				phase =Phase.INTER_PEAK;
			}
			else
			{
				maxUpSlope = Math.max(slope,maxUpSlope);
			}
			
			return null;
		}
		
		if ( phase == Phase.INTER_PEAK )
		{
			peakInterval++;
			
			if( slope <= parameterSet.getRequiredNegativeSlope())
			{
				peakInterval =0;
				phase = Phase.DOWN_PEAK;
				maxDownSlope= Math.min(slope, maxDownSlope);
			}
			else if( peakInterval > parameterSet.getMaxInterslopeDistance())
			{
				return new Feature(parent,startIndex, index, Feature.FeatureType.INTERSLOPE_INTEVAL_TOO_WIDE);
			}
			else if ( slope > parameterSet.getRequiredPositiveSlope())
			{
				return new Feature(parent,startIndex,index, Feature.FeatureType.TWO_UPSLOPES_IN_A_ROW);
			}
			
			return null;
		}
		
		
		if ( phase == Phase.DOWN_PEAK )
		{
			if( slope >=0)
			{
				if( ! parameterSet.isOverThreshold(
						maxValue - minValue, peakList.size(), peakList) )
				{
					return new Feature( parent,startIndex, index, Feature.FeatureType.BELOW_HEIGHT_THRESHOLD );
				}
				else if( ! parameterSet.isOverRequiredPeakWidth(index-startIndex, peakList)) 
				{
					return new Feature( parent,startIndex, index, Feature.FeatureType.BELOW_WIDTH_THRESHOLD);
				
				}else if(parameterSet.hasAbruptJump(startIndex, index,  data))
				{
					return new Feature( parent,startIndex, index, Feature.FeatureType.ABRUPT_JUMP);
				}
				else //everything is ok!
				{
					Feature aPeak = 
						new Feature( parent,startIndex, index,Feature.FeatureType.PEAK);
					peakList.add(aPeak);
					return aPeak;
				}
			}
			else
			{
				maxDownSlope= Math.min(slope, maxDownSlope);
				return null;
			}
		}
		
		throw new Exception("Logic error " + phase);  // must be in one of the 4 phases
	}

}
 