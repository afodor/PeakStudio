package experimentSets;

import java.io.File;
import java.io.Serializable;
import java.util.List;

import dataProvider.ArrayBasedDataProvider;
import dataProvider.DataProvider;

/*
 * Describes a single FSA file
 */
public abstract class AbstractFSAFileDescriptor implements Serializable
{
	private static final long serialVersionUID = 3423923766171489829L;
	
	abstract public File getFSAFile();
	private Float[] basePairCalls = null;
	private DataProvider<Float> basePairCallWrapper = null;
	public abstract AbstractExperimentSet getExperimentSet();
	
	/*
	 * If generateBasePairCalls() has not been called, this returns null
	 * 
	 * Otherwise returns the results of the last time generateBasePairCalls was invoked.
	 * 
	 * Not thread safe.
	 */
	public DataProvider<Float> getLastSetOfBasePairCalls()
	{
		return basePairCallWrapper;
	}
	
	public String getFileNamePrefix() throws Exception
	{
		String name = getFSAFile().getName();
		
		if( name.indexOf(".") != -1)
			name = name.substring(0, name.lastIndexOf("."));
		
		return name;
	}
	
	public void callAllPeaks( ) throws Exception
	{
		getStandardSpectra().callFeatures();
		generateBasePairCalls(false);
		
		for( Spectra sp : getDataSpectra() )
		{
			sp.callFeatures();
		}
	
	}

	/*
	 * If (forceNewPeakCalls) then a new set of peak calls is always generated.
	 * 
	 * Otherwise spectra.callPeaks(ps) is only called if it has not been previously invoked.
	 * 
	 * If the standard peaks have already been called and !forceNewPeakCalls, ps may be null
	 * 
	 * Not thread safe.  Not even close to thread safe as while this process is executing,
	 * the internal datastructures may be intermediate between the old peak calls and the new
	 * peak calls
	 */
	public DataProvider<Float> generateBasePairCalls(boolean forceNewPeakCalls) throws Exception
	{
		Spectra s = null;
		try 
		{
			s = getStandardSpectra();
			s.setIsDataGood(true);
			s.setQcStatus("Good Data");
		} 
		catch (Exception e) 
		{
			s.setIsDataGood(false);
			s.setQcStatus("Bad Data");
		}
		
		List<Feature> peaks= s.getLastGeneratedPeakSet();
			
		if( peaks== null || forceNewPeakCalls)
			peaks= s.callFeatures();
			
		List<Short> standards = getSizeStandards();
			
		double incrementSum=0;
		int incrementN = 0;
		int numMatch = Math.min(peaks.size(), standards.size());
			
		if( standards.size() < 2)
		{
			s.setIsDataGood(false);
			s.setQcStatus("Lacking standard peaks");
		}
		if( peaks.size() < 2)
		{
			s.setIsDataGood(false);
			s.setQcStatus("Lacking data peaks");
		}
			
		//DataProvider<Integer> data = s.getData();
		//DataProvider<Short> data = s.getData();
		DataProvider<Short> data;
		if(s.getIsSmoothed() && s.isShowSmoothed())//if(s.getIsStandard() || !s.getIsSmoothed())
			data = s.getSmoothedData();
		else
			data = s.getData();
		
		this.basePairCalls = new Float[data.getLength()];
		
		for( int x=0; x < this.basePairCalls.length; x++)
			basePairCalls[x] = 0f;
		
		this.basePairCallWrapper = new ArrayBasedDataProvider<Float>(basePairCalls);
		
		for( int x=1; x < numMatch; x++)
		{
				float leftVal = standards.get(x-1);
				float rightVal = standards.get(x);
				Feature leftPeak = peaks.get(x-1);
				Feature rightPeak = peaks.get(x);
				
				for( int y= leftPeak.getIndexOfHighestPeak(); y <= rightPeak.getIndexOfHighestPeak(); y++ )
				{
					int distance = rightPeak.getIndexOfHighestPeak()-leftPeak.getIndexOfHighestPeak();
					
					float increment = (rightVal - leftVal) * 
					(y - leftPeak.getIndexOfHighestPeak())/distance;
					
					float basePairVal = leftVal + increment; 
					
					basePairCalls[y] = basePairVal;
					if( y > 1 )
					{
						incrementSum += basePairVal - basePairCalls[y-1];
						incrementN++;
					}
				}
			}
			
			// expand past the first and last peak
			double averageIncrement = incrementSum/ incrementN;
			
			Feature firstPeak = peaks.get(0);
			float ladderValue = standards.get(0);
			
			for( int x = firstPeak.getIndexOfHighestPeak() -1; x >=0; x--)
			{
				ladderValue -= averageIncrement;
				basePairCalls[x] = ladderValue;
			}
			
			Feature lastPeak = peaks.get(numMatch -1);
			ladderValue = standards.get(numMatch -1);
			
			for( int x= lastPeak.getIndexOfHighestPeak() +1; x < data.getLength(); x++)
			{
				ladderValue += averageIncrement;
				basePairCalls[x] = ladderValue;
			}
		
		
		return basePairCallWrapper;
	}
	
	/*
	 * Can be null if no standards were run.
	 */
	abstract public List<Short> getSizeStandards();
	abstract public void setSizeStandards(List<Short> list);
	abstract public String getSizeStandardsName();
	abstract public void setSizeStandardsName(String name);
	abstract public void setSizeStndFilePath(String path);
	abstract public StandardWeights getStndWeightsObject();
	abstract public void setStndWeightsObject(StandardWeights sw);
	/*
	 * Typically 105 or 4. -1 if no standards were run
	 */
	//abstract public int getStandardChannel();
	abstract public byte getStandardChannel();
	/*
	 * Can be null if only the standards were run
	 */
	//public abstract List<Integer> getDataChannels();
	public abstract List<Byte> getDataChannels();
	
	//private Spectra standardSpectra = null;
	
	
	abstract public Spectra getStandardSpectra() throws Exception;
	abstract public void setStandardSpectra(Spectra s);
	
	abstract public List<Spectra> getDataSpectra()throws Exception;
	
	abstract public void setDataSpectra(List<Spectra> s);
	
	
	/*
	 * Guess the location of the middle peak by interpolation of
	 * the left and the right peaks.
	 * 
	 * Used for QA/QC.  
	 */
	public float predictLocation(
			int leftPeak,int middlePeak, int rightPeak) 
		throws Exception
	{

		List<Short> standards = getSizeStandards();
		
		float lowVal = standards.get(leftPeak);
		float middleVal = standards.get(middlePeak);
		float rightVal = standards.get(rightPeak);
		
		float fraction = (middleVal - lowVal) / (rightVal -lowVal);
		
		List<Feature> peaks = getStandardSpectra().getLastGeneratedPeakSet();
		
		if( rightPeak +1 > peaks.size())
			return 100;
		
		int leftLocation = peaks.get(leftPeak).getIndexOfHighestPeak();
		int rightLocation = peaks.get(rightPeak).getIndexOfHighestPeak();
		
		int predictedLocation =(int)
			(leftLocation + fraction*(rightLocation-leftLocation) + 0.5);
		
		int actualLocation = peaks.get(middlePeak).getIndexOfHighestPeak();
		
		DataProvider<Float> basePairs = getLastSetOfBasePairCalls();
		
		return Math.abs( basePairs.get(predictedLocation) - basePairs.get(actualLocation));
		
	}
	
	public Float getStandardsPeakQANumber() throws Exception
	{
		if( getStandardSpectra() == null )
			return null;
		
		float sum =0;
		int n=0;
		
		List<Feature> peaks = getStandardSpectra().getLastGeneratedPeakSet();
		
		if( peaks == null)
			return null;
		
		List<Short> standards = getSizeStandards();
		
		if( standards == null)
			return null;
		
		int stopPoint = Math.min(peaks.size(), standards.size()) -2;
			
		for( int x=0; x < stopPoint; x++)
		{
			sum += predictLocation(x, x+1, x+2);
				n++;
		}
		
		return sum / n;
	}
}
