package experimentSets;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import dataProvider.DataProvider;
import flanagan.interpolation.CubicSpline;

public class Feature implements Serializable
{
	private static final long serialVersionUID = 6180942983580380428L;

	public static enum FeatureType{ 
		IGNORED_LEADING, PEAK, NON_PEAK, INTERSLOPE_INTEVAL_TOO_WIDE, TWO_UPSLOPES_IN_A_ROW,
			BELOW_HEIGHT_THRESHOLD, BELOW_WIDTH_THRESHOLD, ABRUPT_JUMP,
		IGNORED_TRAILING, USER_REMOVED ,USER_ADDED}
	
	private int startIndex;
	private int finalIndex;
	private FeatureType featureType;
	private final Spectra parent;
	private int indexOfHighestPeak = -1;
	private int minValue = Integer.MAX_VALUE;
	private int maxValue = Integer.MIN_VALUE;
	private float averageValue;
	private double zscore = Double.MAX_VALUE;
	
	
	private float maxDisplayed = Float.MIN_VALUE;
	
	public double getZscore()
	{
		if(zscore == Double.MAX_VALUE)
			this.parent.calculateFeatureZscore();
		return this.zscore;
	}
	
	public void setZscore(double z)
	{
		this.zscore = z;
	}
	
	public double getAUC(boolean indexSpace)
	{
		if(indexSpace)
		{
			return calculateAUCindex();
		}
		else
		{
			return calculateAUCbp();
		}
	}
	
	public float getMaxDisplayed()
	{
		return maxDisplayed;
	}
	
	public int getHeight()
	{
		return this.maxValue - this.minValue;
	}
	
	public void setMaxDisplayedIfAppropriate(float inMax)
	{
		maxDisplayed = Math.max(inMax, maxDisplayed);
	}
	
	public void resetMaxDisplayed()
	{
		this.maxDisplayed = Float.MIN_VALUE;
	}
	void calculateStatistics(DataProvider<Short> data)
	{
		float sum = 0;
		int n =0 ;
		
		for( int x=startIndex; x < finalIndex; x++)
		{
			sum+= data.get(x);
			n++;
			
			if( data.get(x) > maxValue )
			{
				maxValue = data.get(x);
				indexOfHighestPeak = x;
			}
			
			minValue = Math.min(data.get(x), minValue);
		}
		
		averageValue = sum / n;
	}
	
	public int getIndexOfHighestPeak()
	{
		return indexOfHighestPeak;
	}
	public void resetMaxMinValues()
	{
		this.maxValue = Integer.MIN_VALUE;
		this.minValue = Integer.MAX_VALUE;
	}
	public int getMinValue()
	{
		return minValue;
	}
	
	public int getMaxValue()
	{
		return maxValue;
	}
	
	public float getAverageValue()
	{
		return averageValue;
	}
	
	public Spectra getParentSpectra()
	{
		return parent;
	}
	
	public static int getFeatureNumber(List<Feature> features, int xPos)
	{
		for( int x=0; x < features.size(); x++)
		{
			Feature f = features.get(x);
			
			if( xPos >= f.minValue && xPos <= f.maxValue)
				return x;
		}
			
		
		return -1;
	}
	
	// start index is inclusive; finalIndex is not
	public Feature(Spectra parent, int startIndex, int finalIndex, FeatureType featureType)
	{
		this.parent = parent;
		this.startIndex = startIndex;
		this.finalIndex = finalIndex;
		this.featureType = featureType;
	}
	
	/**************************************************************
	 * Interpolation using cubic splines and data for each feature
	 * in Index space to calculate Area Under the Curve
	 **************************************************************/
	private double calculateAUCindex()
	{
		double nVal = 0;
		double sum = 0;
		
		List<Integer> x = new ArrayList<Integer>();
		List<Integer> fx = new ArrayList<Integer>();
		
		int startIndex,endingIndex;
		
		startIndex = getStartIndex();
		endingIndex = getFinalIndex();
		for(int index=startIndex; index<endingIndex; index++)
		{
			int fofx;
			if(this.parent.getIsSmoothed() && this.parent.isShowSmoothed())
				fofx = this.parent.getSmoothedData().get(index);
			else 
				fofx = this.parent.getData().get(index);
			
			x.add(index);
			if( fofx > this.parent.getParameterSet().getPeakThreshold())
			{
				fx.add(fofx);
			}
			else
				fx.add(0);
			
		}
		
		double[] xVal = new double[x.size()];
		double[] yVal = new double[fx.size()];
		for(int index = 0; index<x.size();index++)
		{
			xVal[index] = x.get(index);
			yVal[index] = fx.get(index);
		}
		
		if(x.size() >= 3)
		{
			CubicSpline cs = new CubicSpline(xVal, yVal);
			double strIndex = cs.getXmin();
			double endIndex = cs.getXmax();
			
			for(double index=strIndex; index<endIndex; index+=0.01)
			{
				sum+= cs.interpolate(index);
				nVal++;
			}
			double width = (endIndex-strIndex)/nVal;
			return sum*width;
		}
		else
			return 0.0;	
	}
	/*************************************************************
	 * Interpolation using cubic splines and data for each feature
	 * in BasePair space to calculate Area Under the Curve
	 *************************************************************/
	private double calculateAUCbp()
	{
		double nVal = 0;
		float a = this.parent.getBasePairCalls().get(getStartIndex());
		float b = this.parent.getBasePairCalls().get(getFinalIndex());
		double sum = 0;
		
		List<Integer> x = new ArrayList<Integer>();
		List<Integer> fx = new ArrayList<Integer>();
		for(int index=getStartIndex(); index<getFinalIndex(); index++)
		{
			int fofx;
			if(this.parent.getIsSmoothed() && this.parent.isShowSmoothed())
				fofx = this.parent.getSmoothedData().get(index);
			else 
				fofx = this.parent.getData().get(index);
			x.add(index);
			fx.add(fofx);
		}
		
		double[] xVal = new double[x.size()];
		double[] yVal = new double[fx.size()];
		for(int index = 0; index<x.size();index++)
		{
			xVal[index] = this.parent.getBasePairCalls().get(x.get(index));
			yVal[index] = fx.get(index);
		}
		
		if(x.size() >= 3)
		{
			CubicSpline cs = new CubicSpline(xVal, yVal);
			double stop = b-0.1;
			
			for(double index=a; index<stop-0.1; index+=0.01)
			{
				nVal++;
				sum+= cs.interpolate(index);
			}
			if(nVal == 0)
				nVal = 1;
			double width = (b-a)/nVal;

			if(Double.isNaN(sum*width))
				return 0.0;
			else
				return sum*width;	
		}
		else
			return 0.0;	
	}
	public void setStartIndex(int startIndex)
	{
		parent.clearImageCache();
		this.startIndex = startIndex;
	}

	public void setFinalIndex(int finalIndex)
	{
		parent.clearImageCache();
		this.finalIndex = finalIndex;
	}

	public void setFeatureType(FeatureType featureType)
	{
		parent.clearImageCache();
		this.featureType = featureType;
	}

	public int getStartIndex()
	{
		return startIndex;
	}
	
	public int getFinalIndex()
	{
		return finalIndex;
	}
	
	public FeatureType getFeatureType()
	{
		return featureType;
	}	
}
