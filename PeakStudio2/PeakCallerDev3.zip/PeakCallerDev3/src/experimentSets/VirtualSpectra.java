package experimentSets;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import peakCaller.ParameterSet;

public class VirtualSpectra 
{

	/*
	/**
	 * This is a virtual object to hold the relevant info to create a virtual sspectra
	 * from TRFLP data.  
	 * 
	 *  feed in a list of Spectra.
	 *  
	 *  Create a long virtual spectra, using each of spectra from the list created.
	 *  
	 *  You then use this virtual spectra to draw pretty pictures and do cluster analysis, etc....elsewhere
	 */
	
	/*
	List<Spectra> originalSmallerSpectra;  // this is for the list you bring in...
	String name;
	int numOfsamples;
	int sizeOfVirtualSpectra;
	int[] intensityData;
	float[] basePairData;
	Spectra virtualSpectra;
	
	
	public VirtualSpectra(List<Spectra> originalSmallerSpectra, String name) 
	{
		/*
		this.originalSmallerSpectra = originalSmallerSpectra;
		this.name = name;
		this.numOfsamples = originalSmallerSpectra.size();
		
		this.intensityData = fetchIntensityData(originalSmallerSpectra);
		this.basePairData = generateBasePairData(originalSmallerSpectra);
		
		AbstractFSAFileDescriptor fsa = originalSmallerSpectra.get(0).getFileDescriptor();
		int falseDataChannel = -1;
		ParameterSet ps = originalSmallerSpectra.get(0).getParameterSet();
		
		Spectra spectra =  new Spectra(fsa, falseDataChannel, intensityData, ps);
		
		try 
		{
			spectra.callPeaks();
		}
		
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		virtualSpectra = spectra;
		*/
	}
	
/*


	public Spectra getVirtualSpectra() {
		return virtualSpectra;
	}



	private int[] fetchIntensityData(List<Spectra> originalSmallerSpectra2) 
	{
		ArrayList<int[]> dataHolder = new ArrayList<int[]>();
		int size = 0;
		
		System.out.println("Getting VS spectra, the number of spectra is " + originalSmallerSpectra2.size());
		
		for (Spectra s: originalSmallerSpectra2)
		{
			int[] tempArray = s.getData();
			System.out.println("Size of this Spectra array is " +tempArray.length);
			dataHolder.add(tempArray);
			size += tempArray.length;
			System.out.println(" Size is now " + size);
		}
		
		
		int[] bigAssArray = new int[size];
		
		int count = 0;
		for (int[] array : dataHolder)
		{
			for (int i = 0; i < array.length; i++)
			{
				bigAssArray[count] = array[i];
				count++;
			}	
		}
		System.out.println("The BigAss array is now this big:" + bigAssArray.length);
		return bigAssArray;
	}

	private float[] generateBasePairData(List<Spectra> originalSmallerSpectra2) 
	{
		ArrayList<float[]> dataHolder = new ArrayList<float[]>();
		int indexSize = 0;
		
		for (Spectra s: originalSmallerSpectra2)
		{
			float[] tempArray = s.getBasePairCalls();
			dataHolder.add(tempArray);
			indexSize += tempArray.length;
		}
		
		//We are now making a long list of base pair space values. (not yet corrected 
		ArrayList<Float> theBinUnlateredList = new ArrayList<Float>();
		for (int i=0;i<dataHolder.size();i++)
		{
			for(int j=0; j< dataHolder.get(i).length;j++)
			{
				theBinUnlateredList.add(dataHolder.get(i)[j]);
				//System.out.println(dataHolder.get(i)[j]);
			}
			
		}
		
		//System.out.println( " the last BP size was " + tempArray[tempArray.length-1]);
			//System.out.println( " current size is " + size);
			//System.out.println( "Total number of spectra is " + originalSmallerSpectra2.size());
		
		//We now switch the basepair sizes to be bigger as we loop through...
		
		float[] bigAssArray = new float[theBinUnlateredList.size()];
		float bpValue =  theBinUnlateredList.get(0);
		bigAssArray[0] = bpValue;
		float lemming = theBinUnlateredList.get(0);
		
		System.out.println( "The indexSize calc was " + indexSize + " but arraylist size was " + theBinUnlateredList.size());
		for (int i=1;i<theBinUnlateredList.size();i++)
		{
			
			if (theBinUnlateredList.get(i) < lemming)
			{
				bpValue += lemming;
				System.out.println("the lemming is now " + lemming + " and bpValue is " + bpValue);
			}
			bigAssArray[i] = theBinUnlateredList.get(i) +bpValue;
			lemming = theBinUnlateredList.get(i);
		}
		

		return bigAssArray;
	}



	public List<Spectra> getOriginalSmallerSpectra() {
		return originalSmallerSpectra;
	}

	public String getName() {
		return name;
	}


	public int getNumOfsamples() {
		return numOfsamples;
	}


	public int getSizeOfVirtualSpectra() {
		return sizeOfVirtualSpectra;
	}


	public int[] getIntensityData() {
		return intensityData;
	}


	public float[] getBasePairData() {
		return basePairData;
	}



	public static void main(String[] args) 
	{
		

	}
	
	public void writePeaksInBasepairSpaceToFile(String filepath) throws Exception
	{
		File file = new File(filepath);
		
		if (getVirtualSpectra().getPeaks() == null)
			throw new Exception("Must invoked callPeaks(...) first");
		
		float[] basepaircalls = getVirtualSpectra().getBasePairCalls();
		
		if( basepaircalls == null)
			throw new Exception("Must be in basepair space");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.write("peakNum\tpeakStart\tpeakEnd\tpeakMaxIndex\tpeakMinVal\tpeakMaxVal\n");
		
		
		
		for( int x=0; x < getVirtualSpectra().getPeaks().size(); x++)
		{
			Peak p = getVirtualSpectra().getPeaks().get(x);
			
			writer.write((x+1) + "\t");
			writer.write( basepaircalls[p.getStartIndex()] + "\t" );
			//writer.write( basepaircalls[p.getEndIndex()] + "\t");
			//writer.write( basepaircalls[p.getMaxIndex()] + "\t");
			writer.write( p.getMinValue()+ "\t");
			writer.write( p.getMaxValue() + "\n");
		}
		
		writer.flush();  writer.close();
	}
	public void writePeaksInIndexSpace(String filepath)throws Exception
	{
		File file = new File(filepath);
		
		if (getVirtualSpectra().getPeaks() == null)
			throw new Exception("Must invoked callPeaks(...) first");
		
		float[] basepaircalls = this.getBasePairData();
		
		if( basepaircalls == null)
			throw new Exception("Must be in basepair space");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		writer.write("peakNum\tpeakStart\tpeakEnd\tpeakMaxIndex\tpeakMinVal\tpeakMaxVal\n");
		
		for( int x=0; x < getVirtualSpectra().getPeaks().size(); x++)
		{
			Peak p = getVirtualSpectra().getPeaks().get(x);
			
			writer.write((x+1) + "\t");
			//writer.write( basepaircalls[p.getStartIndex()] + "\t" );
			//writer.write( basepaircalls[p.getEndIndex()] + "\t");
			//writer.write( basepaircalls[p.getMaxIndex()] + "\t");
			writer.write(p.getStartIndex()+"\t");
			writer.write(p.getEndIndex()+"\t");
			writer.write( p.getMinValue()+ "\t");
			writer.write( p.getMaxValue() + "\n");
		}
		
		writer.flush();  writer.close();
		
		
	}

*/
