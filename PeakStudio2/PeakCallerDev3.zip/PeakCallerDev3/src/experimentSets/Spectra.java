package experimentSets;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import dataProvider.ArrayBasedDataProvider;
import dataProvider.DataProvider;


import experimentSets.Feature.FeatureType;
import flanagan.analysis.CurveSmooth;
import flanagan.analysis.Regression;
import fsa.FSAParser;

import peakCaller.BaseLineCorrection;
import peakCaller.ParameterSet;
import utils.Avevar;

public class Spectra implements Serializable
{
	private static final long serialVersionUID = 1376852412238291609L;

	private final AbstractFSAFileDescriptor fileDescriptor;
	private final byte dataChannel;
	private String name;
	private int spectraMaxVal = Integer.MIN_VALUE;
	private int spectraMinVal = Integer.MAX_VALUE;
	private boolean graphIsShown = false;
	private boolean isStandard = false;
	private boolean isDataGood = true;
	private Color graphColor = Color.GRAY;
	private Color peakColor = Color.RED;
	private Color possiblePeakColor = Color.BLUE;
	private Color selectedPeakColor = Color.BLACK;
	private ParameterSet parameterSet;
	private boolean isVisibleInTable = true;
	private HashMap<String, String> metadataMap = new HashMap<String, String>();
	private List<Feature> featureList = null;
	private Short[] data;
	private Short[] smoothData;
	private transient float[] sumPeaks;
	private String qcStatus;
	private String dyeColor;
	private final float STND_ZSCORE_THRESHOLD = 2.9f;
	private transient AtomicReference<CachedBufferedImage> bufferedImage =
		new AtomicReference<CachedBufferedImage>();
	private boolean isSmoothed = false;
	private boolean showSmoothed = false;
	private DataProvider<Short> dataWrapper;
	private DataProvider<Short> smoothDataWrapper;
	
	// used as cache variables to quickly find features without
	// having to search the entire feature list...
	private transient int cumulativeFeatureIndex = -1;
	private transient int cumulativeFeaturePosition = -1;
	
	// used as a temp variable for multiple deletions
	private transient boolean deleteFromList = false;
	
	public void setDeleteFromList(boolean deleteFromList)
	{
		this.deleteFromList = deleteFromList;
	}
	
	public boolean isDeleteFromList()
	{
		return deleteFromList;
	}
	
	public void setQcStatus(String qcStatus)
	{
		this.qcStatus = qcStatus;
	}
	
	public String getQcStatus()
	{
		bufferedImage.set(null);
		return qcStatus;
	}
	
	public Color getSelectedPeakColor()
	{
		bufferedImage.set(null);
		return selectedPeakColor;
	}
	public boolean getIsSmoothed()
	{
		return this.isSmoothed;
	}
	public void setIsSmoothed(boolean smoothed)
	{
		this.isSmoothed = smoothed;
	}
	public boolean isShowSmoothed()
	{
		return this.showSmoothed;
	}
	public void setShowSmoothed(boolean show)
	{
		this.showSmoothed = show;
	}
	public void setSelectedPeakColor(Color selectedPeakColor)
	{
		bufferedImage.set(null);
		this.selectedPeakColor = selectedPeakColor;
	}
	
	public void resetFeatureCrawler()
	{
		cumulativeFeatureIndex = -1;
		cumulativeFeaturePosition = -1;
	}
	
	private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException
	{
		in.defaultReadObject();
		bufferedImage = new AtomicReference<CachedBufferedImage>();
	}
	
	/*
	 *   To use this first call resetFeatureCrawler()
	 *   Then call getAFeatureFromCumulativeCralwer(position)
	 *   where position is always greater than the last time you called that method.
	 */
	public Feature getAFeatureFromCumulativeCralwer( int position )
	{
		Feature currentFeature = null;
		
		if( cumulativeFeaturePosition == -1 )
		{
			cumulativeFeatureIndex = 0;
			cumulativeFeaturePosition = 0;
		}
		
		if( position < cumulativeFeaturePosition)
			return featureList.get(cumulativeFeatureIndex);
		
		currentFeature = featureList.get(cumulativeFeatureIndex);
		
		while(cumulativeFeaturePosition < position)
		{
			cumulativeFeaturePosition++;
			
			if( cumulativeFeaturePosition >= currentFeature.getFinalIndex())
			{
				cumulativeFeatureIndex++;
				
				if( cumulativeFeatureIndex>= featureList.size())
					return null;
				
				currentFeature = featureList.get(cumulativeFeatureIndex);
			}
			
			if( cumulativeFeaturePosition >= currentFeature.getStartIndex() 
					&& cumulativeFeaturePosition <= currentFeature.getFinalIndex() )
			{
				cumulativeFeaturePosition = currentFeature.getFinalIndex();
				return currentFeature;
			}	
		}
		
		return null;
		
	}
	
	public List<Feature> getFeatureList()
	{
		return featureList;
	}
	
	
	public HashMap<String, String> getMetadataMap()
	{
		return metadataMap;
	}

	public boolean isVisibleInTable()
	{
		return isVisibleInTable;
	}

	public void setIsVisibleInTable(boolean b)
	{
		this.isVisibleInTable = b;
	}

	public boolean graphIsShown()
	{
		return graphIsShown;
	}

	public boolean getIsStandard()
	{
		return isStandard;
	}

	public void setIsStandard(boolean x)
	{
		isStandard = x;
	}

	public void setIsDataGood(boolean x)
	{
		this.isDataGood = x;
	}

	public boolean isDataGood()
	{
		return this.isDataGood;
	}

	public void setGraphIsShown(boolean graphIsShown)
	{
		this.graphIsShown = graphIsShown;
	}

	public Color getGraphColor()
	{
		return graphColor;
	}

	public void setGraphColor(Color graphColor)
	{
		this.graphColor = graphColor;
	}

	public Color getPeakColor()
	{
		return peakColor;
	}

	public void setPeakColor(Color peakColor)
	{
		bufferedImage.set(null);
		this.peakColor = peakColor;
	}

	public Color getPossiblePeakColor()
	{
		return possiblePeakColor;
	}

	public void setPossiblePeakColor(Color possiblePeakColor)
	{
		this.possiblePeakColor = possiblePeakColor;
		bufferedImage.set(null);
	}

	public DataProvider<Float> getBasePairCalls()
	{
		return  this.fileDescriptor.getLastSetOfBasePairCalls();
	}

	/*
	 * returns the results of the last time callPeaks(...) was called
	 * 
	 * returns null if callPeaks(...) has not been called.
	 * 
	 * Not thread safe.
	 */
	public List<Feature> getLastGeneratedPeakSet()
	{
		if (featureList == null)
			return null;

		List<Feature> list = new ArrayList<Feature>();

		for (Feature f : featureList)
			if (f.getFeatureType() == Feature.FeatureType.PEAK || f.getFeatureType() == Feature.FeatureType.USER_ADDED)
				list.add(f);

		return list;
	}

	public void clearImageCache()
	{
		if( this.bufferedImage != null )
			this.bufferedImage.set(null);
	}
	
	public void calculateFeatureZscore()
	{
		List<Feature> filterFeatures = new ArrayList<Feature>();
		List<Float> areas = new ArrayList<Float>();
		
		for(Feature f: this.featureList)
		{
			if(!f.getFeatureType().equals(Feature.FeatureType.NON_PEAK) && f.getAUC(true) > 1)
			{
				filterFeatures.add(f);
				
				areas.add((float)f.getAUC(true));
				//areas.add((float)f.getStndArea(sum));
				//System.out.println(f.getAUC(true));
			}
		}
		
		
		Avevar av = new Avevar(areas);
		//double mean = av.getAve();
		double sd = Math.sqrt(av.getVar());
		for(Feature f: this.featureList)
		{
			//double z = (f.getAUC(true)-mean)/sd;
			f.setZscore((f.getAUC(true))/sd);
			
		}
	}
	
	public void autoAdjustPeaks() throws Exception
	{
		int peakCount = 0;
		float sd_threshold = getParameterSet().getStandardDev();
		//System.out.println("SD: "+getParameterSet().getStandardDev());
		for(Feature f: this.featureList)
		{
			if(Math.abs(f.getZscore()) > sd_threshold && f.getAUC(true) > 1)//STND_ZSCORE_THRESHOLD && f.getAUC(true) > 1)
			{
				
				f.setFeatureType(Feature.FeatureType.PEAK);
				peakCount++;
			}
			else
				f.setFeatureType(Feature.FeatureType.NON_PEAK);
		}
		int numWeights = this.fileDescriptor.getSizeStandards().size();
		if(peakCount != numWeights)
		{
			if(peakCount > numWeights)
			{	
				for(int x=0; x<this.featureList.size(); x++)
				{
					if(this.featureList.get(x).getFeatureType().equals(Feature.FeatureType.PEAK) && 
							this.featureList.get(x).getHeight() < getParameterSet().getPeakThreshold() && this.featureList.get(x).getZscore() < 0)
					{
						//System.out.print(x+" "+this.featureList.get(x).getFeatureType().toString()+"\t");
						this.featureList.get(x).setFeatureType(Feature.FeatureType.NON_PEAK);
						//System.out.println(this.featureList.get(x).getFeatureType().toString());
					}		
				}
			}
			else
			{
				for(int x=0; x<this.featureList.size(); x++)
				{
					//System.out.println(x+" "+this.featureList.get(x).getHeight()+"/"+getParameterSet().getPeakThreshold());
					if(this.featureList.get(x).getFeatureType().equals(Feature.FeatureType.NON_PEAK) && 
							this.featureList.get(x).getHeight() >= getParameterSet().getPeakThreshold() && this.featureList.get(x).getZscore() > 0)
					{
						this.featureList.get(x).setFeatureType(Feature.FeatureType.PEAK);
					}
				}
				
			}
		}
		if(this.fileDescriptor.getStandardsPeakQANumber() > 0.5)
		{
			for(int x=0; x<this.featureList.size() && this.fileDescriptor.getStandardsPeakQANumber() > 0.5; x++)
			{
				//System.out.print(x+" "+this.fileDescriptor.getStandardsPeakQANumber()+" "+this.featureList.get(x).getFeatureType().toString()+"\t");
				if(this.featureList.get(x).getFeatureType().equals(Feature.FeatureType.PEAK))
					this.featureList.get(x).setFeatureType(Feature.FeatureType.NON_PEAK);
				//System.out.println(this.featureList.get(x).getFeatureType().toString());
			}
		}
		peakCount = 0;
		for(Feature f: this.featureList)
		{
			if(f.getFeatureType().equals(Feature.FeatureType.PEAK))
				peakCount++;
		}
		
		if(peakCount < this.fileDescriptor.getSizeStandards().size())
		{
			//System.out.println(peakCount+" "+this.fileDescriptor.getSizeStandards().size());
			float height = getParameterSet().getPeakThreshold();
			for(int x=1; x<this.featureList.size(); x++)
			{
				
				if(this.featureList.get(x-1).getFeatureType().equals(Feature.FeatureType.PEAK))
					height = this.featureList.get(x-1).getHeight();
				//System.out.println(this.featureList.get(x).getHeight()+" / "+height+" = "+this.featureList.get(x).getHeight()/height);
				if( this.featureList.get(x).getZscore() >= sd_threshold-1 && this.featureList.get(x).getHeight()/height >= getParameterSet().getPeakHeightThreshold())//this.featureList.get(x).getAUC(true) / totalArea >= 0.01)
					this.featureList.get(x).setFeatureType(Feature.FeatureType.PEAK);
			}
		}
		else if( peakCount > this.fileDescriptor.getSizeStandards().size())
		{
			for(int x=0; x<this.featureList.size(); x++)
			{
				if(this.featureList.get(x).getZscore() < sd_threshold-1 )
				{
					this.featureList.get(x).setFeatureType(Feature.FeatureType.NON_PEAK);
				}
			}
		}
	
	}
	
	/*
	 * If a previous feature call has happened, that call is disregarded.
	 */
	public List<Feature> callFeatures() throws Exception
	{
		this.featureList = new ArrayList<Feature>();
		List<Feature> peakList = new ArrayList<Feature>();
		DataProvider<Short> dwrap;
		if(getIsSmoothed()&& isShowSmoothed() && !getIsStandard())//if(getIsStandard() || !getIsSmoothed())
			dwrap = this.smoothDataWrapper;
		else
			dwrap = this.dataWrapper;


		int startIndex = parameterSet.getNumToTrimFromBeginning();

		if (startIndex < 0)
			startIndex = 0;

		if (startIndex >= data.length)
			startIndex = data.length - 1;

		if (startIndex != 0)
		{
			Feature f = new Feature(this,0, startIndex,
					Feature.FeatureType.IGNORED_LEADING);
			featureList.add(f);
		}

		int endIndex = data.length - parameterSet.getRegressionWindowSize()
				- parameterSet.getNumToTrimFromEnd();

		if (endIndex < 0)
			endIndex = 0;

		if (endIndex >= data.length)
			endIndex = data.length - 1;

		Feature endFeature = new Feature(this,endIndex, data.length,
				Feature.FeatureType.IGNORED_TRAILING);

		int x = startIndex;
		PeakScavanger ps = new PeakScavanger(this,x, parameterSet);

		while (x < endIndex)
		{
			Feature f = ps.scavage(dwrap, x, peakList);//ps.scavage(dataWrapper, x, peakList);

			if (f != null)
			{
				featureList.add(f);
				ps = new PeakScavanger(this,x, parameterSet);

				if (f.getFeatureType() == FeatureType.NON_PEAK)
				{
					ps.setPhase(PeakScavanger.Phase.UP_PEAK);
				}

				// this point is the beginning of the next feature
				//ps.scavage(dataWrapper, x, peakList);
				ps.scavage(dwrap, x, peakList);
			}

			x++;
		}

		x--;

		if (x > ps.getStartIndex())
			featureList.add(new Feature(this,ps.getStartIndex(), x,
					FeatureType.NON_PEAK));

		featureList.add(endFeature);

		for (Feature f : featureList)
		{
			f.calculateStatistics(dwrap);
			this.spectraMaxVal = Math.max(this.spectraMaxVal, f.getMaxValue());
			this.spectraMinVal = Math.min(this.spectraMinVal, f.getMinValue());
		}
			
		cleanUpPeaks(peakList);
		
		checkThresholds();
		if(this.isStandard)
			calculateFeatureZscore();
		bufferedImage.set(null);
		return this.featureList;

	}

	public void resetStndHeights(boolean smooth)
	{
		this.spectraMaxVal = Integer.MIN_VALUE;
		this.spectraMinVal = Integer.MAX_VALUE;
		DataProvider<Short> dwrap;
		if(smooth)
			dwrap = this.smoothDataWrapper;
		else
			dwrap = this.dataWrapper;
		for(Feature f: featureList)
		{
			f.resetMaxMinValues();
			f.calculateStatistics(dwrap);
			this.spectraMaxVal = Math.max(this.spectraMaxVal,f.getMaxValue());
			this.spectraMinVal = Math.min(this.spectraMinVal,f.getMaxValue());
		}
			
			
	}
	/*
	 * This requires a separate second pass
	 */
	private void checkThresholds()
	{
		List<Feature> peaks = getLastGeneratedPeakSet();
		
		for( int x=0; x < peaks.size()-1; x++ ) 
		{
			Feature f = peaks.get(x);
			if( ! parameterSet.isOverThreshold(f.getMaxValue() - f.getMinValue(), x, peaks) )
			{
				f.setFeatureType(Feature.FeatureType.BELOW_HEIGHT_THRESHOLD);
				peaks.remove(x);
				x--;
			}
		}
	}
	
	private void cleanUpPeaks(List<Feature> peaks)
	{
		// clean up small, insignificant peaks that are likely not the true
		// start of the ladder
		for (int x = 0; x < peaks.size() && x < 5; x++)
		{
			Feature aPeak = peaks.get(x);
			if (!parameterSet.isOverThreshold(aPeak.getMaxValue()
					- aPeak.getMinValue(), x, peaks))
			{
				aPeak.setFeatureType(Feature.FeatureType.BELOW_HEIGHT_THRESHOLD);
			} else
			{
				return;
			}
		}

	}

	public int getMaxVal()
	{
		return spectraMaxVal;
	}

	public int getMinVal()
	{
		//if(this.isSmoothed)
		//	return 0;
		//else
			return spectraMinVal;
	}

	public Spectra(AbstractFSAFileDescriptor fileDescriptor, byte dataChannel,
			ParameterSet parameterSet) throws Exception
	{
		this.fileDescriptor = fileDescriptor;
		this.dataChannel = dataChannel;
		this.parameterSet = parameterSet;
		this.dyeColor = setDyeColor(this.dataChannel);
		FSAParser parser = new FSAParser(this.fileDescriptor.getFSAFile());
		this.data = parser.getDataArray(this.dataChannel);
		this.dataWrapper = new ArrayBasedDataProvider<Short>(this.data);
		this.name = this.fileDescriptor.getFileNamePrefix();
		this.bufferedImage.set(null);
	}
	/*
	 * Integer to Short
	 */
	public DataProvider<Short> getData()
	{
		return this.dataWrapper;
	}
	
	public DataProvider<Short> getSmoothedData()
	{
		return this.smoothDataWrapper;
	}
	
	public void smoothData(int rws,int ris,int sgw,int sgp)
	{	
		double[] d = new double[this.data.length];
		for(int index=0; index<this.data.length; index++)
			d[index] = this.data[index];
		BaseLineCorrection bl = new BaseLineCorrection(d, rws, ris, sgw, sgp);
		this.smoothDataWrapper = bl.getCorrectedData();
		
	}
	public void cancelSmoothing()throws Exception
	{
		this.isSmoothed = false;
		this.showSmoothed = false;
		this.smoothDataWrapper = null;
		if(!this.isStandard)
			callFeatures();
		if(this.isStandard)
			resetStndHeights(false);
	}
	
	public CachedBufferedImage getBufferedImage()
	{
		return bufferedImage.get();
	}
	
	public void setBufferedImageIfAppropriate( BufferedImage newImage, int width, int height,
			long timeStamp)
	{
		CachedBufferedImage oldImage = bufferedImage.get();
		
		if( oldImage == null || timeStamp > oldImage.getNanoTimeStamp())
		{
			CachedBufferedImage cbi = new CachedBufferedImage(newImage, width,height,timeStamp);
			bufferedImage.set(cbi);
		}
	}

	/*
	 * //added this 2/23/10 public float[] getLastSetOfBasePairCalls() { return
	 * this.basePaircalls; }
	 */
	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public int getDataChannel()
	{
		return dataChannel;
	}

	public AbstractFSAFileDescriptor getFileDescriptor()
	{
		return fileDescriptor;
	}

	public ParameterSet getParameterSet()
	{
		return parameterSet;
	}

	public void setParameterSet(ParameterSet parameterSet)
	{
		this.parameterSet = parameterSet;
	}
	public float[] getSumPeaks()
	{
		return sumPeaks;
	}
	public void setSumPeaksSize(int size)
	{
		sumPeaks = new float[size];
	}
	public void nullOutSumPeaks()
	{
		sumPeaks = null;
	}
	public String getDyeColor()
	{
		return this.dyeColor;
	}
	private String setDyeColor(int x)
	{
		String[] dyes = {"Blue","Green","Yellow","Red","Orange"};
		if(x == 105)
			return "Orange";
		else
			return dyes[x-1];
	}
}
