package experimentSets;

import java.io.File;
import java.util.List;

public class PsProjectDescriptor extends AbstractFSAFileDescriptor
{
	private static final long serialVersionUID = 4619994332610908452L;
	private List<Spectra> dataSpectra= null;
	private Spectra standardSpectra = null;
	private StandardWeights sw;
	private final File filePath;
	private final GuiDerivedExperimentSet expSet;
	//private final List<Integer> channels;
	private final List<Byte> channels;
	//private final int stndChannel;
	private final byte stndChannel;
	/*public PsProjectDescriptor(StandardWeights sw,final File filePath, 
			final GuiDerivedExperimentSet experimentSet, 
			   final List<Integer> channels, final int stndChannel)*/
	public PsProjectDescriptor(StandardWeights sw,final File filePath, 
			final GuiDerivedExperimentSet experimentSet, 
			   final List<Byte> channels, final byte stndChannel)
	{
		this.sw = sw;
		this.filePath = filePath;
		this.expSet = experimentSet;
		this.channels = channels;
		this.stndChannel = stndChannel;
	}

	@Override
	//public List<Integer> getDataChannels()
	public List<Byte> getDataChannels()
	{
		return this.channels;
	}

	@Override
	public List<Spectra> getDataSpectra() throws Exception 
	{
		return this.dataSpectra;
	}

	@Override
	public AbstractExperimentSet getExperimentSet()
	{
		return this.expSet;
	}

	@Override
	public File getFSAFile() 
	{
		return this.filePath;
	}

	@Override
	public List<Short> getSizeStandards() 
	{
		return sw.getWeights();
	}

	@Override
	public String getSizeStandardsName()
	{
		return sw.getName();
	}

	@Override
	//public int getStandardChannel() 
	public byte getStandardChannel()
	{
		return this.stndChannel;
	}

	@Override
	public Spectra getStandardSpectra() throws Exception 
	{
		return this.standardSpectra;
	}

	@Override
	public StandardWeights getStndWeightsObject()
	{
		return this.sw;
	}

	@Override
	public void setDataSpectra(List<Spectra> s) 
	{
		this.dataSpectra = s;
		
	}

	@Override
	public void setSizeStandards(List<Short> list) 
	{
		this.sw.setWeights(list);
		
	}

	@Override
	public void setSizeStandardsName(String name) 
	{
		this.sw.setName(name);
		
	}

	@Override
	public void setSizeStndFilePath(String path)
	{
		this.sw.setFilePath(path);
		
	}

	@Override
	public void setStandardSpectra(Spectra s)
	{
		this.standardSpectra = s;
		
	}

	@Override
	public void setStndWeightsObject(StandardWeights sw)
	{
		this.sw = sw;
		
	}

}
