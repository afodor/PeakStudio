package experimentSets;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import peakCaller.ParameterSet;

abstract public class AbstractExperimentSet implements Serializable
{
	private static final long serialVersionUID = -770578169082465609L;
	public static final String STANDARDS_SUFFIX= "STANDARDS";
	public static final String PEAKS_SUFFIX = "PEAKS";
	public static final String DATA_SUFFIX = "DATA";
	
	abstract public List<? extends AbstractFSAFileDescriptor> getFileDescriptors() throws Exception;
	abstract public String getName();
	
	public boolean writeLogFile()
	{
		return true;
	}
			
	
	/*
	 * A technical replicate is where the same DNA is input into the same PCR reaction.
	 */
	public abstract List<List<Spectra>> getTechnicalReplicates() throws Exception;
	
	/*
	 * Where the same sample is run in different ways (for example different enzymes 
	 * on the same sample in TR-FLP data)
	 */
	public abstract List<List<Spectra>> getSampleRuns() throws Exception;
	
	public static List<Integer> parseStandardsFile( File file ) throws Exception
	{
		List<Integer> list = new ArrayList<Integer>();
		
		BufferedReader reader = new BufferedReader(new FileReader(file));
		
		String nextLine = reader.readLine();
		
		while( nextLine != null)
		{
			list.add(Integer.parseInt(new StringTokenizer(nextLine).nextToken()));
			nextLine = reader.readLine();
		}
		
		return list;
	}
	
	abstract public ParameterSet getLadderParameterSet();
	abstract public ParameterSet getMainDataParameterSet();
	
	abstract public HashMap<String, String> getBadFSAFileNames();

	public void writeQCSummaryFile(File file) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		writer.write("name\texpectedNumOfStandardPeaks\tActualNumOfStandardPeaks\t");
		writer.write("ErrorInNumStandardPeaks\tAveragePeakDistance\tmarkedAsBad\tproblem\n");
		
		for( AbstractFSAFileDescriptor fsa : getFileDescriptors() )
		{
			writer.write(fsa.getFileNamePrefix() + "\t");
			int numStandards = fsa.getSizeStandards().size();
			int numStandardPeaks = fsa.getStandardSpectra().getLastGeneratedPeakSet().size();
			
			writer.write(numStandards + "\t");
			writer.write(numStandardPeaks + "\t");
			writer.write((numStandards - numStandardPeaks) + "\t");
			writer.write( fsa.getStandardsPeakQANumber() + "\t"  );
			
			String problem = getBadFSAFileNames().get(fsa.getFileNamePrefix());
			
			writer.write( (problem !=null) + "\t");
			
			writer.write( (problem == null ? "ok" : problem) + "\n");
		}
		
		writer.flush();  writer.close();
	}
}
