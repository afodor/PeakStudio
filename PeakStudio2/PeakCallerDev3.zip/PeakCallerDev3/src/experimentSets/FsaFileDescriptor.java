package experimentSets;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class FsaFileDescriptor extends AbstractFSAFileDescriptor implements Serializable
{
	private static final long serialVersionUID = 1790658218359406878L;
	private List<Spectra> dataSpectra= null;
	private Spectra standardSpectra = null;
	private StandardWeights sw;
	private final File filePath;
	private final AbstractExperimentSet expSet;
	//private final List<Integer> channels;
	private final List<Byte> channels;
	//private final int stndChannel;
	private final byte stndChannel;
	
	/*public FsaFileDescriptor(StandardWeights sw,final File filePath, final AbstractExperimentSet experimentSet, 
													   final List<Integer> channels, final int stndChannel)*/
	public FsaFileDescriptor(StandardWeights sw,final File filePath, final AbstractExperimentSet experimentSet, 
			   final List<Byte> channels, final byte stndChannel)
	{
		this.sw = sw;
		this.filePath = filePath;
		this.expSet = experimentSet;
		this.channels = channels;
		this.stndChannel = stndChannel;
		
	}
	
	@Override
	/*public List<Integer> getDataChannels()*/
	public List<Byte> getDataChannels()
	{
		return this.channels;
	}

	@Override
	public List<Spectra> getDataSpectra() throws Exception
	{
		if( dataSpectra == null)
		{
			dataSpectra = new ArrayList<Spectra>();
			
			//List<Integer> dataChannels = getDataChannels();
			List<Byte> dataChannels = getDataChannels();
			if( dataChannels == null)
				return null;

			/*
			for( Integer i : dataChannels )
			{
				//System.out.println(i);
				dataSpectra.add(new Spectra(this, i, getExperimentSet().getMainDataParameterSet()));
			}*/
			for(Byte s: dataChannels)
			{
				dataSpectra.add(new Spectra(this,s,getExperimentSet().getMainDataParameterSet()));
			}
		}
		
		return dataSpectra;
		
	}

	@Override
	public AbstractExperimentSet getExperimentSet()
	{
		return this.expSet;
	}

	@Override
	public File getFSAFile() 
	{
		return this.filePath;
	}

	@Override
	public List<Short> getSizeStandards() 
	{
		if( sw==null)
			return null;
		
		return sw.getWeights();
	}

	@Override
	public String getSizeStandardsName() 
	{
		if( sw== null)
			return null;
		
		return sw.getName();
	}

	@Override
	//public int getStandardChannel() 
	public byte getStandardChannel()
	{
		return this.stndChannel;
	}

	@Override
	public Spectra getStandardSpectra() throws Exception
	{
		if( getStandardChannel() == -1)
			return null;
		
		if( standardSpectra == null)
			standardSpectra = new Spectra(this, getStandardChannel(), this.getExperimentSet().getLadderParameterSet());
		
		return standardSpectra;
	}

	@Override
	public StandardWeights getStndWeightsObject()
	{
		return this.sw;
	}

	@Override
	public void setDataSpectra(List<Spectra> s) 
	{
		this.dataSpectra = s;
		
	}

	@Override
	public void setSizeStandards(List<Short> list) 
	{
		this.sw.setWeights(list);
		
	}

	@Override
	public void setSizeStandardsName(String name)
	{
		this.sw.setName(name);
		
	}

	@Override
	public void setSizeStndFilePath(String path)
	{
		this.sw.setFilePath(path);
		
	}

	@Override
	public void setStandardSpectra(Spectra s) 
	{
		this.standardSpectra = s;
		
	}

	@Override
	public void setStndWeightsObject(StandardWeights sw) 
	{
		this.sw = sw;
		
	}

}
