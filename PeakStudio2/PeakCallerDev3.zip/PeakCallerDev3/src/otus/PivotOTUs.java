package otus;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Arrays;

import dataProvider.DataProvider;

import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;

public class PivotOTUs
{
	public static void simplePivotBySpectra( AbstractExperimentSet aes, 
					int spectraNumber, File outputFile	)
		throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile));
		
		int binSize = 3;
		
		writer.write("bin");
		
		for( AbstractFSAFileDescriptor fd : aes.getFileDescriptors() )
			writer.write("\t" + fd.getFileNamePrefix());
		
		writer.write("\n");
	
		/*
		List<Double> sums = new ArrayList<Double>();
		
		for( AbstractFSAFileDescriptor fd : aes.getFileDescriptors() )
			sums.add(getSum(fd, spectraNumber, 100, 800));
		*/
		
		for( int x = 100; x <=800; x+=binSize)
		{
			writer.write("" + x);
			
			for( int y=0; y < aes.getFileDescriptors().size(); y++ )
			{
				AbstractFSAFileDescriptor fd = aes.getFileDescriptors().get(y);
			//	double sum = sums.get(y);
					
				double val = getAverage(fd, spectraNumber, x, x+binSize);
				
				writer.write( "\t" +  val);
				
			}
			
			writer.write("\n");
		}
		
		writer.flush();  writer.close();
	}
	
	private static double getAverage( AbstractFSAFileDescriptor fs, 
			int spectraNumber, float startBP, float endBP )
		throws Exception
	{
		float sum = 0;
		int n=0;
		
		DataProvider<Float> basePairs= fs.getLastSetOfBasePairCalls();
		
		int startIndex = Math.abs(  basePairs.search(startBP));
		int endIndex = Math.abs( basePairs.search(endBP));
		
		//DataProvider<Integer> data = fs.getDataSpectra().get(spectraNumber).getData();
		DataProvider<Short> data = fs.getDataSpectra().get(spectraNumber).getData();
		for( int x= startIndex; x < endIndex; x++)
		{
			sum+=data.get(x);
			n++;
		}
		
		return sum/n;
	}
}
