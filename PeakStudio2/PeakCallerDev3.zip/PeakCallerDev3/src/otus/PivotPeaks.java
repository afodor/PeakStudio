package otus;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;


import pca.PCA;

import utils.ConfigReader;

import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.Spectra;
//import experimentSets.WolfgangCFData;

public class PivotPeaks
{
	private static void writeHeader( BufferedWriter writer, List<List<Spectra>> outerList) 
		throws Exception
	{
		writer.write("Enzyme\tChannel\tBasePair\tOTU_ID");
		
		for( List<Spectra> innerList : outerList )
		{
			Spectra sp = innerList.get(0);
			StringTokenizer sToken = 
				new StringTokenizer(sp.getFileDescriptor().getFileNamePrefix(),"-");
		
			String nextToken = sToken.nextToken();
			writer.write("\t" + nextToken );
		}
		
		writer.write("\n");
	}
	
	private static class Holder
	{
		String enzyme;
		int channel;
		float basepair;
		String otuID;
		float[] sumPeaks;
	}
	
	private static class PeakHolder
	{
		float basepair;
		float maxValue;
	}
	
	private static List<PeakHolder> getListOfPeaks( Spectra s) throws Exception
	{
		List<PeakHolder> list = new ArrayList<PeakHolder>();
		
		AbstractFSAFileDescriptor fsa = s.getFileDescriptor();
		
		File newDir = new File( fsa.getFSAFile().getParent() + File.separator + 
		"peaks");
		
		File peaksFile = new File(newDir.getAbsoluteFile() + File.separator + 
				fsa.getFileNamePrefix() +
				AbstractExperimentSet.DATA_SUFFIX 
				+ "_" + (s.getDataChannel()-1) +  "." + AbstractExperimentSet.PEAKS_SUFFIX );
		
		BufferedReader reader = new BufferedReader(new FileReader(peaksFile));
		
		reader.readLine();
		
		String nextLine = reader.readLine();
		
		while (nextLine != null)
		{
			StringTokenizer sToken = new StringTokenizer(nextLine);
			PeakHolder ph = new PeakHolder();
			list.add(ph);
			
			sToken.nextToken();sToken.nextToken();sToken.nextToken();
			
			ph.basepair= Float.parseFloat(sToken.nextToken());
			sToken.nextToken();
			ph.maxValue = Float.parseFloat(sToken.nextToken());
			
			if( sToken.hasMoreTokens() )
				throw new Exception("Unexpected token "+ sToken.nextToken());
			
			nextLine = reader.readLine();
		}
		
		return list;
	}
	
	/*
	 * the data array should be in the format
	 * 
	 * 			Taxa1	Taxa2	Taxa3	Taxa4
	 * subjec1
	 * subject2
	 * subject3
	 * This is a double[Site][Taxa]
	 * 
	 * This has the effect of clustering Sites across the Taxa
	 */
	private static double[][] getAsDoubleArray(List<Holder> list,
			List<List<Spectra>> outerList, float threshold)
	{
		List<Holder> shortList = new ArrayList<Holder>();
		
		for( Holder h : list)
		{
			int numOverThreshold = 0;
			
			for( float f : h.sumPeaks )
				if( f > threshold)
					numOverThreshold++;
			
			if( numOverThreshold > 1)
				shortList.add(h);
		}
		
		double[][] d= new double[outerList.size()][shortList.size()];
		
		for( int x=0; x < outerList.size(); x++)
			for(int y=0; y < shortList.size(); y++)
			{
				Holder h = shortList.get(y);
				d[x][y] = h.sumPeaks[x];
			}
			
		return d;
	}
	
	private static void writeArray(List<List<Spectra>> outerList, double[][] d,
			File file) throws Exception
	{
		//double[Site][Taxa]
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(file));
		
		for( int x=0; x < outerList.size(); x++)
		{
			Spectra s= outerList.get(x).get(0);
			String name = s.getFileDescriptor().getFileNamePrefix();
			StringTokenizer sToken = new StringTokenizer(name,"-_");
			writer.write(sToken.nextToken());
			
			if( x +1 == outerList.size())
				writer.write("\n");
			else
				writer.write("\t");
		}
		
		for( int y=0; y < d[0].length; y++)
			for( int x=0; x < outerList.size(); x++)
			{
				//System.out.println(x + " " + y + " " + d[0].length);
				writer.write("" + d[x][y]);				

				if( x +1 == outerList.size())
					writer.write("\n");
				else
					writer.write("\t");

			}
		
		writer.flush();  writer.close();
	}
	
	private static void writeResults(BufferedWriter writer, List<Holder> list) throws Exception
	{
		for( Holder h : list )
		{
			{
				writer.write(h.enzyme);
				writer.write("\t" + h.channel);
				writer.write("\t" + h.basepair);
				writer.write("\t" + h.otuID);
				
				for( Float f : h.sumPeaks )
				{
					writer.write("\t" + f );
				}
				writer.write("\n");
			}			
		}
	}
	
	private static List<Holder> collectPeaks(  List<List<Spectra>> outerList,
			float startBasePairs, float endBasePairs, float binSize)
		throws Exception
	{
		List<Holder> pivots = new ArrayList<Holder>();
		
		for( int y=0; y < 4; y++)
			for( float x= startBasePairs; x <= endBasePairs; x+=binSize)
			{
				Holder h = new Holder();
				h.channel = -1;
				h.basepair = x;
				h.sumPeaks = new float[outerList.size()];
				pivots.add(h);
			}
		
		int yIndex =-1;
	
		for( List<Spectra> innerlist : outerList )
		{
			int xIndex=0;
			yIndex++;
			
			for( Spectra s : innerlist )
			{
				String name = s.getFileDescriptor().getFileNamePrefix();
				StringTokenizer sToken = new StringTokenizer(name,"-_");
				sToken.nextToken();
				String enzyme = sToken.nextToken();
				int channel = s.getDataChannel();
				List<PeakHolder> peakList= getListOfPeaks(s);
				
				for(  int x=(int)startBasePairs; x <= endBasePairs; x+=binSize)
				{
					Holder h = pivots.get(xIndex);
					
					if( h.enzyme == null)
						h.enzyme = enzyme;
					
					if ( ! h.enzyme.equals(enzyme))
						throw new Exception("Parsing error");
					
					if( h.channel == -1)
						h.channel = channel;
					
					if( h.channel != channel)
						throw new Exception("Parsing error");
					
					if ( h.basepair != x)
						throw new Exception("Parsing error");
					
					String otuString = enzyme + "_" + channel + "_" + x;
					
					if( h.otuID == null)
						h.otuID = otuString;
					
					if( ! otuString.equals( h.otuID))
						throw new Exception("Parsing error");
					
					//ineffecient search, but on the other hand the lists are small
					for( PeakHolder ph : peakList)
					{
						float end = x + binSize;
						if( ph.basepair >= x && ph.basepair < end )
							h.sumPeaks[yIndex] += ph.maxValue;
					}
					
					xIndex++;
				}
			}			
		}
				
		
		return pivots;
	}
	
	public static void main(String[] args) throws Exception
	{
		/*
		File outFile = new File(ConfigReader.getMattCFDirectory()+
				File.separator + "peakPivotsBinWidth3");
		
		System.out.println("Writing " + outFile.getAbsolutePath());
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile));
		WolfgangCFData cfdata = new WolfgangCFData();
		
		List<List<Spectra>> outerList = cfdata.getSampleRuns();
		writeHeader(writer, outerList);
		List<Holder> pivots = collectPeaks(outerList, 100f, 900f, 3f);
		writeResults(writer, pivots);
		
		writer.flush();  writer.close();
		
		double[][] d = getAsDoubleArray(pivots, outerList, 25);
		
		List<String> keys = new ArrayList<String>();
		
		for( List<Spectra> list : outerList )
		{
			Spectra s = list.get(0);
			StringTokenizer sToken = 
				new StringTokenizer(s.getFileDescriptor().getFileNamePrefix(), "-_");
			keys.add(sToken.nextToken());
		}
		
		List<String> patientIds = new ArrayList<String>();
		List<String> timepoints = new ArrayList<String>();
		
		for( String key : keys)
		{
			patientIds.add("" + WolfgangCFData.getPatientNumber(key));
			timepoints.add(WolfgangCFData.getTimepoint(key));
		}
		
		List<String> catHeaders = new ArrayList<String>();
		catHeaders.add("Subject");catHeaders.add("Timepoints");
		List<List<String>> categories = new ArrayList<List<String>>();
		categories.add(patientIds);  categories.add(timepoints);
		
		PCA.writePCAFile(keys, catHeaders, categories,
				d, 
				new File(ConfigReader.getMattCFDirectory() + File.separator
				+ "PCA_3bp" ));
		
		writeArray(outerList, d, new File("c:\\temp\\pcaR"));
		*/
	}
}
