package fsaFileChoosers;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.prefs.Preferences;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import viewer.FsaFrame;


public class FsaFileChooser extends JFileChooser implements ItemListener, ActionListener
{
	
	private static final long serialVersionUID = 1L;
	private JPanel topPanel,dataPanel,stndPanel,buttonPanel;
	
	// Warning:  these must be integers.
	public static final String[] menuStrings = {"1","2","3","4","105"};
	private final String[] channel_colors = {"Blue","Green","Yellow","Red","Orange"};
	//private HashMap<String, Integer> stndDropMenu = new HashMap<String, Integer>();
	private HashMap<String,Byte> stndDropMenu = new HashMap<String, Byte>();
	private JComboBox stndChannelComboBox = new JComboBox(channel_colors);
	private JCheckBox[] cba = new JCheckBox[menuStrings.length];
	//private HashMap< String, Integer> chkBoxMap = new HashMap<String, Integer>();
	private HashMap<String,Byte>chkBoxMap = new HashMap<String, Byte>();
	//private List<Integer> dataChannelsList = new ArrayList<Integer>();
	//private int selectedStnd = 0;
	private List<Byte> dataChannelsList = new ArrayList<Byte>();
	private byte selectedStnd = 0;
	private FsaFrame parent;
	private final String FIVE = "Five";
	private Preferences prefs;
	private final String D_S_C = "Default Standard Channel";
	private int d_s_c;
    protected JDialog createDialog(Component parent) throws HeadlessException
    {
        JDialog dialog = super.createDialog(parent);
        this.parent = (FsaFrame) parent;
        this.prefs = Preferences.userNodeForPackage(this.parent.getClass());
        this.d_s_c = this.prefs.getInt(D_S_C, 4);
        buildChkBoxMap();
        dialog.add(buildPanels(), BorderLayout.NORTH);
        dialog.pack();
        return dialog;
    }
   
	private void buildChkBoxMap()
	{
		for(int x = 0; x<menuStrings.length-1; x++)
			chkBoxMap.put(channel_colors[x], Byte.parseByte(menuStrings[x]));//chkBoxMap.put(channel_colors[x], (Byte)(x+1));
	}

    private JPanel buildPanels()
    {
    	topPanel = new JPanel();
    	topPanel.setLayout(new FlowLayout());
    	dataPanel = new JPanel(new FlowLayout());
    	dataPanel.setBorder(BorderFactory.createTitledBorder("Data Channels"));
    	stndPanel = new JPanel();
    	stndPanel.setBorder(BorderFactory.createTitledBorder("Standards"));
    	buttonPanel = new JPanel(new GridLayout(3,1));
    	buttonPanel.setSize(100, 100);
    	makeDropMenuHashMap();
    	buildCheckBox();
    	stndChannelComboBox.addActionListener(this);
    	stndChannelComboBox.setSelectedIndex(getDefaultStndChannel());
    	stndPanel.add(stndChannelComboBox);
    	stndPanel.setSize(200,50);
    	dataPanel.add(stndPanel);
    	topPanel.add(Box.createHorizontalStrut(10));
    	topPanel.add(dataPanel);
    	topPanel.add(Box.createHorizontalStrut(10));
        return topPanel;
    }
    
    
    private void makeDropMenuHashMap()
    {
    	for(int x = 0; x< menuStrings.length; x++)
    	{
    		if(menuStrings[x].equals(FIVE))
    		{
    			//stndDropMenu.put(channel_colors[x], (Byte)105);
    			stndDropMenu.put(channel_colors[x], Byte.parseByte("105"));
    		}
    		else
    			stndDropMenu.put(channel_colors[x], Byte.parseByte(menuStrings[x]));//stndDropMenu.put(channel_colors[x], (Byte)(x+1));
    	}	
    }
    
    private void buildCheckBox()
    {
    	for(int x =0; x<menuStrings.length-1; x++)
    	{
    		cba[x] = new JCheckBox(channel_colors[x]);
    		cba[x].addItemListener(this);
    		if(menuStrings[x].equals("1"))
    			setDefaltChkBoxSelection(menuStrings[x], true);
    		else
    			setDefaltChkBoxSelection(menuStrings[x], false);
    		if(this.prefs.getBoolean(menuStrings[x], false))
    				cba[x].setSelected(true);
    		//if(menuStrings[x].equals("1"))
    			//cba[x].setSelected(true);
    		dataPanel.add(cba[x]);
    	}
    	
    }
    
    private void setDefaltChkBoxSelection(String key,boolean value)
    {
    	this.prefs.putBoolean(key, value);
    }
    
    private int getDefaultStndChannel()
    {
    	return this.d_s_c;
    }
    
    private void setDefaultStndChannel(int x)
    {
    	if(x == 105)
    	{
    		this.d_s_c = 4;
    		this.prefs.putInt(D_S_C, 4);
    	}
    	else
    	{
    		this.d_s_c = x-1;
        	this.prefs.putInt(D_S_C, x-1);
    	}
    	
    }
    
    //private void setSelectedStnd(int x)
    private void setSelectedStnd(byte x)
    {
    	selectedStnd = x;
    }
    
   // public int getSeletedStnd()
    public byte getSelectedStnd()
    {
    	return selectedStnd;
    }
	//public List<Integer> getDataChannels()
    public List<Byte> getDataChannels()
	{
		Collections.sort(dataChannelsList);
		return dataChannelsList;
	}
	
    @Override
	public void itemStateChanged(ItemEvent e)
	{
    	JCheckBox jc = (JCheckBox) e.getSource();
    	String s = jc.getText();
    	if(jc.isSelected())
    	{
    		dataChannelsList.add(chkBoxMap.get(s));
    		setDefaltChkBoxSelection(s, true);
    	}
    	else
    	{
    		if(dataChannelsList.contains(chkBoxMap.get(s)))
    		{
    			dataChannelsList.remove(chkBoxMap.get(s));
    			//setDefaltChkBoxSelection(s, false);
    		}
    		setDefaltChkBoxSelection(s, false);
    	}
		
	}

	@Override
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == stndChannelComboBox)
		{
			String s = (String) stndChannelComboBox.getSelectedItem();
			setSelectedStnd(stndDropMenu.get(s));
			
			setDefaultStndChannel(getSelectedStnd());
		}
	}    
}