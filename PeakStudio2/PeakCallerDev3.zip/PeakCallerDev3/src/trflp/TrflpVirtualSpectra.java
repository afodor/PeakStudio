package trflp;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.List;

import de.linuxusers.clustering.data.LabeledDataPoint;

import binning.AbstractPeakCallBinningMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.Spectra;
import experimentSets.VirtualSpectra;




public class TrflpVirtualSpectra {

/*
	public static void main(String[] args) 
	{
		

	}
	
	public static void writeBinsToFile(ArrayList<ArrayList<Double>> binList, File fileDir, String linkageTrue,
			AbstractPeakCallBinningMethod bm, List<VirtualSpectra> spectraListForName) throws Exception 
	{

		
		File binSizeFile = new File(fileDir	+ File.separator + bm.getName()+ linkageTrue + "binData.txt");
		BufferedWriter writer = new BufferedWriter(new FileWriter(binSizeFile));
		
		ArrayList<String> condition = new ArrayList<String>();
		
		for (int i = 0; i < spectraListForName.size(); i++)
		{
			condition.add(spectraListForName.get(i).getName()); // just choosing 1st name in the row from the setup textfile.
			//ArrayList<Double> values = list.get(i);
			//branchesForCluster.add( new LabeledDataPoint( i,values, label )); //This is what we feed into cluster code
		}
		
		//writing the header
		writer.write("name\t");
		for (int i = 0; i < binList.get(0).size(); i++)
		{
				writer.write(i + "\t");		
		}
		writer.write("\n");	
		
		//write the body
		try 
		{
			for (int i = 0; i < binList.size(); i++)
			{
				writer.write(condition.get(i) + "\t");
				for (int j = 0; j < binList.get(i).size(); j++)
				{
					writer.write(String.valueOf(binList.get(i).get(j)));
					writer.write("\t");
				}
				writer.write("\n");	
			}
		} 
		catch (Exception e) 
		{
			System.out.println(" binList size is " + binList.size());
			System.out.println(" Name List size is " + condition.size());
			e.printStackTrace();
		}
		
		writer.flush();  writer.close();
		System.out.println("FIN writing Bin data file.");
	}
*/
}
