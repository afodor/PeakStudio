package peakSummaryGUI;

import java.awt.Component;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import javax.swing.JFrame;

import experimentSets.Spectra;

import viewer.FsaFrame;

public class PeakSummaryFrame extends JFrame
{
	/*
	private final FsaFrame fsaFrame;
	
	public PeakSummaryFrame(FsaFrame fsaFrame)
	{
		this.fsaFrame = fsaFrame;
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		int width = 400;
		int height = 200;
		setSize(width,height);
		int xPos = fsaFrame.getX() + (fsaFrame.getWidth() - width ) /2;
		int yPos = fsaFrame.getY() + (fsaFrame.getHeight() - height) / 2;
		setLocation( Math.max(0,xPos), Math.max(0, yPos));
		setVisible(false);
	}
	
	private static class Holder
	{
		int numberPeaks=0;
		int numberSpectra=0;
	}
	
	public void updateStatistics()
	{
		HashMap<Integer, Holder> map = new HashMap<Integer, Holder>();
		List<Spectra> spectraList =  fsaFrame.getSpectraList();
		
		for( Spectra s : spectraList)
		{
			Holder h = map.get(s.getDataChannel());
			if( h== null)
			{
				h= new Holder();
				map.put(s.getDataChannel(),h);
			}
				
			h.numberPeaks += s.getPeaks().size();
			h.numberSpectra++;
		}
		
		List<Integer> channels = new ArrayList<Integer>(map.keySet());
		Collections.sort(channels);
		
		for( Component c : getComponents() )
			if( c instanceof PeakSummaryPanel )
				remove(c);
			
		setLayout(new GridLayout( channels.size(), 1 ));
		
		for( Integer i : channels )
		{
			Holder h = map.get(i);
			add( new PeakSummaryPanel(i, h.numberPeaks, h.numberSpectra));
			System.out.println("Adding " + i + " " + h.numberPeaks);
		}
		
		validateTree();
	}
	*/

}
