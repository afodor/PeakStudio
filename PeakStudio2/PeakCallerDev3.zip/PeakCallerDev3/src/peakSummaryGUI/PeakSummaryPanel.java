package peakSummaryGUI;

import java.awt.GridLayout;
import java.text.NumberFormat;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class PeakSummaryPanel extends JPanel
{
	private final int dataChannelNumber;
	
	private final JLabel leftLabel = new JLabel();
	private final JButton removeButton = new JButton("Remove");
	private final JCheckBox standardsBox = new JCheckBox("Standards");
	private final static NumberFormat nf = NumberFormat.getInstance();
	

	public PeakSummaryPanel( int dataChannelNumber, int numPeaks, int numSpectra )
	{
		this.dataChannelNumber = dataChannelNumber;
		setLayout(new GridLayout(1,3));
		add(leftLabel);
		add(removeButton);
		add(standardsBox);
		nf.setMaximumFractionDigits(2);
		float averageNumberOfPeaks = ((float)numPeaks)/numSpectra;
		leftLabel.setText("Channel " + this.dataChannelNumber + " with an average of " + 
				nf.format(averageNumberOfPeaks) + " peaks in " + numSpectra);
		
		validate();
	}
}
