package pca;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.event.MouseWheelEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;
import dialogs.PcaPanelHighlight;
import pca.PCA.EigenValueHolder;
import utils.PointConverter;
import viewer.FsaFrame;
import experimentSets.FsaFileDescriptor;
import experimentSets.Spectra;


public class PcaPanel extends JPanel
{
	private static final long serialVersionUID = 1L;
	private PcaFrame pcaFrame;
	private FsaFrame fsaFrame;
	private RenderingHints rn = null;
	private BasicStroke bs = null;
	private float strokeSize = 1.5f;
	private DecimalFormat formatter;
	Range range;
	Range displayedXRange = null;
	Range displayedYRange = null;
	private BufferedImage offScrBi = null;
	private BufferedImage axisBi = null;
	private Point dragStartScreen;
	private Point dragEndScreen;
	private Point autoPanPoint;
	private boolean panning = false;
	private Timer autoPan;
	public static final float Y_SCREEN_FRACTION = 0.90f;
	private List<String> dotName = new ArrayList<String>();
	private List<Color> dotColor = new ArrayList<Color>();
	private List<Double> varExp;
	private List<EigenValueHolder> evh;
	private double[][] dataArray;
	private int picCount = 1;
	private float xZoomFactor = 1;
	private float maxXZoomFactor = 500;
	private float xPanFactor = 0.5f;
	private float yZoomFactor = 1;
	private float maxYZoomFactor = 25;
	private float yPanFactor = 0.5f;
	public static final int AUTO_PAN_SPEED = 25;
	private final double SMALL = 6;
	private final double MEDIUM = 8;
	private final double LARGE = 12;
	private double choice = 3;
	private boolean drawBox = false;
	private BufferedImage selectBox;
	private Point upperLeft, lowerRight;
	private List<CustomDot> points = new ArrayList<CustomDot>();
	private boolean onCircle = false;
	private int index = 0;
	private Point2D.Float mousePoint = new Point2D.Float();
	private int x_comp;
	private int y_comp;
	
	public PcaPanel(PcaFrame pcaFrame)
	{
		this.pcaFrame = pcaFrame;
		init();
	}
	
	private void init()
	{
		setFocusable(true);
		setBackground(Color.white);
		setPreferredSize(new Dimension(1000,600));
		setSize(1000,600);
		setFocusable(true);
		x_comp = 0;
		y_comp = 1;
		rn = new RenderingHints(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		rn.put(RenderingHints.KEY_STROKE_CONTROL, RenderingHints.VALUE_STROKE_PURE);
		rn.put(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		bs = new BasicStroke(this.strokeSize,BasicStroke.CAP_ROUND,BasicStroke.JOIN_MITER);
		formatter = new DecimalFormat(".00");
		addMouseWheelListener(new MouseAdapter()
		{
			@Override
			public void mouseWheelMoved(MouseWheelEvent e)
			{
				float wheelRotation = ((float) e.getWheelRotation()) / 100;

				if (e.isShiftDown())
				{
					yZoomFactor += wheelRotation * 2;

					if (yZoomFactor > maxYZoomFactor)
						yZoomFactor = maxYZoomFactor;
					else
						yZoomFactor += wheelRotation;

					if (yZoomFactor < 1)
					{
						yZoomFactor = 1;
						yPanFactor = 0.5f;
					}

				} else
				{
					xZoomFactor += wheelRotation * 2;

					if (xZoomFactor > maxXZoomFactor)
						xZoomFactor = maxXZoomFactor;

					if (xZoomFactor < 1)
					{
						xZoomFactor = 1;
						xPanFactor = 0.5f;
					}

				}

				forceRedraw();
			}

		});
		
		addMouseListener(new DragStarter());
		addMouseMotionListener(new Dragging());
		autoPan = new Timer(AUTO_PAN_SPEED, new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				autoPanning(autoPanPoint);
			}
		});
		
	}
	
	public void keyZoomX(boolean zoomIn)
	{
		if(zoomIn)
			xZoomFactor += 2;
		else
			xZoomFactor -= 2;
		
		if(xZoomFactor > maxXZoomFactor)
			xZoomFactor = maxXZoomFactor;
		if(xZoomFactor < 1)
		{
			xZoomFactor = 1;
			xPanFactor = 0.5f;
		}
		forceRedraw();
	}
	
	public void keyZoomY(boolean zoomIn)
	{
		if(zoomIn)
			yZoomFactor += 2;
		else
			yZoomFactor -= 2;
		if(yZoomFactor > maxYZoomFactor)
			yZoomFactor = maxYZoomFactor;
		if(yZoomFactor < 1)
		{
			yZoomFactor = 1;
			yPanFactor = 0.5f;
		}
		forceRedraw();
	}
	
	public void autoPanning(Point p)
	{
		if (autoPanPoint != null)
			imagePan(autoPanPoint);
		
	}
	public void imagePanByKeyEvent(Point p)
	{
		dragStartScreen = new Point(getWidth()/2,getHeight()/2);
		imagePan(p);
	}
	public void imagePan(Point p)
	{
		if (p == null)
			return;

		dragEndScreen = p;

		if (xZoomFactor > 1)
		{
			float xPixelDiff = (dragStartScreen.x - dragEndScreen.x) / 10f;
			float numIndexes = xPixelDiff / getWidth()
					* displayedXRange.diff;

			float scaleFactor = numIndexes / range.diff;

			xPanFactor += scaleFactor;

			if (xPanFactor < 0)
				xPanFactor = 0;

			if (xPanFactor > 1)
				xPanFactor = 1;

		}

		if (yZoomFactor > 1)
		{
			float yPixelDiff = (dragEndScreen.y - dragStartScreen.y) / 10f;
			float scaleFactor = yPixelDiff / getHeight();

			yPanFactor += scaleFactor;

			if (yPanFactor < 0)
				yPanFactor = 0;

			if (yPanFactor > 1)
				yPanFactor = 1;
		}

		forceRedraw();
	}
	
	private static class Range
	{
		final float lowVal;
		final float highVal;
		final float diff;

		public Range(float lowVal, float highVal)
		{
			this.lowVal = lowVal;
			this.highVal = highVal;
			this.diff = highVal - lowVal;
		}
		private List<Float> getBasicSplit(int numDivisions)
		{
			List<Float> splits = new ArrayList<Float>();
			
			for( float x=0; x < numDivisions; x++)
				splits.add( lowVal + diff * x / (numDivisions -1));
			
			return splits;
		
		}
		
		public List<Float> getSplits(int numDivisions)
		{
			if(diff < 1)
			{
				return getBasicSplit(numDivisions);
			}
			
			int intDiffInterval = (int) ((diff + 0.5)/numDivisions);
			
			if( intDiffInterval <= 1)
			{
				getBasicSplit(numDivisions);
			}
			
			int intDiffLength = ("" + intDiffInterval).length();
			
			if(intDiffLength > 1 )
			{
				int tenFactor = (int) Math.pow(10,(intDiffLength - 1));
				
				intDiffInterval = tenFactor * (intDiffInterval/tenFactor);
			}
			
			if( intDiffInterval<=0)
				return getBasicSplit(numDivisions);
			
			int startVal = (int) (intDiffInterval * (int)(lowVal / intDiffInterval));
			
			List<Float> splits = new ArrayList<Float>();
			
			for( int x=startVal; x <= highVal + intDiffInterval; x+=intDiffInterval)
			{
				splits.add((float)x);
			}
			
			return splits;
		}
	}
	
	public void setDataToPlot(List<EigenValueHolder>evh,double[][] array,FsaFrame fsaFrame,List<Double>var)
	{
		this.evh = evh;
		this.fsaFrame = fsaFrame;
		this.dataArray = array;
		this.varExp = var;
		setMinMaxValues();
		setNameAndColor();
	}
	public void setXcomp(int x)
	{
		this.x_comp = x;
	}
	public int getXcomp()
	{
		return this.x_comp;
	}
	public void setYcomp(int y)
	{
		this.y_comp = y;
	}
	public int getYcomp()
	{
		return this.y_comp;
	}
	private void setMinMaxValues()
	{
		int maxValue = 0;
		int minValue = 0;
		for(int x=0; x<this.dataArray.length; x++)
		{
			maxValue = (int) Math.max(maxValue, this.dataArray[x][this.evh.get(getXcomp()).rank]);//[this.evh.get(0).rank]);
			maxValue = (int) Math.max(maxValue, this.dataArray[x][this.evh.get(getYcomp()).rank]);//[this.evh.get(1).rank]);
			minValue = (int) Math.min(minValue,this.dataArray[x][this.evh.get(getXcomp()).rank]);//[this.evh.get(0).rank]);
			minValue = (int) Math.min(minValue,this.dataArray[x][this.evh.get(getYcomp()).rank]);//[this.evh.get(1).rank]);
		}
		maxValue += 2000;
		minValue -= 2000;
		range = new Range(minValue,maxValue);
	}
	
	
	public void paint(Graphics g)
	{
		super.paint(g);

		try
		{
			Graphics2D g2 = (Graphics2D) g;
			g2.setColor(Color.WHITE);
			g2.fillRect(0, 0, getWidth(), getHeight());
			offScrBi = new BufferedImage(getWidth(), getHeight(), BufferedImage.TRANSLUCENT);
			Graphics2D lig = (Graphics2D) offScrBi.getGraphics();
			calculateGraph(lig);
			g2.drawImage(offScrBi,0,0,this);
			axisBi = new BufferedImage(getWidth(), getHeight(),
					BufferedImage.TRANSLUCENT);
			Graphics2D big = axisBi.createGraphics();
			renderAxis(big);
			
			if(onCircle)
			{
				lableCircle(mousePoint, big);
			}
			
			g2.drawImage(axisBi, 0, 0, this);
			/**************************************
			 * Removed drawing of box to select dots
			 * may be added back in later versions
			if (drawBox)
			{
				selectBox = new BufferedImage(getWidth(), getHeight(),BufferedImage.TRANSLUCENT);
				Graphics2D sbg = selectBox.createGraphics();
				drawSelectorBox(upperLeft, lowerRight, sbg);
				g2.drawImage(selectBox, 0, 0, this);
			}
			*****************************************/
			
		}
		catch (Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(pcaFrame, "Unexpected error:\n"
					+ e.getMessage());

		}

	}
	/**************************************************
	 * method not used in current version,
	 * checks to see what points where highlighted after
	 * drawing box with right mouse click and drag
	 *************************************************/
	private void checkPoints(Rectangle2D.Double rect)
	{
		List<String> names = new ArrayList<String>();
		List<Color> colors = new ArrayList<Color>();
		for(int index=0; index<points.size(); index++)
		{
			if(rect.contains(points.get(index).getPoint().x,points.get(index).getPoint().y))
			{
				names.add(points.get(index).getName());
				colors.add(points.get(index).getColor());
			}
		}
		if(!names.isEmpty() && !colors.isEmpty())
			new PcaPanelHighlight(names,colors,this.pcaFrame);
	}
	
	private void lableCircle(Point2D.Float p, Graphics2D g)
	{
		g.setColor(Color.BLACK);
		g.drawString(this.points.get(index).getName(),p.x+10,p.y-10);
		onCircle = false;
	}
	

	
	private void calculateGraph(Graphics2D g)
	{
		this.displayedXRange = getXRangeToDisplay();
		this.displayedYRange = getYRangeToDisplay();
		points.clear();
		g.setRenderingHints(rn);
		g.setStroke(getCurrentStroke());
		float graphYMax = getHeight() * Y_SCREEN_FRACTION;
		for(int row=0; row<this.dataArray.length; row++)
		{
			float xVal = (float) this.dataArray[row][this.evh.get(getXcomp()).rank];
			float yVal = (float) this.dataArray[row][this.evh.get(getYcomp()).rank];
			if(inRange(xVal, yVal))
			{
				int newX = (int) PointConverter.getXpixel(xVal,
						displayedXRange.lowVal, displayedXRange.diff, getWidth());

				int newY = (int) PointConverter.getYpixel(yVal,
						displayedYRange.lowVal, displayedYRange.diff, graphYMax);
				g.setColor(this.dotColor.get(row));
				Point2D.Double one = new Point2D.Double(newX,newY);
				CustomDot mark = new CustomDot(new Ellipse2D.Double(one.x,one.y,getDotSize(),getDotSize()),this.dotName.get(row),one,this.dotColor.get(row));
				g.fill(mark.getCustomShape());
				if(pcaFrame.isNameSelected())
					g.drawString(mark.getName(), (int)mark.getPoint().x+5, (int)mark.getPoint().y-5);
				points.add(mark);
			}
		}
		
	}
	
	private void renderAxis(Graphics2D g) throws Exception
	{
		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		g.setColor(Color.WHITE);
		g.fillRect(0, (int) graphYmax, getWidth(), (int) graphYmax);
		xTics(g);
		xlabel(g);
		yTics(g);
		ylabel(g);
		zeroLine(g);
	}
	
	private void zeroLine(Graphics2D g)
	{
		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		float zero = 0f;
		g.setColor(Color.RED);
		float[] dashPattern = { 30, 10, 10, 10 }; 
		g.setStroke(new BasicStroke(0.2f, BasicStroke.CAP_BUTT,BasicStroke.JOIN_MITER, 10, dashPattern, 0));
		double zeroX = PointConverter.getXpixel((float)zero, displayedXRange.lowVal, displayedXRange.diff, getWidth());
		double zeroY = PointConverter.getYpixel((float)zero, displayedYRange.lowVal, displayedYRange.diff, graphYmax);
		g.drawLine((int)zeroX, (int)zeroY, (int)zeroX, getHeight());
		g.drawLine((int)zeroX,(int)zeroY,(int)zeroX,0);
		g.drawLine((int)zeroX,(int)zeroY,0,(int)zeroY);
		g.drawLine((int)zeroX,(int)zeroY,getWidth(),(int)zeroY);
	}
	
	private void yTics(Graphics2D g)
	{
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(1);
		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 50, getHeight());
		g.setColor(Color.BLACK);
		g.drawLine(35, 0, 35, (int) graphYmax);
		
		List<Float> splits = displayedYRange.getSplits(10);
		for( float split : splits )
		{
			int newY = (int) PointConverter.getYpixel(split,
					displayedYRange.lowVal, displayedYRange.diff, graphYmax);
			
			if (split>= range.lowVal && split<= range.highVal)
			{
				g.drawLine(35, newY, 50, newY);
				g.drawString("" + ((int) (split)), 40, newY);
			}
		}
	}
	
	private void xTics(Graphics2D g)
	{
		NumberFormat nf = NumberFormat.getInstance();
		nf.setMaximumFractionDigits(1);
		float graphYmax = getHeight() * Y_SCREEN_FRACTION;
		g.setColor(Color.WHITE);
		g.fillRect(0, (int)graphYmax, getWidth(), getHeight());
		g.setColor(Color.BLACK);
		g.drawLine(35, (int) graphYmax, getWidth(), (int) graphYmax);

		List<Float> splits = displayedXRange.getSplits(10);
		
		for (float split : splits)
		{	
			int newX = (int) PointConverter.getXpixel(split,
					displayedXRange.lowVal, displayedXRange.diff, getWidth());

			g.setColor(Color.BLACK);
			g.drawLine(newX, (int) graphYmax, newX, (int)graphYmax+10);
			g.drawString("" + (int)split+ " ", newX-5,(int)graphYmax+25 );
		
		}

	}
	
	private void xlabel(Graphics2D g)
	{
		g.setColor(Color.BLACK);
		String s = formatter.format(this.varExp.get(getXcomp())*100);
		int comp = getXcomp() + 1;
		g.drawString("Comp "+comp+" Explains "+s+"%",getWidth()/2,getHeight()-10);
	}
	
	private void ylabel(Graphics2D g)
	{
	    BufferedImage im = new BufferedImage(25,180,BufferedImage.TRANSLUCENT);
	    Graphics2D img = im.createGraphics();
	    img.setColor(Color.WHITE);
	    img.fillRect(0, 0, im.getWidth(), im.getHeight());
	    img.setColor(Color.BLACK);
	    img.rotate(Math.PI/2);
	    String st = formatter.format(this.varExp.get(getYcomp())*100);
	    int comp = getYcomp()+1;
	    img.drawString("Comp "+comp+" Explains "+st+"%",0,0);
	    g.drawImage(im, 10, (int)(getHeight()*0.3), this);
	}
	
	private boolean inRange(float xVal,float yVal)
	{
		if(xVal >= this.displayedXRange.lowVal && xVal <= this.displayedXRange.highVal && 
				yVal >= this.displayedYRange.lowVal && yVal <= this.displayedYRange.highVal)
			return true;
		else
			return false;
	}
	private Range getYRangeToDisplay()
	{
		float zoomedRange = range.diff / yZoomFactor;

		float panStart = range.lowVal + yPanFactor * range.diff - zoomedRange
				/ 2;

		return new Range(panStart, panStart + zoomedRange);
	}

	private Range getXRangeToDisplay()
	{
		float zoomedRange = range.diff / xZoomFactor;
		float panStart = range.lowVal + xPanFactor * range.diff - zoomedRange / 2;
		return new Range(panStart,panStart+zoomedRange);
	}
	
	private BasicStroke getCurrentStroke()
	{
		return this.bs;
	}
	private double getDotSize()
	{
		switch((int)getChoice())
		{
			case 1: return SMALL;
			case 2: return MEDIUM;
			case 3: return LARGE;
			default: return LARGE;			
		}
	}
	
	private double getChoice()
	{
		return this.choice;
	}
	
	public void setChoice(double choice)
	{
		this.choice = choice;
		forceRedraw();
	}
	public void forceRedraw()
	{
		setNameAndColor();
		repaint();
	}
	private void setNameAndColor()
	{
		try
		{
			this.dotName.clear();
			this.dotColor.clear();
			for(FsaFileDescriptor fd: this.fsaFrame.getExperimentSet().getFileDescriptors())
			{
				this.dotName.add(fd.getFileNamePrefix());
				List<Spectra> spectra = fd.getDataSpectra();
				this.dotColor.add(spectra.get(0).getPeakColor());
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			JOptionPane.showMessageDialog(this.fsaFrame,
					"A serious error has occurred \n" + e.getMessage()
							+ "\nYour data are in an undefined state\n",
					"Error", JOptionPane.ERROR_MESSAGE);
		}
		
	}
	private class DragStarter extends MouseAdapter
	{
		/******************************************
		 * boolean release3 was used to see if user
		 * was trying to highlight point on screen,
		 * a function not available in current version
		 *******************************************/
		//boolean release3 = false;
		@Override
		public void mousePressed(MouseEvent e)
		{
			upperLeft = e.getPoint();
			dragStartScreen = e.getPoint();
			//dragEndScreen = null;
			dragEndScreen = e.getPoint();
			switch (e.getButton())
			{
			case MouseEvent.BUTTON1:

				if (xZoomFactor > 1 || yZoomFactor > 1)
				{
					setCursor(new Cursor(Cursor.HAND_CURSOR));
					panning = true;
				}
				break;
			case MouseEvent.BUTTON3:
				//release3 = true;
				break;

			}
		}

		@Override
		public void mouseReleased(MouseEvent e)
		{
			/*
			if(release3)
			{
				release3 = false;
				Rectangle2D.Double rect = new Rectangle2D.Double(upperLeft.x,upperLeft.y,lowerRight.x-upperLeft.x,lowerRight.y-upperLeft.y);
				checkPoints(rect);
			}*/
			setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
			panning = false;
			drawBox = false;
			//release3 = false;
			autoPan.stop();
			repaint();
		}
		@Override
		public void mouseEntered(MouseEvent e)
		{
			forceRedraw();
		}
	}	
	
	private class Dragging extends MouseMotionAdapter
	{
		public void mouseDragged(MouseEvent e)
		{
			int rightButton = e.BUTTON3_DOWN_MASK;
			if ((e.getModifiersEx() & rightButton) == rightButton)
			{
				lowerRight = e.getPoint();
				drawBox = true;
				repaint();
			}
			if (panning)
			{
				if (e.getX() >= getWidth() || e.getX() <= 0
						|| e.getY() >= getHeight() || e.getY() <= 0)
				{
					autoPanPoint = e.getPoint();
					autoPan.start();
				} else
					imagePan(e.getPoint());

			}
		}
		boolean intersect;
		public void mouseMoved(MouseEvent e)
		{
			intersect = false;
			mousePoint.setLocation(e.getX(), e.getY());
			for(int x =0; x< points.size(); x++)
			{
				Shape temp = points.get(x).getCustomShape();
				intersect = temp.contains(mousePoint); 
				
				if(intersect)
				{
					onCircle = intersect;
					index = x;
				}
				repaint();
			}
		}
	}


	private void sendPicToFile(File filename) 
	{
		try
		{
		  BufferedImage outImage = new BufferedImage(getWidth(),getHeight(),BufferedImage.TYPE_INT_RGB);
		  Graphics2D g = (Graphics2D) outImage.getGraphics();
		  g.setColor(Color.WHITE);
		  g.fillRect(0, 0, outImage.getWidth(), outImage.getHeight());
		  g.drawImage(offScrBi,0,0,this);
		  
		  g.drawImage(axisBi, 0, 0, this);
		  ImageIO.write(outImage, "PNG", filename.getAbsoluteFile());
		}
		catch (Exception e)
		{
			System.out.println(e);
		}
	}
	public void takePicture()
	{
		JFileChooser fc = new JFileChooser();
		fc.setDialogTitle(".png");
		fc.setSelectedFile(new File("PCA"+picCount+".png"));
		if(fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
		{
			File file = fc.getSelectedFile();
			sendPicToFile(file);
		}
		picCount++;
	}
	
	/**************************************************
	 * method used to draw a bounding rectangle when user
	 * right clicks and drags mouse, function not available 
	 * in current version.
	 **************************************************/
	private void drawSelectorBox(Point start, Point end, Graphics2D g2)
	{
		g2.setColor(Color.red);
		if (end.x < start.x && end.y < start.y)
			g2.drawRect(end.x, end.y, start.x - end.x, start.y - end.y);
		else if (end.x < start.x)
			g2.drawRect(end.x, start.y, start.x - end.x, end.y - start.y);
		else if (end.y < start.y)
			g2.drawRect(start.x, end.y, end.x - start.x, start.y - end.y);
		else
			g2.drawRect(start.x, start.y, end.x - start.x, end.y - start.y);
		
	}
	public void resetZoomOut()
	{
		xZoomFactor = 1;
		xPanFactor = 0.5f;
		yZoomFactor = 1;
		yPanFactor = 0.5f;

		forceRedraw();
	}
	
	class CustomDot 
	{
		Shape shape;
		String name;
		Point2D.Double p;
		Color c;
		public CustomDot(Shape s,String name,Point2D.Double p,Color c) 
		{
			this.shape = s;
			this.name = name;
			this.p = p;
			this.c = c;
		}
		public Shape getCustomShape()
		{
			return this.shape;
		}
		public void setCustomShape(Shape s)
		{
			this.shape = s;
		}
		public String getName()
		{
			return this.name;
		}
		public Point2D.Double getPoint()
		{
			return this.p;
		}
		public Color getColor()
		{
			return this.c;

		}
	}
}
