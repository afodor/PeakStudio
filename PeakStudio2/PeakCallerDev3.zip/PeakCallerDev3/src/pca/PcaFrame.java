package pca;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.net.URL;
import java.util.List;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.KeyStroke;
import javax.swing.SwingWorker;
import pca.PCA.EigenValueHolder;
import dialogs.PcaViewerAxisDialog;
import Jama.EigenvalueDecomposition;
import Jama.Matrix;
import binning.BinPeaks;
import viewer.FsaFrame;


public class PcaFrame extends JFrame
{
	private static final long serialVersionUID = 8790184729377985757L;
	private FsaFrame fsaFrame;
	private final String frameTitle = "PCA";
	private JMenuBar menuBar = new JMenuBar();
	private JCheckBoxMenuItem small,medium,large;
	private PcaPanel panel;
	private JRadioButton sampleName = new JRadioButton("Name");
	private PcaWorker myWorker;
	private PcaFrame thisFrame;
	private float str,end,b_size,p_height;
	private double[][] dataMatrix;
	private List<EigenValueHolder> eigenValues;
	private double[][] finalEigVecArray;
	private List<Double> varExplained;
	
	
	public PcaFrame(float str,float end, float bin_size,float p_height, FsaFrame frame)throws Exception
	{
		this.fsaFrame = frame;
		thisFrame = this;
		this.str = str;
		this.end = end;
		this.b_size = bin_size;
		this.p_height = p_height;
		buildFrame();
	}
	public void setDataMatrix(double[][] d)
	{
		this.dataMatrix = d;
	}
	public void startPca() throws Exception
	{
		runPCA();
	}
	private double[][] getDataMatrix()
	{
		return this.dataMatrix;
	}
	private class MyProgressBarDialog extends JDialog
	{
		private static final long serialVersionUID = 1L;
		private String string;
		private JProgressBar jbar;
		private int max;
		private JButton cancel;
		public MyProgressBarDialog(String s, int max) 
		{
			super(thisFrame,"Working...");
			this.string = s;
			this.max = max;
			init();
			this.setAlwaysOnTop(true);
			this.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
			this.setSize(200,100);
			this.setLocationRelativeTo(null);
			this.setModal(true);
			this.pack();
			this.setResizable(true);
		}
		public JProgressBar getProgressBar()
		{
			return this.jbar;
		}
		public JButton getCancelButton()
		{
			return this.cancel;
		}
		private void init()
		{
			try
			{
				URL imageUrl = fsaFrame.getClass().getResource("PSlogoSmall.png");
				Image logoImage = ImageIO.read(imageUrl);
				ImageIcon icon = new ImageIcon(logoImage);
				jbar = new JProgressBar(0,max);
				jbar.setPreferredSize(new Dimension(200,20));
				cancel = new JButton("Cancel");
				jbar.setString("Working");
				jbar.setStringPainted(true);
				jbar.setIndeterminate(true); 
				JLabel label = new JLabel(this.string+": ");
				JPanel center_panel = new JPanel();
				center_panel.setSize(200, 75);
				center_panel.add(new JLabel(icon));
				center_panel.add(jbar);
				JPanel bot_panel = new JPanel();
				bot_panel.setSize(200, 75);
				bot_panel.add(cancel);
				JPanel top_panel = new JPanel();
				top_panel.add(label);
				this.getContentPane().add(top_panel,BorderLayout.NORTH);
				this.getContentPane().add(center_panel, BorderLayout.CENTER);
				this.getContentPane().add(bot_panel,BorderLayout.SOUTH);
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
				JOptionPane.showMessageDialog(fsaFrame,
						"A serious error has occurred \n" + e.getMessage()
								+ "\nYour data are in an undefined state\n",
						"Error", JOptionPane.ERROR_MESSAGE);
			}
		}
	}
	
	private void runPCA() throws Exception
	{
		
		MyProgressBarDialog mpd = new MyProgressBarDialog("Running PCA",10);
		mpd.getCancelButton().addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				myWorker.cancel(true);	
			}
		});
		myWorker = new PcaWorker(mpd);
		myWorker.execute();
		mpd.setVisible(true);
		setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
		//showPCA();
	}
	
	private void buildFrame() throws Exception
	{
		this.setTitle(frameTitle);
	 	this.setResizable(true);
	 	this.setSize(1000,600);
	 	this.setLocationRelativeTo(null);
	 	this.setBackground(Color.WHITE);
	 	this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	 	URL imageUrl = this.fsaFrame.getClass().getResource("PSlogo.png"); 
	 	Image logoImage = ImageIO.read(imageUrl); 
	 	this.setIconImage(logoImage);
	 	panel = new PcaPanel(this);
	 	buildMenuBar();
	 	addKeyEventHandler();
	 	this.setBackground(Color.white);   
	 	this.setPreferredSize(new Dimension(1000,600));
	 	this.getContentPane().add(this.panel);
	}
	
	public void showPCA()
	{
		this.setFocusable(true);
		this.pack();
		this.setVisible(true);
	}
	private void addKeyEventHandler()
	{
		addKeyListener(new KeyListener()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				
				if(e.isShiftDown() && e.getKeyChar() == '+')
					panel.keyZoomY(true);
				else if (e.isShiftDown() && e.getKeyChar() == '-')
					panel.keyZoomY(false);
				else if(e.getKeyChar() == '+')
					panel.keyZoomX(true);
				else if(e.getKeyChar() == '-')
					panel.keyZoomX(false);
				else if(e.getKeyCode() == KeyEvent.VK_UP)
					panel.imagePanByKeyEvent(new Point((getWidth()/2),0));
				else if(e.getKeyCode() == KeyEvent.VK_DOWN)
					panel.imagePanByKeyEvent(new Point((getWidth()/2),getHeight()));
				else if(e.getKeyCode() == KeyEvent.VK_RIGHT)
					panel.imagePanByKeyEvent(new Point(getWidth(),(getHeight()/2)));
				else if(e.getKeyCode() == KeyEvent.VK_LEFT)
					panel.imagePanByKeyEvent(new Point(0,(getHeight()/2)));
			}
			@Override
			public void keyReleased(KeyEvent e) {}

			@Override
			public void keyTyped(KeyEvent e) {}
		});
	}
	private void buildMenuBar()
	{
		buildMenus();
		this.add(menuBar,BorderLayout.NORTH); 
	}
	
	private void buildMenus()
	{
		JMenu exportMenu = new JMenu("Export");
		JMenuItem exportItem = new JMenuItem("PNG");
		JMenu matrix = new JMenu("Matrix");
		JMenuItem dm = new JMenuItem("Data");
		JMenuItem eigm = new JMenuItem("Components");
		JMenu viewMenu = new JMenu("View");
		JMenu editMenu = new JMenu("Edit");
		JMenuItem editAxis = new JMenuItem("Axis");
		editMenu.add(editAxis);
		editAxis.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e) 
			{
				PcaViewerAxisDialog ax_dialog = new PcaViewerAxisDialog(panel,thisFrame);
				ax_dialog.setUpXdropMenu(panel.getXcomp());
				ax_dialog.setUpYdropMenu(panel.getYcomp());
				ax_dialog.setVisible(true);
			}
		});
		JMenu dotSize = new JMenu("Shape Size");
		small = new JCheckBoxMenuItem("Small");
		medium = new JCheckBoxMenuItem("Medium");
		large = new JCheckBoxMenuItem("Large");
		large.setSelected(true);
		small.setSelected(false);
		medium.setSelected(false);
		small.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				panel.setChoice(1);
				deSelectLarge();
				deSelectMedium();	
			}
		});
		
		medium.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				panel.setChoice(2);
				deSelectLarge();
				deSelectSmall();
			}
		});
		
		large.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				panel.setChoice(3);
				deSelectMedium();
				deSelectSmall();
			}
		});
		
		dotSize.add(small);
		dotSize.add(medium);
		dotSize.add(large);
		viewMenu.add(dotSize);
		JMenuItem zoomOut = new JMenuItem("Zoom Out");
		
		zoomOut.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				panel.resetZoomOut();
				
			}
		});
		zoomOut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z,
				ActionEvent.CTRL_MASK));
		viewMenu.addSeparator();
		viewMenu.add(zoomOut);
		viewMenu.addSeparator();
		dm.addActionListener(new FileSelectionListener());
		eigm.addActionListener(new FileSelectionListener());
		matrix.add(dm);
		matrix.add(eigm);
		exportItem.addActionListener(new FileSelectionListener());
		exportMenu.add(exportItem);
		exportMenu.add(matrix);
		
		this.sampleName.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(panel != null)
					panel.forceRedraw();
			}
			
		});
		JRadioButtonMenuItem samBG = new JRadioButtonMenuItem();
		samBG.add(this.sampleName);
		viewMenu.add(samBG);
		menuBar.add(exportMenu);
		menuBar.add(viewMenu);
		menuBar.add(editMenu);
	}
	
	private void deSelectSmall()
	{
		small.setSelected(false);
	}
	
	private void deSelectMedium()
	{
		medium.setSelected(false);
	}
	
	private void deSelectLarge()
	{
		large.setSelected(false);
	}
	
	private class FileSelectionListener implements ActionListener
	{

		public void actionPerformed(ActionEvent e)
	 	{
			switch(FileCommand.getFileCommand(e.getActionCommand()))
		 	{

				case PNG:			panel.takePicture();
		 							break;	
				case Data:			try
									{
										outPutMatrix(true);
									}catch(Exception x)
									{
										x.printStackTrace();
										JOptionPane.showMessageDialog(fsaFrame,
												"A serious error has occurred \n" + x.getMessage()
														+ "\nCould not export Matrix\n",
												"Error", JOptionPane.ERROR_MESSAGE);
									}
									break;
				case Components:	try
									{
										outPutMatrix(false);
									}catch(Exception x)
									{
										x.printStackTrace();
										JOptionPane.showMessageDialog(fsaFrame,
												"A serious error has occurred \n" + x.getMessage()
														+ "\nCould not export Matrix\n",
												"Error", JOptionPane.ERROR_MESSAGE);
									}
									break;
			 	default:			break;
		 	}
				
		 }	
	}
	 
	private enum FileCommand
	 {
		 PNG,Data,Components,NOVALUE;
		 
		 public static FileCommand getFileCommand(String str)
		 {
			 try
			 {
				 return valueOf(str);
			 }
			 catch (Exception x)
			 {
				 return NOVALUE;
			 }
		 }
	 }
	private void outPutMatrix(boolean x) throws Exception
	{
		JFileChooser fc = new JFileChooser();
		fc.setDialogTitle(".txt");
		String s;
		if(x)
			s="DataMatrix";
		else
			s="Components";
		fc.setSelectedFile(new File(s+".txt"));
		if(fc.showSaveDialog(null) == JFileChooser.APPROVE_OPTION)
		{
			File file = fc.getSelectedFile();
			if(x)
			{
				BinPeaks bp = new BinPeaks(this.str,this.end,this.b_size,this.p_height,this.fsaFrame);
				bp.collectPeaks();
				double[][] d = bp.getDoubleArray();
				bp.outPutMatrix(file);
			}
			else
			{
				outPutEigArray(finalEigVecArray, file);
			}
		}
	}
	
	protected FsaFrame getFsaFrame()
	{
		return this.fsaFrame;
	}
	
	public boolean isNameSelected()
	{
		return this.sampleName.isSelected();
	}

	
	private class PcaWorker extends SwingWorker<Void, Void>
	{
		private JDialog jd;
		public PcaWorker(JDialog jd) 
		{
			this.jd = jd;
		}
		
		@Override
		protected Void doInBackground() throws Exception
		{
			
			calcPCA();
			return null;
		}
		
		@Override
		protected void done()
		{
			jd.dispose();
			if(!isCancelled())
			{
				panel.setDataToPlot(eigenValues, finalEigVecArray, fsaFrame, varExplained);
				panel.setXcomp(0);
				panel.setYcomp(1);
				panel.forceRedraw();
				showPCA();
			}
			else
				thisFrame.dispose();
			
		}
	}

	public void calcPCA() throws Exception
	{
		double[][] subtractColMeans = PCA.subTractColMeans(getDataMatrix());
		double [][]coVarArray = PCA.getCovarianceArray(subtractColMeans);
		Matrix covarianceMatrix = new Matrix(coVarArray);
		EigenvalueDecomposition evd = covarianceMatrix.eig();
		eigenValues = PCA.getRankedEigenValues(evd);
		Matrix eigenVectors = evd.getV();
		Matrix rawDataAdjust = new Matrix(getDataMatrix()).transpose();
		Matrix rowFeatureVector = eigenVectors.transpose();
		//Matrix rowFeatureVector = eigenVectors;
		Matrix finalData = rowFeatureVector.times(rawDataAdjust);
		finalEigVecArray = finalData.transpose().getArray();
		//outPutEigArray(this.finalEigVecArray, new File("EigArray.txt"));
		Matrix originalData =  new Matrix(getDataMatrix());
		
		Matrix compressedData = rowFeatureVector.inverse().times(finalData).transpose();
		varExplained = PCA.getVarExplained();
		if( originalData.getColumnDimension() != compressedData.getColumnDimension())
			throw new Exception("Logic error");
		
		if( originalData.getRowDimension() != compressedData.getRowDimension())
			throw new Exception("Logic error");
		
		for( int i=0; i < originalData.getRowDimension(); i++)
			for( int j=0; j < originalData.getColumnDimension(); j++)
			{
				if( Math.abs( originalData.get(i, j) - compressedData.get(i, j)) > 0.0001)
					throw new Exception("Diff");
			}
	}
	public List<Double> getVarExplained()
	{
		return varExplained;
	}
	
	public void outPutEigArray(double[][]d,File outFile) throws Exception
	{
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile));
		
		for(int head=0; head<d[0].length; head++)
			writer.write("\t"+"comp_"+head);
		writer.write("\n");
		for(int x=0; x<d.length; x++)
		{
			writer.write(this.fsaFrame.getExperimentSet().getFileDescriptors().get(x).getFileNamePrefix()+"\t");
			for(int y=0; y<this.eigenValues.size(); y++)//for(int y=0; y<d[0].length; y++)
				writer.write(d[x][this.eigenValues.get(y).rank]+"\t");
			writer.write("\n");
		}
		writer.flush(); writer.close();
	}
	
	
}
