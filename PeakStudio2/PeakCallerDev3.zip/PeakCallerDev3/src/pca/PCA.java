package pca;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import utils.Pearson;
import Jama.EigenvalueDecomposition;
import Jama.Matrix;

public class PCA
{
	/*
	 * the data array should be in the format
	 * 
	 * 			Taxa1	Taxa2	Taxa3	Taxa4
	 * Site1
	 * Site2
	 * Site3
	 * This is a double[Site][Taxa]
	 * 
	 * This has the effect of clustering Sites across the Taxa
	 */
	
	public static class EigenValueHolder implements Comparable<EigenValueHolder>
	{
		final double eigenValue;
		final int rank;
		
		public EigenValueHolder(double eigenValue, int rank)
		{
			this.eigenValue = eigenValue;
			this.rank = rank;
		}
		
		public int compareTo(EigenValueHolder o)
		{
			return Double.compare( Math.abs( o.eigenValue), Math.abs( this.eigenValue));
		}
	}
	private static List<Double> varExplained;//= new ArrayList<Double>();
	public static List<Double> getVarExplained()
	{
		return varExplained;
	}
	public static List<EigenValueHolder> getRankedEigenValues( EigenvalueDecomposition evd )
		throws Exception
	{
		List<EigenValueHolder> list = new ArrayList<EigenValueHolder>();
		varExplained = new ArrayList<Double>();
		double[] eigenValues = evd.getRealEigenvalues();
		
		double sum = 0;
		
		for( int x=0; x < eigenValues.length; x++)
		{
			EigenValueHolder evh = new EigenValueHolder(eigenValues[x], x);
			list.add(evh);
			sum+=evh.eigenValue;
		}
		
		Collections.sort(list);
	
		for(int x=0; x < list.size(); x++)
			if( x<10)
			{
				//System.out.println("Comp. " + (x+1) + " explains " + ( list.get(x).eigenValue/sum ));
				varExplained.add(list.get(x).eigenValue/sum);
				
			}
				
		
		return list;
	}
	
	public static void writePCAFile(List<String> keys,
					double[][] d, File outFile) 
			throws Exception
	{
		writePCAFile(keys, null,null, d, outFile);
	}

	
	public static void writePCAFile(List<String> keys,
			List<String> categoryHeaders,
			List<List<String>> categories,
			double[][] d, File outFile) 
			throws Exception
	{
		subtractColumnMeans(d);
		
		double[][] covarianceArray = getCovarianceArray(d);
		//writeCovarianceArray(covarianceArray);
		Matrix covarianceMatrix = new Matrix(covarianceArray);
		EigenvalueDecomposition evd = covarianceMatrix.eig();
		
		List<EigenValueHolder> eigenValues = getRankedEigenValues(evd);
		
		Matrix eigenVectors = evd.getV();
		
		Matrix rawDataAdjust = new Matrix(d).transpose();
		Matrix rowFeatureVector = eigenVectors.transpose();
		
		Matrix finalData = rowFeatureVector.times(rawDataAdjust);
		
		writeComponents(outFile, finalData, keys, categoryHeaders, categories,  eigenValues);
		
		Matrix originalData =  new Matrix(d);
		
		Matrix compressedData = rowFeatureVector.inverse().times(finalData).transpose();
		
		if( originalData.getColumnDimension() != compressedData.getColumnDimension())
			throw new Exception("Logic error");
		
		if( originalData.getRowDimension() != compressedData.getRowDimension())
			throw new Exception("Logic error");
		
		for( int i=0; i < originalData.getRowDimension(); i++)
			for( int j=0; j < originalData.getColumnDimension(); j++)
			{
				if( Math.abs( originalData.get(i, j) - compressedData.get(i, j)) > 0.0001)
					throw new Exception("Diff");
			}
	}
	
	public static void writeComponents( File outFile,
			Matrix componentMatrix,  List<String> labels, 
			List<String> categoryHeaders,
			List<List<String>> categories,
			List<EigenValueHolder> eigenValues)
		throws Exception
	{
		double[][] a = componentMatrix.getArray();
		
		if( labels.size() != a[0].length)
			throw new Exception("Logic error");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(outFile ));
		
		writer.write( "keys" );
		
		if( categoryHeaders != null)
			for(String s : categoryHeaders)
				writer.write("\t"+ s);
		
		for( int x=0; x < a.length; x++)
			writer.write("\tComp" + x);
		
		writer.write("\n");
		
		for( int y =0; y < labels.size(); y++)
		{
			writer.write(labels.get(y));
			
			if( categories != null)
				for( List<String> cats : categories )
					writer.write("\t" + cats.get(y));
			
			for( int x=0; x < eigenValues.size(); x++)
			{
				writer.write("\t" + a[eigenValues.get(x).rank][y]);
			}
			
			writer.write("\n");
		}
		
		writer.flush();  writer.close();
	}

	
	public static double[][] transposeArray(double[][] d) throws Exception
	{
		double[][] returnA = new double[d[0].length][d.length];
		
		for( int x=0; x< d.length; x++)
			for( int y=0; y < d[0].length; y++)
				returnA[y][x] = d[x][y];
		
		return returnA;
	}
	
	
	public static double[][] getCovarianceArray(double[][] d)
		throws Exception
	{
		double[][] returnArray = new double[d[0].length][d[0].length];
		
		for( int x=0; x < d[0].length; x++ )
		{
			double[] xArray = getColumn(d, x);
			
			for( int y=0; y < d[0].length; y++)
			{
				double[] yArray = getColumn(d, y);
				
				returnArray[x][y] = Pearson.getCovariance(xArray, yArray);
			}
		}
		
		return returnArray;
	}
	
	static double[] getRow( double[][] d, int rowIndex ) throws Exception
	{
		double[] r = new double[d[rowIndex].length];
		
		for( int x=0; x < d[rowIndex].length; x++)
			r[x] = d[rowIndex][x];
		
		return r;
	}
	
	static double[] getColumn( double[][] d, int colIndex) throws Exception
	{
		double[] r = new double[d.length];
		
		for( int x=0; x < d.length; x++)
			r[x] = d[x][colIndex];
		
		return r;
	}
	
	
	public static void subtractColumnMeans(double[][] d) throws Exception
	{
		for( int y=0; y < d[0].length; y++)
		{
			double colSum = 0;
			
			for( int x=0; x < d.length; x++)
				colSum += d[x][y];
			
			colSum = colSum / d.length;
			
			for( int x=0; x < d.length; x++)
				d[x][y] = d[x][y] - colSum;
			
		}
	}
	public static double[][] subTractColMeans(double[][]data)
	{
		double[][] d = data;
		for( int y=0; y < d[0].length; y++)
		{
			double colSum = 0;
			
			for( int x=0; x < d.length; x++)
				colSum += d[x][y];
			
			colSum = colSum / d.length;
			
			for( int x=0; x < d.length; x++)
				d[x][y] = d[x][y] - colSum;
			
		}
		return d;
		
	}
	public static double[][] getDataArrayWithTaxaAsColumns(HashMap<String, int[]> countMap,
			List<String> keys, List<String> annotations) 
		throws Exception
	{	
		double[][] a = 
			new double[annotations.size()][keys.size()];
		
			for( int y=0; y < keys.size(); y++)
			{
				int[] innerArray = countMap.get(keys.get(y));
				
				for( int x=0; x< innerArray.length; x++)
					a[x][y] = Math.log10( innerArray[x] + 1);
			}
		
		return a;
	}
	
	public static void percentExplained(List<EigenValueHolder> list)
	{
		double sum = 0;
		double cumulative = 0;
		
		for( EigenValueHolder egv : list )
			sum += egv.eigenValue;
		
		for( EigenValueHolder egv : list)
		{
			cumulative += egv.eigenValue / sum ;
			System.out.println( egv.eigenValue / sum + " " + cumulative);
		}
			
	}
}
