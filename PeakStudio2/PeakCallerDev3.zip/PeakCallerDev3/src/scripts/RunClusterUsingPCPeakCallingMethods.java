package scripts;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import binning.AbstractPeakCallBinningMethod;
import binning.PCDynamicProgramming;
import binning.PCFuhrman04;
import binning.PCFuhrmanShiftingMethod;
import binning.PCRandomBin;
import binning.PCSimpleBinFractions;
import de.linuxusers.clustering.HierarchicalClusterer;
import de.linuxusers.clustering.data.Cluster;
import de.linuxusers.clustering.data.DataPoint;
import de.linuxusers.clustering.data.LabeledDataPoint;
import de.linuxusers.clustering.diagrams.NewicktreeBuilder;
import de.linuxusers.clustering.linkage.LinkageMethod;
import de.linuxusers.clustering.linkage.WardsMethod;
import experimentSets.AbstractExperimentSet;
import experimentSets.AbstractFSAFileDescriptor;
import experimentSets.FsaFileDescriptor;
import experimentSets.Spectra;
//import experimentSets.ZeiselArisaMini132;

public class RunClusterUsingPCPeakCallingMethods 
{

	/**
	 * This script will run many experiment sets and many PC binning methods
	 * and generate the NH file,  the Unifrac scores, and summarize them all.
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception 
	{
		/*
		//AbstractExperimentSet sz = new Mouse188ArisaData();
		//AbstractExperimentSet sz = new Mouse150ArisaData();
		//AbstractExperimentSet sz = new ZeiselSuper12ArisaData();
		//AbstractExperimentSet sz = new ZeiselArisa70NoTechRepeats();
		AbstractExperimentSet sz = new ZeiselArisaMini132();
		ArrayList<Spectra> spectra = fetchSpectra(sz);
		ArrayList<AbstractPeakCallBinningMethod> bmList = fetchBinningMethods(spectra);
		
		for (AbstractPeakCallBinningMethod bm: bmList)
		{
			ArrayList<ArrayList<Double>> list = bm.getBinListofLists();
			System.out.println(" Our binlistsoflists is " + list.size());
			
			//writeLists(list, expt);
			ArrayList<DataPoint> temperatures = new ArrayList<DataPoint>();
			
			for (int i = 0; i < spectra.size(); i++)
			{
				String label = spectra.get(i).getName();
				ArrayList<Double> values = list.get(i);
				System.out.println(" Our Bin list size is " + values.size() + " for label: " + label);
				temperatures.add( new LabeledDataPoint( i,values, label ));
			}
			
			LinkageMethod avgDist = new WardsMethod();
			// we want to have three clusters of temperature
			int clusterCount = 1;
			
			
			// let's cluster!
			List<Cluster> avgDResults = HierarchicalClusterer.cluster(
					temperatures, avgDist,	clusterCount);
			
			// let's take a look at the results, this
			// time we want the data points of the clusters only,
			// hierarchical structure is too geeky for us...
			//System.out.println("Avg Distance Method:");
			for ( Cluster cl : avgDResults ) 
			{
				System.out.println(cl.getLeavesOrSelf());
			}
							
			Cluster topCluster = HierarchicalClusterer.cluster(
					temperatures, avgDist);
			
			NewicktreeBuilder s = new NewicktreeBuilder();
			String test = s.getTree(topCluster);
			AbstractPeakCallBinningMethod.writeNewickFormatToFile(test, sz, bm);
			
			File file = AbstractPeakCallBinningMethod.writeNewickFormatToFile(test, sz, bm);
			File envFile = new File(sz.getFileDescriptors().get(0).getFSAFile().getParent() + File.separator + "unifracENV.txt");
			scripts.UnifracMakeScript.launchUniFracScript(file, bm, sz, envFile);
			System.out.println("\n\n\n" + bm.getName() + "\t\t" + test);
		}
		File unifraLocation = new File(sz.getFileDescriptors().get(0).getFSAFile().getParent() + File.separator + "Unifrac");
		ParseUnifracResults.parseResults(unifraLocation);
		*/
	}

	
	
	private static ArrayList<AbstractPeakCallBinningMethod> fetchBinningMethods(ArrayList<Spectra> spectra) throws Exception 
	{	
		ArrayList<AbstractPeakCallBinningMethod> list = new ArrayList<AbstractPeakCallBinningMethod>();
		
		/*list.add(new PCDynamicProgramming(spectra, false, true));
		list.add(new PCFuhrmanShiftingMethod(spectra, false, true));
		list.add(new PCFuhrman04(spectra, false, true));
		
		for (int j = 1; j < 10; j++)
		{
			list.add( new PCSimpleBinFractions(j, spectra, 0.25, false, true));
		}
		
		for (int j = 1; j < 100; j++)
		{
			list.add(new PCRandomBin(spectra, false, true,String.valueOf(j)));
		}*/
		list.add( new PCSimpleBinFractions(0.5f, spectra, 0.25, false, true));
		return list;
	}

}
