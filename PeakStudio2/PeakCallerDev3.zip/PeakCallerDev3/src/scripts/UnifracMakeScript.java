package scripts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

import experimentSets.AbstractExperimentSet;
//import experimentSets.ZeiselArisaMini132;
import utils.ConfigReader;
import utils.PythonProcessWrapper;
import binning.AbstractPeakCallBinningMethod;
import binning.PCSimpleBinFractions;


public class UnifracMakeScript
{

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception
	{
		/*
		AbstractExperimentSet sz = new ZeiselArisaMini132();
		
		//PCSimpleBinFractions meth = new PCSimpleBinFractions(3,sz, 0, false,false);
		File envFile = new File("C:\\ArisaLS\\miniZeiselNoRepeats51\\unifracENV.txt"); 
		File file = new File("C:\\ArisaLS\\megaZeisel153\\NH_Files\\clusterInfo-SimpleBinFraction1.0Peaked.nh");
		 
		//launchUniFracScript(file, meth,  sz, envFile);
		 */
	}
	

	public static void launchUniFracScript(File file, AbstractPeakCallBinningMethod meth, AbstractExperimentSet sz, File envFile) throws Exception
	{
		System.out.println(" Time to write unifrac scipts to the unifrac subfolder !!");
		File uniFracFile = writeScripts(file, meth, sz, envFile);
		
		System.out.println(" Finished Unifrac Script Writing, now we Launch !!");
		boolean itRan = runPythonScript(uniFracFile);
		
		System.out.println(" Finished running Unifrac Script!!");
	}

	//this is hard wired to launch the python direcotry where Unifrac code is
	//in this case it is  c:\\python\\unifrac\\UniFrac_files
	private static File writeScripts(File nhfile, AbstractPeakCallBinningMethod meth, AbstractExperimentSet expt, File envFile) throws Exception
	{
		String parentDir = expt.getFileDescriptors().get(0).getFSAFile().getParent();
		File newDir = new File( parentDir + File.separator + 
		"UniFrac");
		
		if( ! newDir.exists())
			newDir.mkdir();
		
		
		File unifracFile = new File(newDir 	+ File.separator + meth.getName() + ".py" );
		
		BufferedReader reader = new BufferedReader(new FileReader(nhfile));
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(unifracFile));
				
		writer.write("print 'We are launching the unifrac script !! '\n");
		writer.write("import os, sys \n");
		writer.write("print os.getcwd() \n");
		writer.write("sys.path.append(r'C:/Python23/UniFrac_files')\n");
		writer.write("from tree_comparison_api import TreeAnalysis\n");
		writer.write("a=TreeAnalysis()\n");
		//writer.write("print a.__doc__\n"); 
		writer.write("name = r'" + parentDir + File.separator + "NH_Files" + File.separator
				+ "clusterInfo-" + meth.getName() + ".nh'\n");
		writer.write("a.loadTreeFromFile((name), 'NwA')\n");
		writer.write("a.loadEnvs('TabDel', r'"  + envFile.getAbsolutePath() + "')\n");
		writer.write("a.makeEnvDistanceMatrix(Weight=False, pad=None, norm=False,  file_path=r'" + newDir.getAbsolutePath() 
				+ File.separator + "dmatrix-" + meth.getName() + ".txt')\n");
		writer.write("a.UniFracPCA( file_path=r'" + newDir.getAbsolutePath() 
				 + File.separator + "PCA-" + meth.getName() + ".txt" 
				+  "', Weight=False,  norm=False)\n"); 
		writer.write("pvalue = a.uniFracPString(p_output='Tree', pop_size=1000, Weight=False)\n");
		writer.write("a._print_output_to_file(pvalue, file_path=r'" + newDir.getAbsolutePath()
				+ File.separator + "PValue-" + meth.getName() + ".txt')\n" );
		//writer.write("sys.exit()\n");
		//writer.write("exit()\n");
		writer.flush();  writer.close();
		
		reader.close();
		System.out.println("We are done writing the Unifrac Script !!");
		return unifracFile;
	}
	
	
	private static boolean runPythonScript(File uniFracScriptFile) throws Exception
	{
		String[] args = new String[2];
		args[0] = ConfigReader.getPythonExe();
		args[1] = uniFracScriptFile.getCanonicalPath();;
		
		System.out.println(" Python Args = " + args[0] + "\t" + args[1]);
		
		new PythonProcessWrapper(args);
		System.out.println(" Python Script is finished.");
		return false;
	}
	


}
