package scripts;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.StringTokenizer;
import experimentSets.AbstractExperimentSet;
//import experimentSets.ZeiselArisaMini132;

public class ParseUnifracResults
{

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception
	{
		/*
		AbstractExperimentSet sz = new ZeiselArisaMini132();
		
		File unifracDir = new File(sz.getFileDescriptors().get(0).getFSAFile().getParent() + File.separator + "Unifrac");
		ParseUnifracResults.parseResults(unifracDir);
		
		
		parseResults(unifracDir);

		*/
	}
	
	
	public static void parseResults(File unifracDir) throws Exception
	{
		if (! unifracDir.isDirectory()) throw new Exception("Unifrad Dir was a directory !! Plz correct, omg Lolz");
		System.out.println(" Starting the parse....");
		
		StringBuffer sbPCA = new StringBuffer();
		StringBuffer sbdMatrix = new StringBuffer();
		StringBuffer sbPValue = new StringBuffer();
		
		for (File f: unifracDir.listFiles())
		{
			if (f.getName().substring(0, 4).contentEquals("PCA-"))
			{
				System.out.println("We are parsing " + f.getName());
				sbPCA.append(parsePCA(f));
			}
			else if ((f.getName().substring(0, 4).contentEquals("dmat")))
			{
				System.out.println("We are parsing " + f.getName());
				sbdMatrix.append(parsedmatrix(f));
			}
			
			else if ((f.getName().substring(0, 4).contentEquals("PVal")))
			{
				System.out.println("We are parsing " + f.getName());
				sbPValue.append(parsePValueFile(f));
			}
		}
		
		write3Files(sbPCA, sbdMatrix, sbPValue, unifracDir);
		
	}

	private static String parsePValueFile(File f) throws Exception
	{
		StringBuffer line = new StringBuffer();
		line.append(f.getName() + "\t");
		BufferedReader reader = new BufferedReader(new FileReader(f));
		
		String nextLine = reader.readLine();  //throw away the header
		line.append(nextLine + "\n");
				
		reader.close();
		
		System.out.println(line.toString());
		return line.toString();
	}
	
	private static String parsedmatrix(File f) throws Exception
	{
		StringBuffer line = new StringBuffer();
		line.append(f.getName() + "\t");
		BufferedReader reader = new BufferedReader(new FileReader(f));
		
		reader.readLine();  //throw away the header
		String nextLine = reader.readLine(); // this is num of columns 
		StringTokenizer sToken = new StringTokenizer(nextLine);
		int numberOfColumns = 0;
		while (sToken.hasMoreTokens())
		{
			sToken.nextToken();
			numberOfColumns++;
		}
		System.out.println(" The number of tokens was " + numberOfColumns);
		
		if(nextLine == null)
			throw new Exception("Something is EMPTY! Ruh Roh.");
		
		nextLine = reader.readLine(); 
		int rowcount = 1;
		while(nextLine != null)
		{		
			sToken = new StringTokenizer(nextLine);
			
			String condition = sToken.nextToken();
			for (int i = 0; i < rowcount; i++)
			{
				sToken.nextToken(); //skipping the 1/2 triangle
			}
			
			while (sToken.hasMoreTokens())
			{
				String value = sToken.nextToken();
				line.append(value + "\t");
			}
			nextLine = reader.readLine();
			rowcount++;
		}
		
		reader.close();
		line.append("\n");
		System.out.println(line.toString());
		return line.toString();
	}

	private static String parsePCA(File f) throws Exception
	{
		StringBuffer line = new StringBuffer();
		line.append(f.getName() + "\t");
		BufferedReader reader = new BufferedReader(new FileReader(f));
		
		String nextLine = reader.readLine();  //throw away the header
		
		StringTokenizer sToken = new StringTokenizer(nextLine);
		
		if(nextLine == null)
			throw new Exception("Something is EMPTY! Ruh Roh.");
		
		nextLine = reader.readLine(); // the first PCA summary line
		
		while(nextLine.trim().length() != 0)
		{		
			nextLine = reader.readLine(); 
		}
		reader.readLine(); // throw away the 2nd blank line, the next line should be eigens
		reader.readLine(); // toss those eigens ! now we get the components !
		nextLine = reader.readLine();
		
		sToken = new StringTokenizer(nextLine);
		sToken.nextToken(); //throw away this
		sToken.nextToken(); 
		sToken.nextToken(); 
		String pca1 = sToken.nextToken();
		String pca2 = sToken.nextToken();
		
		line.append(pca1 + "\t" + pca2 + "\n");
		reader.close();
		
		System.out.println(line.toString());
		return line.toString();
	}

	private static void write3Files(StringBuffer sbPCA, StringBuffer sbdMatrix, StringBuffer sbPValue, File unifracDir) throws Exception
	{
		File dmatrixFile = new File(unifracDir.getCanonicalPath() + File.separator + "SummaryofDmatrix.txt");
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(dmatrixFile));
		writer.write("Distance matrix results '\n");
		writer.write(sbdMatrix.toString() + "\n");
		writer.flush();  writer.close();
		
		File pcaFile = new File(unifracDir.getCanonicalPath() + File.separator + "SummaryofPCA.txt");
		writer = new BufferedWriter(new FileWriter(pcaFile));
		writer.write("PCA matrix results '\n");
		writer.write(sbPCA.toString() + "\n");
		writer.flush();  writer.close();
		
		File pValueFile = new File(unifracDir.getCanonicalPath() + File.separator + "SummaryofPValues.txt");
		writer = new BufferedWriter(new FileWriter(pValueFile));
		writer.write("PValue results '\n");
		writer.write(sbPValue.toString() + "\n");
		writer.flush();  writer.close();
	}

}
