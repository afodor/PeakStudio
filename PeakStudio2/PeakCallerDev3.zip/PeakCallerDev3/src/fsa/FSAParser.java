package fsa;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

public class FSAParser
{	
	private final File fileToParse;
	private final DictionaryEntry topDictionaryEntry;
	private List<DictionaryEntry> dictionaryList;

	public static List<File> getFsaFiles(String inFilePath) throws Exception
	{
		File inDirectory = new File(inFilePath);
	
		if( ! inDirectory.exists() || ! inDirectory.isDirectory())
			throw new Exception("Could not find directory " + inDirectory.getAbsolutePath());
		
		List<File> returnList = new ArrayList<File>();
		String[] files = inDirectory.list();
		
		for( String file : files)
		{
			String fileUpper = file.toUpperCase();
			if( fileUpper.endsWith(".FSA") )
				returnList.add( new File(inDirectory.getAbsolutePath() + File.separator + 
						file));
		}

		return returnList;
	}
	
	/*
	 * DataArrayNumber 1 is cached if adjustForBackground is true.
	 * Not thread safe
	 */
	/*
	public Integer[] getDataArray(int dataArrayNum) throws Exception
	{	
		DictionaryEntry dataEntry = getDictionaryEntry("DATA", dataArrayNum);
		
		short[] s= dataEntry.getShortArray(fileToParse);
		
		Integer[] returnArray = new Integer[s.length];
		
		for( int x=0; x < s.length; x++)
			returnArray[x] = new Integer( s[x]);
		
		return returnArray;
	}
	*/
	/******************************************
	 * switch from int[] to short[] for memory
	 ******************************************/
	public Short[] getDataArray(byte dataArrayNum) throws Exception
	{
		DictionaryEntry dataEntry = getDictionaryEntry("DATA", dataArrayNum);
		short[] s= dataEntry.getShortArray(fileToParse);
		Short[] returnArray = new Short[s.length];
		for(int x=0; x< s.length; x++)
			returnArray[x] = new Short(s[x]);
		return returnArray;
		
	}
	public short getNumberOfDyes() throws Exception
	{
		DictionaryEntry numDyes = getDictionaryEntry("Dye#", 1);
		//System.out.println(numDyes);
		
		if( numDyes.getNumElements() != 1 )
			throw new Exception("Expecting single element for number of dyes");
		
		if( numDyes.getElementSize() != 2 )
			throw new Exception("Expecting short data type for number of dyes");
		
		return numDyes.getDataOffsetAsSingleShort();
	}
	
	public String getDyeName(int dyeNum) throws Exception
	{
		DictionaryEntry dye = getDictionaryEntry("DyeN", dyeNum);
		return dye.getPString(this.fileToParse);
		
	}
	
	public DictionaryEntry getDictionaryEntry(String tagName, int tagNumber)
		throws Exception
	{
		for( DictionaryEntry de : dictionaryList )
			if( de.getTagName().equals(tagName))
				if( de.getTagNumber() == tagNumber)
					return de;
		
		throw new Exception("Could not find " + tagName + " " + tagNumber);
	}
	
	
	public FSAParser(String fileToParse) throws Exception
	{
		this(new File(fileToParse));
	}
	
	public FSAParser(File fileToParse) throws Exception
	{
		this.fileToParse = fileToParse;
		
		 DataInputStream in = new DataInputStream( new BufferedInputStream(
         		new FileInputStream(fileToParse )));
		 confirmABIF(in);
		 getVersionNumber(in);
		 this.topDictionaryEntry = new DictionaryEntry(in);
		 //System.out.println(this.topDictionaryEntry);
		 in.close();

		 in = new DataInputStream( new BufferedInputStream(
	         		new FileInputStream(fileToParse )));
		 
		 in.skip(topDictionaryEntry.getDataOffset());
		 
		 dictionaryList = new ArrayList<DictionaryEntry>();
		 
		 for( int x=1; x < topDictionaryEntry.getElementSize(); x++)
		 {
			 DictionaryEntry de2 = new DictionaryEntry(in);
			 dictionaryList.add(de2);
			 //System.out.println("\n\n" + de2);
		 }
		 
		 in.close();
	}
	
	private short getVersionNumber(DataInputStream in) throws Exception
	{
		return in.readShort();
	}
	
	private void confirmABIF( DataInputStream in ) throws Exception
	{
		char[] expected = "ABIF".toCharArray();
		byte[] bytes = new byte[4];
		 
		 in.read(bytes);
		 
		 for(int x=0; x < expected.length; x++)
			 if( expected[x] != (char) bytes[x] )
				 throw new Exception("Heading does not match an ABIF file");

	}
	
	public List<DictionaryEntry> getDictionaryList()
	{
		return dictionaryList;
	}
	
	public File getParsedFile()
	{
		return fileToParse;
	}
}
