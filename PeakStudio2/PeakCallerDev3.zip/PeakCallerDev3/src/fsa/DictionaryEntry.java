package fsa;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;

public class DictionaryEntry
{
	private final String tagName;
	private final int tagNumber;
	private final short elementTypeCode;
	private final short elementSize;
	private final int numElements;
	private final int dataSize;
	private final int dataOffset;
	private final int datahandle;
	
	public DictionaryEntry(DataInputStream in) throws Exception
	{
		this.tagName = readTagName(in);
		this.tagNumber = in.readInt();
		this.elementTypeCode = in.readShort();
		this.elementSize= in.readShort();
		this.numElements = in.readInt();
		this.dataSize = in.readInt();
		this.dataOffset = in.readInt();
		this.datahandle = in.readInt();
	}
	
	public short[] getShortArray(File fileToParse) throws Exception
	{
		if( getDataSize() <= 4)
			throw new Exception("Don't call this method for less than 4 shorts!");
		
		DataInputStream in = new DataInputStream( new BufferedInputStream(
         		new FileInputStream(fileToParse )));
		
		in.skip(getDataOffset());

		short[] s = new short[getNumElements()];
		
		for( int x=0; x < getNumElements(); x++)
			s[x] = in.readShort();
		
		in.close();
		
		return s;
		
	}
	
	public String getPString(File fileToParse) throws Exception
	{
		if( getDataSize() > 4)
		{

			DataInputStream in = new DataInputStream( new BufferedInputStream(
		         		new FileInputStream(fileToParse )));
				
			 in.skip(getDataOffset());

			 byte b = in.readByte();
			 
			 if( b +1 != getNumElements() )
				 throw new Exception("Expecting a string of length " + b );
			
			 char[] chars = new char[b];
			 
			 for( int x=0; x < b ; x++)
				 chars[x] = (char) in.readByte();
				 
			return new String(chars);
		}
		
		// if we are still here the string is stored in the offset value
		return getOffsetAsPString();

	}


	/*
	 * According to the "Applied Biosystems Genetic Analysis Data File Format" guide,
	 * if the total dataItems are less than 4 bits, than the data is stored
	 * in the dataOffset itself (rather than the dataoffset pointing to the 
	 * data somewhere else in the file).
	 * 
	 * A PString is an old Pascal string.  The first byte is the length of the string.
	 * The next bytes are 256 bit ASCII code.
	 */
	public String getOffsetAsPString() throws Exception
	{
		int i = getDataOffset();
		
		i = Integer.rotateLeft(i, 8);
		
		byte b = (byte)i;
		
		if( b > 4)
			throw new Exception("Parsing error");
		
		char[] c = new char[b];
		
		for( int x=0; x < b; x++)
		{
			i = Integer.rotateLeft(i, 8);
			byte newByte = (byte)i;
			c[x] = (char) newByte;
		}
		
		return new String(c);
	}
	
	public int getNumElements()
	{
		
		return numElements;
	}

	/*
	 * According to the "Applied Biosystems Genetic Analysis Data File Format" guide,
	 * if the total dataItems are less than 4 bits, than the data is stored
	 * in the dataOffset itself (rather than the dataoffset pointing to the 
	 * data somewhere else in the file).
	 */
	public short getDataOffsetAsSingleShort()
	{
		int i = this.dataOffset;
		i = Integer.rotateLeft(i,16);
		return (short)i;
	}

	public int getDataSize()
	{
		return dataSize;
	}


	public int getDataOffset()
	{
		return dataOffset;
	}

	public int getDatahandle()
	{
		return datahandle;
	}

	public short getElementSize()
	{
		return elementSize;
	}
	
	public short getElementTypeCode()
	{
		return elementTypeCode;
	}
	
	public String getTagName()
	{
		return tagName;
	}
	
	public int getTagNumber()
	{
		return tagNumber;
	}
	
	private String readTagName( DataInputStream in  ) throws Exception
	{
		StringBuffer buff = new StringBuffer();
		byte[] b = new byte[4];
		in.read(b);
		
		for( int x=0; x < b.length; x++)
			buff.append((char)b[x]);
		
		return buff.toString();
		
	}
	
	@Override
	public String toString()
	{
		return "tagName " +  tagName + "\n"  + 
		"tagNumber " + tagNumber + "\n" + 
		"elementTypeCode " +  elementTypeCode + "\n" + 
		 "elementSize " + elementSize + "\n" + 
		"numElements " + numElements + "\n" + 
		"dataSize " + dataSize + "\n" + 
		"dataOffset " + dataOffset + "\n";
	}
	
}
