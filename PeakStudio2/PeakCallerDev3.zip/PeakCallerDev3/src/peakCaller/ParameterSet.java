package peakCaller;

import java.util.List;

import dataProvider.DataProvider;

import experimentSets.Feature;

public abstract class ParameterSet
{
	//TODO:  Add serialVersionUID
	
	/*
	 * The # of clicks to skip from the beginning of the ARISA spectra.
	 * No peaks will be called in this region
	 */
	abstract public int getNumToTrimFromBeginning();
	abstract public void setNumToTrimFromBeginning(int x);
	/*
	 * The # of clicks to skip from the end of the ARISA spectra.
	 * No peaks will be called in this region 
	 */
	abstract public int getNumToTrimFromEnd();
	abstract public void setNumToTrimFromEnd(int x);
	/*
	 * The peak calling algorithm works by fitting a different regression 
	 * starting with every point in the spectra.  
	 * This method returns the size of that window
	 */
	abstract public int getRegressionWindowSize();
	abstract public void setRegressionWindowSize(int x);
	/*
	 * The algorithm looks for a regression with a positive slope 
	 * followed by a regression with a negative slope.
	 * 
	 * This is the threshold for the positive slope
	 */
	abstract public float getRequiredPositiveSlope();
	abstract public void setRequiredPositiveSlope(float x);
	/*
	 * The algorithm looks for a regression with a positive slope 
	 * followed by a regression with a negative slope.
	 * 
	 * This is the threshold for the negative slope
	 */
	abstract public float getRequiredNegativeSlope();
	abstract public void setRequiredNegativeSlope(float x);
	/*
	 * After the positive slope is detected, the negative slope 
	 * must be detected within this number of clicks or
	 * the algorithm decides that it is not looking at a peak
	 */
	abstract public int getMaxInterslopeDistance();
	abstract public void setMaxInterslopeDistance(int x);
	/*
	 * val is usually the value of the top of the peak - the value of the bottom of the peak
	 * 
	 * This method should return true if val is over the threshold required 
	 * to be a peak.
	 * 
	 * peaks may be null but if not null is a list of all the peaks defined so far.
	 */
	abstract public boolean isOverThreshold( float val, int peakIndex, List<Feature> peaks );

	/*
	 * True peaks tend to change only gradually from one click to the next.
	 * 
	 * If there is an abrupt jump, likely indicatin a non-true peak,
	 * this method will return false
	 */
	//abstract public boolean hasAbruptJump( int startPos, int endPos, DataProvider<Integer> fsaData);
	abstract public boolean hasAbruptJump( int startPos, int endPos, DataProvider<Short> fsaData);
	abstract public boolean checkAbruptJumpSet();
	abstract public void setCheckAbrutJump(boolean x);
	/*
	 * returns true if the peak is wide enough.
	 * 
	 * peaks may be null but if not null is a list of all the peaks defined so far.
	 */
	abstract public boolean isOverRequiredPeakWidth( int width, List<Feature> peaks );
	
	abstract public float getPeakThreshold();
	abstract public void setPeakThreshold(float peakThreshold);
	abstract public float getPeakHeightThreshold();
	abstract public void setPeakHeightThreshold(float peakHeightThreshold);
	abstract public void setStandardDev(float sd);
	abstract public float getStandardDev();
	abstract public int getSmoothWindow();
	abstract public void setSmoothWindow(int smooth);
	
}
