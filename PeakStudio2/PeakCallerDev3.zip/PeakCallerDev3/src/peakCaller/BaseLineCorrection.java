package peakCaller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import utils.Avevar;

import dataProvider.ArrayBasedDataProvider;
import dataProvider.DataProvider;
import flanagan.analysis.CurveSmooth;
import flanagan.analysis.Regression;
//import flanagan.analysis.Stat;
import stats.Stat;

public class BaseLineCorrection
{
	private final double[] spectralData;
	private Short[] correctedData;
	private ArrayBasedDataProvider<Short> corrected;
	private final int regWindowSize;
	private final int regWindowIncrement;
	private final int smoothingWindow;
	private final int polyDegree;
	private List<double[]> regPoints;
	
	public BaseLineCorrection(double[] raw,int winSize,int incSize,int smoothWin,int polynomialDegree) 
	{
		this.spectralData = raw;
		this.regWindowSize = winSize;
		this.regWindowIncrement = incSize;
		this.smoothingWindow = smoothWin;
		this.polyDegree = polynomialDegree;
		runBaseLineCorrection();
		
		
	}
	
	private void runBaseLineCorrection()
	{
		double[] x = new double[this.spectralData.length];
		for(int index=0; index<x.length; index++)
			x[index] = index;
		
		CurveSmooth cs = new CurveSmooth(x, this.spectralData);
		cs.setSGpolyDegree(this.polyDegree);
		cs.setSGderivOrder(0);
		double[] smooth = cs.savitzkyGolay(this.smoothingWindow);
		getRegressionPoints();
		double[]xVals = new double[this.regPoints.size()];
		double[]yVals = new double[this.regPoints.size()];
		int position =0;
		for(double[] d: this.regPoints)
		{
			xVals[position] = d[0];
			yVals[position] = d[1];
			position++;
		}
		
		Regression r = new Regression(xVals, yVals);
		r.polynomial(3);
	
		double[] coefficients = r.getCoeff();
		this.correctedData = new Short[this.spectralData.length];
		for(int index=0; index<this.spectralData.length; index++)
		{
			double y = coefficients[0]+(coefficients[1]*index)+(coefficients[2]*Math.pow(index, 2))+(coefficients[3]*Math.pow(index, 3));
			this.correctedData[index] = (short) (smooth[index] - y);
			if(this.correctedData[index] < 0)
				this.correctedData[index] = 0;
		}
		this.corrected = new ArrayBasedDataProvider<Short>(this.correctedData);
		
	}
	
	public void removeRegressionOutliers() 
	{
		boolean altered = false;
		double[] xdata = new double[this.regPoints.size()];
		double[] ydata = new double[this.regPoints.size()];
		int count = 0;
		for (double[] d : this.regPoints)
		{
			xdata[count] = d[0];
			ydata[count] = d[1];
			count++;
		}
		Regression r = new Regression(xdata, ydata);
		r.supressYYplot();
		r.supressErrorMessages();
		r.supressPrint();
		r.polynomial(3);
		double[] residuals = r.getResiduals();
		Avevar av = new Avevar(residuals);
		double std = Math.sqrt(av.getVar());
		double mean = av.getAve();
		for (int i = residuals.length - 1; i >= 0; i--) {
			if (residuals[i] < (mean - 3 * std)
					|| residuals[i] > (mean + 3 * std)) {
				altered = true;
				this.regPoints.remove(i);
			}
		}
		if (altered == true) {
			removeRegressionOutliers();
		}
	}
	
	private void getRegressionPoints()
	{
		this.regPoints = new ArrayList<double[]>();
		for(int index=0; index<this.spectralData.length-1-this.regWindowSize; index+=this.regWindowIncrement)
		{
			double[] data = Arrays.copyOfRange(this.spectralData, index,index+this.regWindowSize);
			//Avevar av = new Avevar(data);
			double mean = calculateHistogramCentre(data);//av.getAve();
			this.regPoints.add(new double[]{(double)index+(double)this.regWindowSize/2d,mean});
		}
		removeRegressionOutliers();
	}
	
	public DataProvider<Short> getCorrectedData()
	{
		if(this.corrected == null)
			return new ArrayBasedDataProvider<Short>(this.correctedData);
		else
			return this.corrected;
	}
	private double calculateHistogramCentre(double[] d)
	{
		double c = 0;
		double std = Stat.standardDeviation(d);
		double min = Double.POSITIVE_INFINITY;
		double max = Double.NEGATIVE_INFINITY;
		for (int i = 0; i < d.length; i++) 
		{
			max = Math.max(max, d[i]);
			min = Math.min(min, d[i]);
		}
		long numberOfBins = Math.round((max - min) / std);
		long widthOfBins = Math.round((max - min) / (double) numberOfBins);
		double[][] histogram;
		try
		{
			histogram = Stat.histogramBins(d, widthOfBins, min);
		} catch (NegativeArraySizeException nase)
		{
			return c;
		}
		double[] binFrequencies = histogram[1];
		int mostPopulatedBin = 0;
		double largestBinPopulation = 0;
		for (int i = 0; i < binFrequencies.length; i++) 
		{
			if (largestBinPopulation < binFrequencies[i]) 
			{
				largestBinPopulation = binFrequencies[i];
				mostPopulatedBin = i;
			}
		}
		
		c = histogram[0][mostPopulatedBin];
		/*
		 * Collect all of the values that within the bounds c+-2*std
		 */
		ArrayList<Double> newHistogramData = new ArrayList<Double>();
		double minValue = c - 2 * std;
		double maxValue = c + 2 * std;
		for (int i = 0; i < d.length; i++)
		{
			if (minValue <= d[i] && d[i] <= maxValue) 
			{
				newHistogramData.add(d[i]);
			}
		}
		if (newHistogramData.size() * 100 < d.length * 95) 
		{	
			double[] newD = new double[newHistogramData.size()];
			int count = 0;
			for (double num : newHistogramData) 
			{
				newD[count++] = num;
			}
			return calculateHistogramCentre(newD);
		} 
		else 
		{
			return c;
		}
	}
}
