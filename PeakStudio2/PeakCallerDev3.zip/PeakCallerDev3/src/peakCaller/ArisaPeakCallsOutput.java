package peakCaller;

public class ArisaPeakCallsOutput
{
	private int arisaSignal;
	private int intergenicLengthCall;
		
	public ArisaPeakCallsOutput(int arisaSignal, int intergenicLengthCall)
	{
		this.arisaSignal = arisaSignal;
		this.intergenicLengthCall = intergenicLengthCall;
	}

	
	public int getArisaSignal()
	{
		return arisaSignal;
	}

	public int getIntergenicLengthCall()
	{
		return intergenicLengthCall;
	}

	public void setIntergenicLengthCall(double calibration)
	{		
		this.intergenicLengthCall = (int)calibration;
	}
	
	
	
}