package peakCaller;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import dataProvider.DataProvider;

import experimentSets.Feature;

public class DefaultStandardPeakParameterSet extends ParameterSet implements Serializable
{
	private static final long serialVersionUID = -1927937739170106436L;
	private int maxInterslopeDistance = 10;
	private int numToTrimFromBeginning = 0;
	private int numToTrimFromEnd = 0;
	private int regressionWindowSize = 16;
	private float requiredNegativeSlope = -1.1f;
	private float requiredPositiveSlope = 1.1f;
	private float peakThreshold = 100f;
	private float peakHeightThreshold = 0.33f;
	private float standardDev = 3.0f;
	private boolean abrubt_jump = false;
	
	public String toString()
	{
		return "Max interslope Dist: "+Integer.toString(maxInterslopeDistance)+'\n'+
				"num trim Beginning: "+Integer.toString(numToTrimFromBeginning)+'\n'+
				"num trim from End: "+Integer.toString(numToTrimFromEnd)+'\n'+
				"Regression Window Size: "+Integer.toString(regressionWindowSize)+'\n'+
				"Negative Slope: "+Float.toString(requiredNegativeSlope)+'\n'+
				"Positive Slope: "+Float.toString(requiredPositiveSlope)+'\n'+
				"Standard Deviation: "+Float.toString(standardDev)+"\n";
	}
	@Override
	public int getMaxInterslopeDistance()
	{
		return maxInterslopeDistance;
	}
	public void setMaxInterslopeDistance(int maxInterslopeDistance)
	{
		this.maxInterslopeDistance = maxInterslopeDistance;
	}
	
	@Override
	public int getNumToTrimFromBeginning()
	{
		return numToTrimFromBeginning;
	}
	public void setNumToTrimFromBeginning(int numToTrimFromBeginning)
	{
		this.numToTrimFromBeginning = numToTrimFromBeginning;
	}
	
	
	@Override
	public int getNumToTrimFromEnd()
	{
		return numToTrimFromEnd;
	}
	
	@Override
	public void setNumToTrimFromEnd(int x)
	{
		this.numToTrimFromEnd = x;
	}
	@Override
	public int getRegressionWindowSize()
	{
		return regressionWindowSize;
	}
	public void setRegressionWindowSize(int regressionWindowSize)
	{
		this.regressionWindowSize = regressionWindowSize;
	}
	
	@Override
	public float getRequiredNegativeSlope()
	{
		return requiredNegativeSlope;
	}
	public void setRequiredNegativeSlope(float requiredNegativeSlope)
	{
		this.requiredNegativeSlope = requiredNegativeSlope;
	}
	
	@Override
	public float getRequiredPositiveSlope()
	{
		return requiredPositiveSlope;
	}
	public void setRequiredPositiveSlope(float requiredPositiveSlope)
	{
		this.requiredPositiveSlope = requiredPositiveSlope;
	}
	
	public float getPeakThreshold()
	{
		return peakThreshold;
	}
	public void setPeakThreshold(float peakThreshold)
	{
		this.peakThreshold = peakThreshold;
	}
	public float getPeakHeightThreshold()
	{
		return peakHeightThreshold;
	}
	public void setPeakHeightThreshold(float peakHeightThreshold) 
	{
		this.peakHeightThreshold = peakHeightThreshold;
	}
	public void setCheckAbrutJump(boolean x)
	{
		abrubt_jump = x;
	}
	@Override
	/*public boolean hasAbruptJump(int startIndex, int endIndex, DataProvider<Integer> fsaData)*/
	public boolean hasAbruptJump(int startIndex, int endIndex, DataProvider<Short> fsaData)
	{
		if(!checkAbruptJumpSet())
			return false;
		
		List<Float> newData = new ArrayList<Float>();
		
		float minValue = Float.MAX_VALUE;
		
		for( int x=startIndex; x < endIndex; x++)
		{
			float f = (float) fsaData.get(x);
			newData.add(f);
			minValue = Math.min(minValue, f);
		}
		
		if( minValue < 0)
			for( int x=0; x < newData.size(); x++)
				newData.set(x, newData.get(x) + Math.abs( minValue) + 1);
		
		
		for( int x=1; x < newData.size(); x++)
		{
			float startVal = newData.get(x-1);
			float newVal = newData.get(x);
			
			if( Math.abs( newVal - startVal) > 50 ) 
			{
				float ratio = newVal/startVal;
				
				if( ratio !=0 &&  ratio < 1)
					ratio = 1 /ratio;
				
				if( ratio> 2)
				{
					return true;
				}
					
			}		
		}
		
		return false;
	}

	@Override
	/*
	 * 
	 * If peaks is null or empty, returns false if val is under 50.
	 * 
	 * Otherwise, if peakIndex >0 
	 * 	returns false if the values is less than 1/3 the value of the previous peak.
	 * 
	 * if peakIndex == 0, returns false if the value is less than 1/3 of the next peak
	 * 
	 */
	public boolean isOverThreshold(float val, int peakIndex, List<Feature> peaks)
	{
		if( peaks == null || peaks.size() ==0 )
			return val >= peakThreshold;
			
		if( peakIndex == 0 )  // the first peak uses the next peak for comparison
		{
			Feature nextPeak = peaks.get(1);
			
			float nextPeakThreshold = nextPeak.getMaxValue()-nextPeak.getMinValue();
			
			if( val >= peakHeightThreshold * nextPeakThreshold)
				return true;
		}
		else
		{
			Feature previousPeak = peaks.get(peakIndex-1);
			
			float oldThreshold = previousPeak.getMaxValue() - previousPeak.getMinValue();
				
			if( val > peakHeightThreshold * oldThreshold)
					return true;			
		}
			
		return false;
	}
	
	@Override
	public boolean isOverRequiredPeakWidth(int width, List<Feature> peaks)
	{
		return true;  // not used here
	}
	public boolean checkAbruptJumpSet() 
	{
		return abrubt_jump;
	}
	@Override
	public void setStandardDev(float sd)
	{
		this.standardDev = sd;	
	}
	@Override
	public float getStandardDev() 
	{
		
		return this.standardDev;
	}
	@Override
	public int getSmoothWindow() {
		// TODO Auto-generated method stub
		return 0;
	}
	@Override
	public void setSmoothWindow(int smooth) {
		// TODO Auto-generated method stub
		
	}
	
}
