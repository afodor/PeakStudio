package peakCaller;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

public class ArisaAnalysis
{	
	//this is used for multiple sample to get all intergenic lengths from peak calls
	
	public static HashMap<Integer, Integer> getAllIntergenicLengthsInSamples(HashMap<String, List<ArisaPeakCallsOutput>> summaryPeakCallsByGroup)
		throws Exception
	{	
		HashMap<Integer, Integer> intergenicLengths = new HashMap<Integer, Integer>();
		
		List<String> fileNames = new ArrayList<String>();
		fileNames.addAll(summaryPeakCallsByGroup.keySet());
		Collections.sort(fileNames);
		
		for(int i = 0; i < fileNames.size(); i++)
		{
			 String fileName = fileNames.get(i);
			 List<ArisaPeakCallsOutput> arisaData = summaryPeakCallsByGroup.get(fileName);
			 
			for(int j = 0; j < arisaData.size(); j++)
			{
				ArisaPeakCallsOutput eachLine = arisaData.get(j);
				int eachIntLength = eachLine.getIntergenicLengthCall();
				intergenicLengths.put(eachIntLength, eachIntLength);
			}
			 
		}	 
			
		return intergenicLengths;
	}
	
	public static HashMap<String, List<ArisaPeakCallsOutput>> getCommonPeakCalls(HashMap<String, List<ArisaPeakCallsOutput>> summaryPeakCallsByGroup,
			HashMap<Integer, Integer> intergenicLengths) throws Exception
	{
		HashMap<String, List<ArisaPeakCallsOutput>> revisedPeakCallsByGroup = new HashMap<String, List<ArisaPeakCallsOutput>>();
		
		List<String> fileNames = new ArrayList<String>();
		fileNames.addAll(summaryPeakCallsByGroup.keySet());
		Collections.sort(fileNames);
		
		List<Integer> allLengths = new ArrayList<Integer>();
		allLengths.addAll(intergenicLengths.keySet());
		Collections.sort(allLengths);

		Object[] lengthArray = allLengths.toArray();
		
		for(int i = 0; i < fileNames.size(); i++)
		{
			String fileName = fileNames.get(i);
			List<ArisaPeakCallsOutput> arisaData = summaryPeakCallsByGroup.get(fileName);
			List<ArisaPeakCallsOutput> revisedArisaData = new ArrayList<ArisaPeakCallsOutput>();
			
			for(int m = 0; m < lengthArray.length; m++)
			{
				int eachLength = allLengths.get(m);
				ArisaPeakCallsOutput revisedLine = new ArisaPeakCallsOutput(0, eachLength);
							
				for(int j = 0; j < arisaData.size(); j++) 
				{
					ArisaPeakCallsOutput eachLine = arisaData.get(j);
					int eachIntLength = eachLine.getIntergenicLengthCall();
					int eachSignal = eachLine.getArisaSignal();
									
					if(eachLength == eachIntLength)
					{
						revisedLine = new ArisaPeakCallsOutput(eachSignal, eachLength);
					}			
				}								
				revisedArisaData.add(revisedLine);					
			}
			revisedPeakCallsByGroup.put(fileName, revisedArisaData);			
		}
				
		return revisedPeakCallsByGroup;
	}
			
	public static List<ArisaPeakCallsOutput> getTopPeakCalls(List<ArisaPeakCallsOutput> eachSampleList,
			int desiredNumberPeaks) throws Exception
			{
				List<ArisaPeakCallsOutput> topNumberPeakCalls = new ArrayList<ArisaPeakCallsOutput>();
				List<Integer> listOfSignals = new ArrayList<Integer>();
				HashMap<Integer, Integer> tempHash = new HashMap<Integer, Integer>();
				
				for(ArisaPeakCallsOutput t: eachSampleList)
				{
					int arisaSignal = t.getArisaSignal();
					int intLength = t.getIntergenicLengthCall();
					listOfSignals.add(arisaSignal);
					tempHash.put(arisaSignal, intLength);
				}
				
				Collections.sort(listOfSignals);
				Collections.reverse(listOfSignals);
				
				if(listOfSignals.size() < desiredNumberPeaks)
					desiredNumberPeaks = listOfSignals.size();
				
				for(int i = 0; i < desiredNumberPeaks; i++)
				{
					int descendingSignal = listOfSignals.get(i);
					int intLength = tempHash.get(descendingSignal);

					ArisaPeakCallsOutput eachCall = new ArisaPeakCallsOutput(descendingSignal, intLength);
					topNumberPeakCalls.add(eachCall);					
				}				
				return topNumberPeakCalls;
			}
	
	public static void dumpSummaryPeakCallsToFile(HashMap<String, List<ArisaPeakCallsOutput>> summaryPeakCallsByGroup,
			File summaryFile) throws Exception
	{
				
		HashMap<Integer, Integer> allIntLengthsInSamples = getAllIntergenicLengthsInSamples(summaryPeakCallsByGroup);
				
		List<Integer> keys = new ArrayList<Integer>();
		keys.addAll(allIntLengthsInSamples.keySet());
		Collections.sort(keys);

		HashMap<String, List<ArisaPeakCallsOutput>> revisedPeakCallsByGroup = getCommonPeakCalls(summaryPeakCallsByGroup, 
				allIntLengthsInSamples);
		
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(summaryFile));
		
		List<String> fileNames = new ArrayList<String>();
		fileNames.addAll(revisedPeakCallsByGroup.keySet());
		Collections.sort(fileNames);
		
		
		List<ArisaPeakCallsOutput> eachCallList = revisedPeakCallsByGroup.get(fileNames.get(0));
				 
		writer.write("\t");
		
		for(int i = 0; i < fileNames.size(); i++)
		{
			 String fileName = fileNames.get(i).substring(0, fileNames.get(i).indexOf("_") + 4);
			 
			 writer.write("P" + fileName + "\t");
		}
		     	
		writer.write("\n");		
				
			for(int n = 0; n < eachCallList.size(); n++)
			{
				ArisaPeakCallsOutput eachLength = eachCallList.get(n);
				
				writer.write(eachLength.getIntergenicLengthCall() + "\t");
				
				for(int k = 0; k < fileNames.size(); k++)
				{
					String fileName = fileNames.get(k);
					List<ArisaPeakCallsOutput> eachList = revisedPeakCallsByGroup.get(fileName);
					
					ArisaPeakCallsOutput eachLine = eachList.get(n);
										
					writer.write(eachLine.getArisaSignal() + "\t" );
				}	
				writer.write("\n");		
			}
															
		writer.flush();  writer.close();
	}
	
	public static void dumpAllPeakCallsToFile(HashMap<String, List<ArisaPeakCallsOutput>> summaryPeakCallsByGroup,
			File summaryFile) throws Exception
	{
		HashMap<Integer, Integer> allIntLengthsInSamples = getAllIntergenicLengthsInSamples(summaryPeakCallsByGroup);
		int numberKeys = allIntLengthsInSamples.keySet().size();
		System.out.println("Number of keys for peak calls is " + numberKeys );
		
		List<Integer> keys = new ArrayList<Integer>();
		keys.addAll(allIntLengthsInSamples.keySet());
		Collections.sort(keys);
		
		HashMap<String, List<ArisaPeakCallsOutput>> revisedPeakCallsByGroup = getCommonPeakCalls(summaryPeakCallsByGroup, 
				allIntLengthsInSamples);
		
		BufferedWriter writer = new BufferedWriter(new FileWriter(summaryFile));
		
		List<String> fileNames = new ArrayList<String>();
		fileNames.addAll(revisedPeakCallsByGroup.keySet());
		Collections.sort(fileNames);
				
		List<ArisaPeakCallsOutput> eachCallList = revisedPeakCallsByGroup.get(fileNames.get(0));
		 
		writer.write("\t");
		
		for(int i = 0; i < fileNames.size(); i++)
		{
			 String fileName = fileNames.get(i).substring(0, fileNames.get(i).indexOf("_") + 4);
			 
			 writer.write("P" + fileName + "\t" + "Peak IL" + "\t");
		}
		     	
		writer.write("\n");
						
			for(int n = 0; n < eachCallList.size(); n++)
			{
				ArisaPeakCallsOutput eachLength = eachCallList.get(n);
				writer.write(eachLength.getIntergenicLengthCall() + "\t");
				
				for(int k = 0; k < fileNames.size(); k++)
				{
					String fileName = fileNames.get(k);
					List<ArisaPeakCallsOutput> eachList = revisedPeakCallsByGroup.get(fileName);
					
					ArisaPeakCallsOutput eachLine = eachList.get(n);
					
					writer.write(eachLine.getArisaSignal() + "\t" + eachLine.getIntergenicLengthCall() + "\t");
				}	
				writer.write("\n");		
			}
			
		writer.flush();  writer.close();
	}
	
	
}
